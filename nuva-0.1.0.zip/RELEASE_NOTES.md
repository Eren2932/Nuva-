## Nuva 0.1.0 — сервер PoC, шаги 2–3

- `server/tools/vectors.py`: эталон крипто v1 (PyNaCl) + `test-vectors.json`, HKDF по RFC 5869.
- Сервер: схема БД, WebSocket `/ws` (`nuva.v1`), регистрация по инвайту, вход по подписи ключа устройства,
  вытеснение старого соединения (4409), выгрузка офлайн-очереди после входа.
- `server/tools/invite.py`: выпуск/отзыв инвайтов.
- Деплой: `server/docker-compose.yml` (postgres + api + caddy, TLS 1.3).

Клиента в этом релизе нет: только серверный пакет и тест-векторы.
