"""Настройки сервера. Источник — переменные окружения и .env (секреты только там, ADR/§6.7)."""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

SERVER_ROOT = Path(__file__).resolve().parent.parent


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    # Обязательные.
    database_url: str = Field(description="postgresql://user:pass@host:5432/db")
    server_host: str = Field(description="HOST из §4.1: входит в подписи, зашит в клиент")

    # Пул БД.
    db_pool_min: int = Field(default=1, ge=1)
    db_pool_max: int = Field(default=5, ge=1)
    db_command_timeout_s: float = Field(default=10.0, gt=0)
    migrations_dir: Path = SERVER_ROOT / "migrations"
    apply_migrations_on_start: bool = True

    # Протокол и лимиты (§5.7).
    auth_timeout_s: float = Field(default=10.0, gt=0)
    idle_timeout_s: float = Field(default=60.0, gt=0)
    max_frame_bytes: int = Field(default=256 * 1024, gt=0)
    max_envelope_bytes: int = Field(default=64 * 1024, gt=0)
    max_envelopes_per_send: int = Field(default=10, gt=0)
    register_attempts_per_conn: int = Field(default=3, gt=0)
    queue_batch: int = Field(default=100, gt=0, le=1000)

    log_level: str = "INFO"

    @field_validator("server_host")
    @classmethod
    def _host_ascii(cls, v: str) -> str:
        v = v.strip()
        if not v or not v.isascii() or any(c.isspace() or c in "\x00/" for c in v):
            raise ValueError("SERVER_HOST must be a bare ASCII host name, e.g. api.example.org")
        return v.lower()

    @field_validator("db_pool_max")
    @classmethod
    def _pool_bounds(cls, v: int, info) -> int:
        lo = info.data.get("db_pool_min", 1)
        if v < lo:
            raise ValueError("DB_POOL_MAX must be >= DB_POOL_MIN")
        return v


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()  # type: ignore[call-arg]
