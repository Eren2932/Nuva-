"""WebSocket-протокол v1 (§5): разбор клиентских фреймов и сборка серверных.

Правила (§6.2 спецификации):
  * кривой JSON / не объект           → ProtocolViolation → закрытие 4400;
  * неизвестный type / неверные поля  → FrameInvalid      → error bad_request (соединение живёт).
"""
from __future__ import annotations

import json
import time
import uuid
from typing import Annotated, Any, Callable, Literal, Union

from pydantic import BaseModel, ConfigDict, Field, PlainValidator, TypeAdapter, ValidationError

from .crypto import B64Error, b64url_decode, b64url_encode

PROTOCOL_VERSION = 1
SUBPROTOCOL = "nuva.v1"

# Коды закрытия WS (§5.6).
CLOSE_NORMAL = 1000
CLOSE_PROTOCOL = 4400
CLOSE_UNAUTHORIZED = 4401
CLOSE_AUTH_TIMEOUT = 4408
CLOSE_REPLACED = 4409
CLOSE_RATE_LIMIT = 4429

# Коды ошибок (§5.6).
E_BAD_REQUEST = "bad_request"
E_UNAUTHORIZED = "unauthorized"
E_AUTH_FAILED = "auth_failed"
E_INVITE_INVALID = "invite_invalid"
E_USERNAME_TAKEN = "username_taken"
E_USERNAME_INVALID = "username_invalid"
E_NOT_FOUND = "not_found"
E_DEVICES_MISMATCH = "devices_mismatch"
E_PAYLOAD_TOO_LARGE = "payload_too_large"
E_RATE_LIMITED = "rate_limited"
E_INTERNAL = "internal"

T_REGISTER = "account.register"
T_AUTH_RESPONSE = "auth.response"
T_PING = "ping"
PRE_AUTH_TYPES = frozenset({T_REGISTER, T_AUTH_RESPONSE})


class ProtocolViolation(Exception):
    """Нарушение уровня транспорта/JSON: соединение закрывается 4400."""


class FrameInvalid(Exception):
    """Фрейм разобран как JSON, но не прошёл схему: ответ error bad_request."""

    def __init__(self, message: str, frame_id: str | None):
        super().__init__(message)
        self.frame_id = frame_id


# ── Типы полей ──

def _b64_exact(n: int) -> Callable[[Any], bytes]:
    def validate(value: Any) -> bytes:
        if not isinstance(value, str):
            raise ValueError("expected base64url string")
        try:
            raw = b64url_decode(value)
        except B64Error as exc:
            raise ValueError(str(exc)) from exc
        if len(raw) != n:
            raise ValueError(f"expected {n} bytes")
        return raw
    return validate


Key32 = Annotated[bytes, PlainValidator(_b64_exact(32))]
Sig64 = Annotated[bytes, PlainValidator(_b64_exact(64))]
FrameId = Annotated[str, Field(min_length=1, max_length=64)]


class _Frame(BaseModel):
    # extra="ignore": новые необязательные поля от свежих клиентов не ломают старый сервер.
    model_config = ConfigDict(extra="ignore", frozen=True)
    v: Literal[1]


class DeviceKeys(BaseModel):
    model_config = ConfigDict(extra="ignore", frozen=True)
    identity_key: Key32
    x25519_key: Key32
    x25519_sig: Sig64
    platform: Literal["android", "desktop", "ios"]


class AccountRegister(_Frame):
    type: Literal["account.register"]
    id: FrameId
    invite: Annotated[str, Field(min_length=1, max_length=32)]
    # Формат юзернейма проверяет обработчик (нужен отдельный код username_invalid).
    username: Annotated[str, Field(min_length=1, max_length=64)]
    device: DeviceKeys
    sig: Sig64


class AuthResponse(_Frame):
    type: Literal["auth.response"]
    id: FrameId
    device_id: uuid.UUID
    sig: Sig64


class Ping(_Frame):
    type: Literal["ping"]
    id: FrameId | None = None


ClientFrame = Annotated[Union[AccountRegister, AuthResponse, Ping], Field(discriminator="type")]
_adapter: TypeAdapter[Any] = TypeAdapter(ClientFrame)


def parse_json(text: str) -> dict[str, Any]:
    try:
        obj = json.loads(text)
    except (ValueError, RecursionError) as exc:
        raise ProtocolViolation("malformed json") from exc
    if not isinstance(obj, dict):
        raise ProtocolViolation("frame must be a json object")
    return obj


def frame_id_of(obj: dict[str, Any]) -> str | None:
    fid = obj.get("id")
    return fid if isinstance(fid, str) and 0 < len(fid) <= 64 else None


def validate_frame(obj: dict[str, Any]) -> AccountRegister | AuthResponse | Ping:
    try:
        return _adapter.validate_python(obj)
    except ValidationError as exc:
        first = exc.errors(include_url=False, include_input=False)[0]
        loc = ".".join(str(p) for p in first.get("loc", ()))
        kind = first.get("type", "invalid")
        if kind in ("union_tag_invalid", "union_tag_not_found"):
            msg = "unknown frame type"
        else:
            msg = f"invalid field {loc}: {kind}" if loc else f"invalid frame: {kind}"
        raise FrameInvalid(msg, frame_id_of(obj)) from None


# ── Серверные фреймы ──

def now_ms() -> int:
    return time.time_ns() // 1_000_000


def _f(type_: str, frame_id: str | None = None, **fields: Any) -> dict[str, Any]:
    out: dict[str, Any] = {"v": PROTOCOL_VERSION, "type": type_}
    if frame_id is not None:
        out["id"] = frame_id
    out.update(fields)
    return out


def auth_challenge(nonce: bytes) -> dict[str, Any]:
    return _f("auth.challenge", nonce=b64url_encode(nonce), server_time=now_ms())


def account_registered(frame_id: str, account_id: uuid.UUID, device_id: uuid.UUID) -> dict[str, Any]:
    return _f("account.registered", frame_id, account_id=str(account_id), device_id=str(device_id))


def auth_ok(frame_id: str, account_id: uuid.UUID, device_id: uuid.UUID, pending: int) -> dict[str, Any]:
    return _f("auth.ok", frame_id, account_id=str(account_id), device_id=str(device_id), pending=pending)


def msg_deliver(server_id: int, from_account: uuid.UUID | None, from_device: uuid.UUID | None,
                client_msg_id: uuid.UUID, envelope: bytes, server_ts: int) -> dict[str, Any]:
    return _f("msg.deliver", server_id=server_id,
              from_account=str(from_account) if from_account else None,
              from_device=str(from_device) if from_device else None,
              client_msg_id=str(client_msg_id), envelope=b64url_encode(envelope), server_ts=server_ts)


def queue_empty() -> dict[str, Any]:
    return _f("queue.empty")


def pong(frame_id: str | None) -> dict[str, Any]:
    return _f("pong", frame_id, server_time=now_ms())


def error(code: str, frame_id: str | None = None, message: str | None = None,
          details: dict[str, Any] | None = None) -> dict[str, Any]:
    fields: dict[str, Any] = {"code": code}
    if message is not None:
        fields["message"] = message
    if details is not None:
        fields["details"] = details
    return _f("error", frame_id, **fields)


def dumps(frame: dict[str, Any]) -> str:
    return json.dumps(frame, ensure_ascii=False, separators=(",", ":"))
