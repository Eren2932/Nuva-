# Nuva — клиент (Kotlin Multiplatform)

```
client/
├── core/         ядро без UI: libsodium (ionspin), WebSocket (Ktor), SQLDelight, регистрация, Messenger
├── ui/           общий Compose-UI: тема #6559A3, онбординг, чаты, поиск, переписка, профиль
├── app-android/  Android-приложение (Keystore, системная заставка, R8)
└── app-desktop/  desktop — в следующем архиве (settings подключит его автоматически)
```

## Сборка Android

```bash
export NUVA_SERVER_HOST=api.example.org      # без схемы и пути; входит в подписи
gradle :app-android:assembleDebug            # локально, debug-подпись
gradle :app-android:assembleRelease          # релиз; ключ — из NUVA_SIGNING_* (CI-секреты)
gradle :core:allTests                        # тест-векторы, общие с сервером
```

Нужен JDK 17 и Android SDK 35. Если R8 поведёт себя странно: `-Pnuva.minify=false`.

## Поток экранов

Заставка → Приветствие → Код приглашения (XXXXX-XXXXX) → Имя / Фамилия → @username →
Генерация ключей (≥1.2 с, потом регистрация одним запросом) → Чаты.

Ошибки последнего шага возвращают на нужный экран: занятый юзернейм — на юзернейм,
плохой инвайт — на инвайт, а при ошибке сети ключи переиспользуются, и можно нажать «Повторить».
Регистрация идёт в скоупе приложения: при повороте экрана второй запрос не уходит, инвайт не сгорает.

## Безопасность на устройстве

- Секреты учётки: AES-256-GCM, ключ лежит в Android Keystore, файл — в `noBackupFilesDir`.
- `allowBackup=false` плюс `dataExtractionRules`: на Android 12+ запрещён и перенос между устройствами.
- Поиск только по точному @username: списки пользователей сервер не отдаёт.
