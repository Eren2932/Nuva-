import java.util.Properties

plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.android.library) apply false
    alias(libs.plugins.kotlin.multiplatform) apply false
    alias(libs.plugins.kotlin.android) apply false
    alias(libs.plugins.compose.compiler) apply false
    alias(libs.plugins.compose.multiplatform) apply false
    alias(libs.plugins.sqldelight) apply false
}

// Единый источник версии — ../version.properties (тот же файл читает CI).
val versionProps = Properties().apply {
    val f = rootDir.resolve("../version.properties")
    check(f.isFile) { "version.properties not found at ${f.absolutePath}" }
    f.inputStream().use { load(it) }
}
val nuvaVersionName: String = versionProps.getProperty("versionName").trim()
val nuvaVersionCode: Int = versionProps.getProperty("versionCode").trim().toInt()
val nuvaServerHost: String = (System.getenv("NUVA_SERVER_HOST")?.takeIf { it.isNotBlank() }
    ?: (findProperty("nuva.serverHost") as String?) ?: "").trim().lowercase()

extra["nuvaVersionName"] = nuvaVersionName
extra["nuvaVersionCode"] = nuvaVersionCode
extra["nuvaServerHost"] = nuvaServerHost
