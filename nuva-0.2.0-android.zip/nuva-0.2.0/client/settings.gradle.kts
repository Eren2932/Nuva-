rootProject.name = "nuva"

pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.PREFER_SETTINGS)
    repositories {
        google()
        mavenCentral()
    }
}

include(":core", ":ui", ":app-android")
// Desktop-приложение подключается автоматически, как только появится папка (следующий архив).
if (file("app-desktop/build.gradle.kts").isFile) include(":app-desktop")
