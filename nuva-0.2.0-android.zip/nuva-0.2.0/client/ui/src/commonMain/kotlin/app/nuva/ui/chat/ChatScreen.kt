package app.nuva.ui.chat

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.isShiftPressed
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.nuva.core.chat.ChatMessage
import app.nuva.core.chat.Limits
import app.nuva.core.chat.Messenger
import app.nuva.core.chat.MsgStatus
import app.nuva.core.chat.Peer
import app.nuva.core.net.SocketState
import app.nuva.ui.AppGraph
import app.nuva.ui.chats.requireMessenger
import app.nuva.ui.components.Avatar
import app.nuva.ui.components.NuvaTopBar
import app.nuva.ui.components.StatusTicks
import app.nuva.ui.components.connectionLabel
import app.nuva.ui.components.dayKey
import app.nuva.ui.components.daySeparator
import app.nuva.ui.components.timeHm
import app.nuva.ui.theme.NuvaColors
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.launch

private const val PAGE = 80L
/** Сообщения одного автора ближе этого интервала склеиваются в группу (как в Telegram). */
private const val GROUP_MS = 5 * 60_000L

@OptIn(ExperimentalCoroutinesApi::class)
@Composable
fun ChatScreen(graph: AppGraph, peerId: String) {
    val m = requireMessenger(graph) ?: return
    val socket by graph.core.socket.state.collectAsState()
    val peer by remember(m, peerId) { m.peer(peerId) }.collectAsState(initial = null)

    // Окно сообщений растёт страницами; flatMapLatest не сбрасывает список при подгрузке → без мерцания.
    val limit = remember(peerId) { MutableStateFlow(PAGE) }
    val messages by remember(m, peerId) { limit.flatMapLatest { m.messages(peerId, it) } }
        .collectAsState(initial = null)
    val list = messages.orEmpty()
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    var showInfo by remember { mutableStateOf(false) }

    // Открытый чат: входящие не копят непрочитанные; уходим — снимаем отметку.
    DisposableEffect(m, peerId) {
        m.activeChat.value = peerId
        onDispose { if (m.activeChat.value == peerId) m.activeChat.value = null }
    }
    val newest = list.firstOrNull()
    LaunchedEffect(newest?.localId) {
        m.markRead(peerId)
        // Своё сообщение — всегда вниз; чужое — только если пользователь и так внизу.
        if (newest != null && (newest.outgoing || listState.firstVisibleItemIndex <= 2)) {
            listState.animateScrollToItem(0)
        }
    }
    // Подгрузка истории при приближении к верху.
    LaunchedEffect(listState, list.size) {
        snapshotFlow { listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0 }
            .distinctUntilChanged()
            .collect { last -> if (list.size.toLong() >= limit.value && last >= list.size - 15) limit.value += PAGE }
    }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).imePadding()) {
        NuvaTopBar {
            IconButton(onClick = { graph.router.back() }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Назад")
            }
            val p = peer
            Row(
                Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).clickable(enabled = p != null) { showInfo = true }
                    .padding(vertical = 6.dp, horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Avatar(peerId, p?.title ?: "", 40.dp)
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(p?.title ?: "", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold,
                        maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(connectionLabel(socket)?.lowercase() ?: p?.let { "@${it.username}" } ?: "",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (socket == SocketState.Online) MaterialTheme.colorScheme.secondary
                        else MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                }
            }
        }
        peer?.takeIf { it.keyChanged }?.let { p -> KeyChangedBanner(p, onCheck = { showInfo = true }) {
            scope.launch { m.acceptKeyChange(peerId) }
        } }

        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (messages != null && list.isEmpty()) EmptyChat(Modifier.align(Alignment.Center))
            LazyColumn(
                state = listState,
                reverseLayout = true,
                modifier = Modifier.fillMaxSize(),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 8.dp),
            ) {
                itemsIndexed(list, key = { _, msg -> msg.localId }) { i, msg ->
                    val newer = list.getOrNull(i - 1)
                    val older = list.getOrNull(i + 1)
                    val newDay = older == null || dayKey(older.ts) != dayKey(msg.ts)
                    val groupEnd = newer == null || newer.outgoing != msg.outgoing ||
                        newer.ts - msg.ts > GROUP_MS || dayKey(newer.ts) != dayKey(msg.ts)
                    val groupStart = newDay || older!!.outgoing != msg.outgoing || msg.ts - older.ts > GROUP_MS
                    Column(Modifier.animateItem()) {
                        if (newDay) DayChip(msg.ts)
                        Bubble(msg, groupEnd, groupStart, m, peerId)
                    }
                }
            }
        }
        Composer(onSend = { text -> scope.launch { m.sendText(peerId, text) } })
    }

    val p = peer
    if (showInfo && p != null) PeerInfoDialog(p, m, onDismiss = { showInfo = false }) {
        scope.launch { m.acceptKeyChange(peerId) }
        showInfo = false
    }
}

@Composable
private fun DayChip(ts: Long) {
    Box(Modifier.fillMaxWidth().padding(vertical = 10.dp), contentAlignment = Alignment.Center) {
        Surface(color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.85f), shape = RoundedCornerShape(12.dp)) {
            Text(daySeparator(ts), Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun Bubble(msg: ChatMessage, groupEnd: Boolean, groupStart: Boolean, m: Messenger, peerId: String) {
    val out = msg.outgoing
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()
    var menu by remember { mutableStateOf(false) }
    val big = 18.dp
    val small = 6.dp
    // Сторона автора: верхний угол скруглён только у первого в группе, нижний — всегда «хвостик».
    val edgeTop = if (groupStart) big else small
    val edgeBottom = if (groupEnd) 4.dp else small
    val shape = if (out) RoundedCornerShape(topStart = big, topEnd = edgeTop, bottomEnd = edgeBottom, bottomStart = big)
    else RoundedCornerShape(topStart = edgeTop, topEnd = big, bottomEnd = big, bottomStart = edgeBottom)
    val failed = msg.status == MsgStatus.FAILED
    val metaColor = if (out) Color.White.copy(alpha = 0.72f) else MaterialTheme.colorScheme.onSurfaceVariant

    Row(
        Modifier.fillMaxWidth().padding(top = if (groupStart) 6.dp else 2.dp),
        horizontalArrangement = if (out) Arrangement.End else Arrangement.Start,
    ) {
        Box {
            Box(
                Modifier.widthIn(max = 340.dp).clip(shape)
                    .then(if (out) Modifier.background(NuvaColors.OutgoingBubble) else Modifier.background(NuvaColors.IncomingBubble))
                    .combinedClickable(
                        onClick = { if (failed) scope.launch { m.retry(peerId, msg.clientMsgId) } },
                        onLongClick = { menu = true },
                    )
                    .padding(start = 12.dp, end = 10.dp, top = 7.dp, bottom = 7.dp),
            ) {
                // Невидимый «хвост» из em-пробелов резервирует место под время — как в Telegram.
                Text(
                    msg.body + (if (out) "\u2003\u2003\u2003\u2003" else "\u2003\u2003\u2003"),
                    style = MaterialTheme.typography.bodyLarge.copy(fontSize = 16.sp, lineHeight = 21.sp),
                    color = if (out) Color.White else MaterialTheme.colorScheme.onSurface,
                )
                Row(Modifier.align(Alignment.BottomEnd).padding(top = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(timeHm(msg.ts), fontSize = 11.sp, color = metaColor)
                    if (out) {
                        Spacer(Modifier.width(3.dp))
                        StatusTicks(msg.status, metaColor)
                    }
                }
            }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(text = { Text("Копировать") }, onClick = {
                    clipboard.setText(AnnotatedString(msg.body)); menu = false
                })
                if (failed) DropdownMenuItem(text = { Text("Отправить ещё раз") }, onClick = {
                    scope.launch { m.retry(peerId, msg.clientMsgId) }; menu = false
                })
            }
        }
    }
    if (failed) {
        Text("Не отправлено · нажмите, чтобы повторить", Modifier.fillMaxWidth().padding(top = 2.dp, end = 4.dp),
            textAlign = TextAlign.End, fontSize = 11.sp, color = MaterialTheme.colorScheme.error)
    }
}

@Composable
private fun Composer(onSend: (String) -> Unit) {
    var text by remember { mutableStateOf("") }
    val cs = MaterialTheme.colorScheme
    val canSend = text.isNotBlank()
    val send = {
        if (canSend) { onSend(text); text = "" }
    }
    Surface(color = cs.surfaceContainer) {
        Row(
            Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.Bottom,
        ) {
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(22.dp)).background(cs.surfaceContainerHighest)
                    .padding(horizontal = 16.dp, vertical = 11.dp),
            ) {
                if (text.isEmpty()) Text("Сообщение", color = cs.onSurfaceVariant, style = MaterialTheme.typography.bodyLarge)
                BasicTextField(
                    value = text,
                    onValueChange = { text = it.take(Limits.MAX_TEXT) },
                    maxLines = 6,
                    textStyle = MaterialTheme.typography.bodyLarge.copy(color = cs.onSurface),
                    cursorBrush = SolidColor(cs.secondary),
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                    // Desktop/физическая клавиатура: Enter — отправить, Shift+Enter — новая строка.
                    modifier = Modifier.fillMaxWidth().onPreviewKeyEvent { e ->
                        if ((e.key == Key.Enter || e.key == Key.NumPadEnter) && !e.isShiftPressed) {
                            if (e.type == KeyEventType.KeyDown) send()
                            true
                        } else false
                    },
                )
            }
            AnimatedVisibility(canSend, enter = scaleIn() + fadeIn(), exit = scaleOut() + fadeOut()) {
                Box(Modifier.padding(start = 8.dp).size(46.dp).clip(CircleShape).background(cs.primary)
                    .clickable { send() }, contentAlignment = Alignment.Center) {
                    Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Отправить", tint = cs.onPrimary,
                        modifier = Modifier.size(22.dp))
                }
            }
        }
    }
    if (text.length > Limits.MAX_TEXT - 300) {
        Text("${text.length}/${Limits.MAX_TEXT}", Modifier.fillMaxWidth().padding(end = 16.dp, bottom = 4.dp),
            textAlign = TextAlign.End, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun EmptyChat(modifier: Modifier) {
    Surface(modifier.padding(32.dp), color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.8f),
        shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(horizontal = 24.dp, vertical = 20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Filled.Lock, null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(32.dp))
            Spacer(Modifier.height(10.dp))
            Text("Сообщений пока нет", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(6.dp))
            Text("Сообщения шифруются на этом устройстве. Сервер видит только зашифрованные данные.",
                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun KeyChangedBanner(peer: Peer, onCheck: () -> Unit, onAccept: () -> Unit) {
    Surface(color = MaterialTheme.colorScheme.error.copy(alpha = 0.12f)) {
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.Warning, null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(10.dp))
            Text("Ключ @${peer.username} изменился. Сверьте код безопасности.", Modifier.weight(1f),
                style = MaterialTheme.typography.bodySmall)
            TextButton(onClick = onCheck) { Text("Код") }
            TextButton(onClick = onAccept) { Text("Принять") }
        }
    }
}

@Composable
private fun PeerInfoDialog(peer: Peer, m: Messenger, onDismiss: () -> Unit, onAccept: () -> Unit) {
    val code = remember(peer.identityKey) { m.safetyNumber(peer) }
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Avatar(peer.accountId, peer.title, 64.dp) },
        title = { Text(peer.title, textAlign = TextAlign.Center) },
        text = {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                Text("@${peer.username}", color = MaterialTheme.colorScheme.secondary)
                Spacer(Modifier.height(18.dp))
                Text("Код безопасности", style = MaterialTheme.typography.labelLarge)
                Spacer(Modifier.height(8.dp))
                Text(code, fontFamily = FontFamily.Monospace, fontSize = 17.sp, lineHeight = 26.sp,
                    textAlign = TextAlign.Center, letterSpacing = 1.sp)
                Spacer(Modifier.height(10.dp))
                Text("Сравните код с собеседником при встрече или по звонку. Совпадает — переписку никто не подменяет.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center)
            }
        },
        confirmButton = {
            if (peer.keyChanged) TextButton(onClick = onAccept) { Text("Код совпал — принять") }
            else TextButton(onClick = onDismiss) { Text("Готово") }
        },
        dismissButton = if (peer.keyChanged) ({ TextButton(onClick = onDismiss) { Text("Позже") } }) else null,
    )
}
