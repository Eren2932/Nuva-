package app.nuva.ui.onboarding

import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.nuva.core.chat.Limits
import app.nuva.ui.AppGraph
import app.nuva.ui.components.ErrorText
import app.nuva.ui.components.NuvaField
import app.nuva.ui.components.PrimaryButton
import app.nuva.ui.components.StepScaffold
import app.nuva.ui.nav.Screen
import app.nuva.ui.onboarding.OnboardingState.Companion.INVITE_LEN

/** Показ инвайта как XXXXX-XXXXX; в состоянии хранятся только 10 «чистых» символов. */
private object InviteMask : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText {
        val s = text.text
        if (s.length <= 5) return TransformedText(text, OffsetMapping.Identity)
        val out = s.substring(0, 5) + "-" + s.substring(5)
        return TransformedText(AnnotatedString(out), object : OffsetMapping {
            override fun originalToTransformed(offset: Int) = if (offset <= 5) offset else offset + 1
            override fun transformedToOriginal(offset: Int) = if (offset <= 5) offset else offset - 1
        })
    }
}

@Composable
private fun AutoFocus(requester: FocusRequester) {
    LaunchedEffect(Unit) { runCatching { requester.requestFocus() } }
}

@Composable
fun InviteScreen(graph: AppGraph) {
    val ob = graph.onboarding
    val focus = remember { FocusRequester() }
    val ready = ob.invite.length == INVITE_LEN
    val next = { if (ready) graph.router.push(Screen.Name) }
    StepScaffold(
        title = "Приглашение",
        subtitle = "Nuva работает по приглашениям. Введите код из 10 символов, который вам прислали.",
        onBack = { graph.router.back() },
        button = { PrimaryButton("Далее", onClick = next, enabled = ready) },
    ) {
        NuvaField(
            value = ob.invite,
            onValueChange = { ob.invite = OnboardingState.normalizeInvite(it); ob.inviteError = null },
            label = "Код приглашения",
            modifier = Modifier.focusRequester(focus),
            isError = ob.inviteError != null,
            textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 20.sp, letterSpacing = 2.sp),
            visualTransformation = InviteMask,
            keyboardOptions = KeyboardOptions(
                capitalization = KeyboardCapitalization.Characters,
                autoCorrectEnabled = false,
                keyboardType = KeyboardType.Ascii,
                imeAction = ImeAction.Next,
            ),
            keyboardActions = KeyboardActions(onNext = { next() }),
        )
        ErrorText(ob.inviteError)
        Spacer(Modifier.height(12.dp))
        Text(
            "Дефисы и регистр не важны. Код одноразовый — он проверится на последнем шаге.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
    AutoFocus(focus)
}

@Composable
fun NameScreen(graph: AppGraph) {
    val ob = graph.onboarding
    val focus = remember { FocusRequester() }
    val fm = LocalFocusManager.current
    val ready = OnboardingState.cleanName(ob.firstName).isNotEmpty()
    val next = {
        if (ready) {
            ob.firstName = OnboardingState.cleanName(ob.firstName)
            ob.lastName = OnboardingState.cleanName(ob.lastName)
            graph.router.push(Screen.Username)
        }
    }
    StepScaffold(
        title = "Ваше имя",
        subtitle = "Так вас увидят собеседники. Фамилию можно не указывать.",
        onBack = { graph.router.back() },
        button = { PrimaryButton("Далее", onClick = next, enabled = ready) },
    ) {
        NuvaField(
            value = ob.firstName,
            onValueChange = { ob.firstName = it.take(Limits.NAME_MAX) },
            label = "Имя",
            modifier = Modifier.focusRequester(focus),
            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words, imeAction = ImeAction.Next),
            keyboardActions = KeyboardActions(onNext = { fm.moveFocus(FocusDirection.Down) }),
        )
        Spacer(Modifier.height(14.dp))
        NuvaField(
            value = ob.lastName,
            onValueChange = { ob.lastName = it.take(Limits.NAME_MAX) },
            label = "Фамилия (необязательно)",
            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words, imeAction = ImeAction.Done),
            keyboardActions = KeyboardActions(onDone = { next() }),
        )
    }
    AutoFocus(focus)
}

@Composable
fun UsernameScreen(graph: AppGraph) {
    val ob = graph.onboarding
    val focus = remember { FocusRequester() }
    val hint = OnboardingState.usernameHint(ob.username)
    val ready = Limits.USERNAME.matches(ob.username)
    val next = {
        if (ready) {
            ob.usernameError = null
            ob.phase = RegPhase.Idle
            graph.router.push(Screen.KeyGen)
        }
    }
    StepScaffold(
        title = "Имя пользователя",
        subtitle = "По нему вас найдут в Nuva. Номер телефона и почта не нужны.",
        onBack = { graph.router.back() },
        button = { PrimaryButton("Создать аккаунт", onClick = next, enabled = ready) },
    ) {
        NuvaField(
            value = ob.username,
            onValueChange = { ob.username = OnboardingState.filterUsername(it); ob.usernameError = null },
            label = "Имя пользователя",
            prefix = "@",
            modifier = Modifier.focusRequester(focus),
            isError = ob.usernameError != null || (hint != null && ob.username.length >= 3),
            supporting = "${ob.username.length}/32",
            keyboardOptions = KeyboardOptions(
                capitalization = KeyboardCapitalization.None,
                autoCorrectEnabled = false,
                keyboardType = KeyboardType.Ascii,
                imeAction = ImeAction.Done,
            ),
            keyboardActions = KeyboardActions(onDone = { next() }),
        )
        ErrorText(ob.usernameError ?: hint)
        Spacer(Modifier.height(14.dp))
        Text(
            "a–z, 0–9 и _ · от 3 до 32 символов",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        if (ready) {
            Spacer(Modifier.height(20.dp))
            Text(
                "Вас найдут как @${ob.username}",
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.secondary,
            )
        }
    }
    AutoFocus(focus)
}
