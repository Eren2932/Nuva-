# libsodium через JNA: нативный код ищет классы и поля по именам.
-keep class com.sun.jna.** { *; }
-keepclassmembers class * extends com.sun.jna.** { public *; }
-keep class com.ionspin.kotlin.crypto.** { *; }
-dontwarn java.awt.**
-dontwarn com.sun.jna.**

# Ktor / OkHttp: опциональные зависимости, которых нет на Android.
-dontwarn org.slf4j.**
-dontwarn java.lang.management.**
-dontwarn javax.naming.**
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**
-keepclassmembers class io.ktor.** { volatile <fields>; }

# Корутины: AtomicFieldUpdater по именам полей.
-keepclassmembers class kotlinx.coroutines.** { volatile <fields>; }

# Стектрейсы в отчётах об ошибках оставляем читаемыми.
-keepattributes SourceFile,LineNumberTable
