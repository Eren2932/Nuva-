package app.nuva.android

import android.content.Context
import app.cash.sqldelight.db.SqlDriver
import app.cash.sqldelight.driver.android.AndroidSqliteDriver
import app.nuva.core.Platform
import app.nuva.core.SecretStore
import app.nuva.db.NuvaDatabase
import io.ktor.client.HttpClient
import io.ktor.client.engine.okhttp.OkHttp
import io.ktor.client.plugins.websocket.WebSockets
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import java.io.File
import java.util.concurrent.TimeUnit

class AndroidPlatform(private val ctx: Context) : Platform {
    override val name: String = "android"
    override val io: CoroutineDispatcher = Dispatchers.IO

    // noBackupFilesDir: Android сам исключает эту папку из любых бэкапов.
    override val secrets: SecretStore = KeystoreSecretStore(File(ctx.noBackupFilesDir, "account.bin"))

    override fun createSqlDriver(): SqlDriver = AndroidSqliteDriver(NuvaDatabase.Schema, ctx, "nuva.db")

    override fun createHttpClient(): HttpClient = HttpClient(OkHttp) {
        install(WebSockets)
        engine {
            config {
                connectTimeout(15, TimeUnit.SECONDS)
                readTimeout(0, TimeUnit.SECONDS) // WebSocket живёт долго; живость проверяет ping ядра
                retryOnConnectionFailure(true)
            }
        }
    }
}
