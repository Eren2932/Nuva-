package app.nuva.android

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Log
import app.nuva.core.SecretStore
import java.io.File
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Секреты учётки шифруются AES-256-GCM ключом из Android Keystore (аппаратным, где он есть).
 * Ключ неизвлекаемый: даже root-доступ к файлу не даёт расшифровать его вне этого устройства.
 * Формат файла: [версия=1][iv 12 байт][шифртекст+тег].
 */
class KeystoreSecretStore(private val file: File) : SecretStore {
    private val lock = Any()

    override fun read(): ByteArray? = synchronized(lock) {
        if (!file.isFile) return null
        try {
            val blob = file.readBytes()
            require(blob.size > 1 + IV_LEN && blob[0] == VERSION) { "bad secret file format" }
            val c = Cipher.getInstance(TRANSFORM)
            c.init(Cipher.DECRYPT_MODE, key(create = false) ?: return null,
                GCMParameterSpec(128, blob, 1, IV_LEN))
            c.doFinal(blob, 1 + IV_LEN, blob.size - 1 - IV_LEN)
        } catch (e: Exception) {
            // Ключ Keystore потерян (сброс блокировки экрана, перенос данных) — расшифровать нечем.
            Log.e(TAG, "secret store unreadable", e)
            null
        }
    }

    override fun write(data: ByteArray): Unit = synchronized(lock) {
        val c = Cipher.getInstance(TRANSFORM)
        c.init(Cipher.ENCRYPT_MODE, key(create = true)!!)
        val iv = c.iv
        check(iv.size == IV_LEN) { "unexpected IV length ${iv.size}" }
        val ct = c.doFinal(data)
        // Атомарно: пишем во временный файл и переименовываем — без «половины» ключей при сбое.
        val tmp = File(file.parentFile, file.name + ".tmp")
        tmp.outputStream().use { out ->
            out.write(byteArrayOf(VERSION)); out.write(iv); out.write(ct)
            out.fd.sync()
        }
        if (!tmp.renameTo(file)) {
            file.delete()
            check(tmp.renameTo(file)) { "cannot replace secret file" }
        }
    }

    override fun clear(): Unit = synchronized(lock) {
        file.delete()
        File(file.parentFile, file.name + ".tmp").delete()
        runCatching { keyStore().deleteEntry(ALIAS) }
    }

    private fun keyStore(): KeyStore = KeyStore.getInstance(PROVIDER).apply { load(null) }

    private fun key(create: Boolean): SecretKey? {
        (keyStore().getKey(ALIAS, null) as? SecretKey)?.let { return it }
        if (!create) return null
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, PROVIDER)
        gen.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .setRandomizedEncryptionRequired(true)
                .build(),
        )
        return gen.generateKey()
    }

    private companion object {
        const val TAG = "Nuva"
        const val PROVIDER = "AndroidKeyStore"
        const val ALIAS = "nuva.account.v1"
        const val TRANSFORM = "AES/GCM/NoPadding"
        const val IV_LEN = 12
        const val VERSION: Byte = 1
    }
}
