package app.nuva.android

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import app.nuva.ui.NuvaApp

class MainActivity : ComponentActivity() {
    private val graph get() = (application as NuvaApplication).graph

    override fun onCreate(savedInstanceState: Bundle?) {
        // Системная заставка снимается на первом кадре Compose, а он рисует тот же знак
        // на том же месте — переход без вспышки.
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
        )
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (!graph.back()) {
                    // Стек пуст — отдаём системе (свернуть приложение).
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                    isEnabled = true
                }
            }
        })
        setContent { NuvaApp(graph) }
    }

    override fun onStart() {
        super.onStart()
        graph.onForeground()
    }
}
