package app.nuva.android

import android.app.Application
import android.net.ConnectivityManager
import android.net.Network
import app.nuva.ui.AppGraph

/** Один AppGraph на процесс: переживает пересоздание Activity, регистрация не обрывается. */
class NuvaApplication : Application() {
    lateinit var graph: AppGraph
        private set

    override fun onCreate() {
        super.onCreate()
        graph = AppGraph(AndroidPlatform(this))
        // Сеть вернулась — переподключаемся сразу, не дожидаясь backoff-таймера сокета.
        getSystemService(ConnectivityManager::class.java)?.registerDefaultNetworkCallback(
            object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) = graph.onForeground()
            },
        )
    }
}
