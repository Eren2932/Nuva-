import org.jetbrains.compose.desktop.application.dsl.TargetFormat
import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    alias(libs.plugins.kotlin.jvm)
    alias(libs.plugins.compose.multiplatform)
    alias(libs.plugins.compose.compiler)
}

// jpackage принимает только числовое X.Y.Z: суффикс вида -beta отбрасываем.
val packageVer = (rootProject.extra["nuvaVersionName"] as String).substringBefore('-')

kotlin {
    compilerOptions { jvmTarget.set(JvmTarget.JVM_17) }
}

dependencies {
    implementation(project(":ui"))
    implementation(compose.desktop.currentOs)
    implementation(libs.coroutines.swing)
    implementation(libs.ktor.client.okhttp)
    implementation(libs.sqldelight.jvm)
}

compose.desktop {
    application {
        mainClass = "app.nuva.desktop.MainKt"

        nativeDistributions {
            targetFormats(TargetFormat.Msi, TargetFormat.Deb)
            packageName = "Nuva"
            packageVersion = packageVer
            description = "Nuva — приватный мессенджер"
            vendor = "Nuva"
            // JNA (libsodium) и SQLite тянут модули JDK по рефлексии: надёжнее взять полный рантайм,
            // чем гадать список через suggestRuntimeModules. Установщик станет больше, зато запустится.
            includeAllModules = true

            windows {
                menuGroup = "Nuva"
                shortcut = true
                dirChooser = true
                perUserInstall = true
                // Постоянный UUID: по нему Windows понимает, что новая версия — обновление, а не вторая программа.
                upgradeUuid = "6f1c2b5e-3a9d-4e57-9b0a-5d2c7e8f4a11"
                iconFile.set(project.file("icons/nuva.ico"))
            }
            linux {
                packageName = "nuva"
                shortcut = true
                iconFile.set(project.file("icons/nuva.png"))
            }
        }
    }
}
