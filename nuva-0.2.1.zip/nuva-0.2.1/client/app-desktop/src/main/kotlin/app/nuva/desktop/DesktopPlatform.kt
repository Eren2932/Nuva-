package app.nuva.desktop

import app.cash.sqldelight.db.QueryResult
import app.cash.sqldelight.db.SqlDriver
import app.cash.sqldelight.driver.jdbc.sqlite.JdbcSqliteDriver
import app.nuva.core.Platform
import app.nuva.core.SecretStore
import app.nuva.db.NuvaDatabase
import io.ktor.client.HttpClient
import io.ktor.client.engine.okhttp.OkHttp
import io.ktor.client.plugins.websocket.WebSockets
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import java.io.File
import java.io.RandomAccessFile
import java.nio.channels.FileLock
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.nio.file.attribute.PosixFilePermissions
import java.util.concurrent.TimeUnit

class DesktopPlatform : Platform {
    override val name: String = "desktop"
    override val io: CoroutineDispatcher = Dispatchers.IO

    /** Windows — %APPDATA%\Nuva, macOS — ~/Library/Application Support/Nuva, Linux — $XDG_DATA_HOME/nuva. */
    private val dir: File = run {
        val os = System.getProperty("os.name").lowercase()
        val home = System.getProperty("user.home")
        val base = when {
            "win" in os -> System.getenv("APPDATA")?.takeIf { it.isNotBlank() } ?: "$home\\AppData\\Roaming"
            "mac" in os -> "$home/Library/Application Support"
            else -> System.getenv("XDG_DATA_HOME")?.takeIf { it.isNotBlank() } ?: "$home/.local/share"
        }
        File(base, if ("win" in os || "mac" in os) "Nuva" else "nuva").also { d ->
            d.mkdirs()
            ownerOnly(d, dir = true)
        }
    }

    override val secrets: SecretStore = FileSecretStore(File(dir, "account.bin"))

    override fun createSqlDriver(): SqlDriver {
        val driver = JdbcSqliteDriver("jdbc:sqlite:${File(dir, "nuva.db").absolutePath}")
        // JDBC-драйвер сам схему не создаёт. Версию схемы держим в PRAGMA user_version.
        val current = driver.executeQuery(
            identifier = null,
            sql = "PRAGMA user_version",
            mapper = { c -> QueryResult.Value(if (c.next().value) (c.getLong(0) ?: 0L) else 0L) },
            parameters = 0,
        ).value
        val target = NuvaDatabase.Schema.version
        when {
            current == 0L -> NuvaDatabase.Schema.create(driver)
            current < target -> NuvaDatabase.Schema.migrate(driver, current, target)
        }
        if (current != target) driver.execute(null, "PRAGMA user_version = $target", 0)
        ownerOnly(File(dir, "nuva.db"), dir = false)
        return driver
    }

    override fun createHttpClient(): HttpClient = HttpClient(OkHttp) {
        install(WebSockets)
        engine {
            config {
                connectTimeout(15, TimeUnit.SECONDS)
                readTimeout(0, TimeUnit.SECONDS)
                retryOnConnectionFailure(true)
            }
        }
    }

    private var lockFile: RandomAccessFile? = null
    private var lock: FileLock? = null

    /** false — Nuva уже запущена под этим пользователем. Блокировку снимает ОС при выходе процесса. */
    fun acquireSingleInstanceLock(): Boolean = try {
        val raf = RandomAccessFile(File(dir, "nuva.lock"), "rw")
        val l = raf.channel.tryLock()
        if (l == null) { raf.close(); false } else { lockFile = raf; lock = l; true }
    } catch (e: Exception) {
        true // не смогли проверить — лучше запуститься, чем не пустить пользователя
    }
}

/**
 * Секреты на десктопе лежат файлом, доступным только владельцу (0600 / папка пользователя).
 * Это защита уровня учётки ОС, а не шифрование: честный аналог Keystore (DPAPI / libsecret) — следующий шаг.
 */
private class FileSecretStore(private val file: File) : SecretStore {
    private val lock = Any()

    override fun read(): ByteArray? = synchronized(lock) { if (file.isFile) file.readBytes() else null }

    override fun write(data: ByteArray): Unit = synchronized(lock) {
        val tmp = File(file.parentFile, file.name + ".tmp")
        tmp.outputStream().use { out -> out.write(data); out.fd.sync() }
        ownerOnly(tmp, dir = false)
        // Атомарная замена: при сбое остаётся либо старый файл целиком, либо новый целиком.
        Files.move(tmp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING)
    }

    override fun clear(): Unit = synchronized(lock) {
        file.delete()
        File(file.parentFile, file.name + ".tmp").delete()
    }
}

private fun ownerOnly(f: File, dir: Boolean) {
    try {
        Files.setPosixFilePermissions(f.toPath(), PosixFilePermissions.fromString(if (dir) "rwx------" else "rw-------"))
    } catch (_: UnsupportedOperationException) {
        // Windows: права наследуются от профиля пользователя (ACL), отдельно ничего не делаем.
    } catch (_: Exception) {
    }
}
