import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    alias(libs.plugins.kotlin.multiplatform)
    alias(libs.plugins.android.library)
    alias(libs.plugins.sqldelight)
}

val serverHost = rootProject.extra["nuvaServerHost"] as String
val appVersionName = rootProject.extra["nuvaVersionName"] as String
val appVersionCode = rootProject.extra["nuvaVersionCode"] as Int

// BuildInfo.kt: хост сервера и версия, зашитые при сборке. Хост входит в подписи (§4.1),
// поэтому пустой/кривой хост — ошибка сборки, а не «тихо сломанный» клиент.
val generateBuildInfo by tasks.registering {
    val outDir = layout.buildDirectory.dir("generated/buildinfo/kotlin")
    inputs.property("host", serverHost)
    inputs.property("versionName", appVersionName)
    inputs.property("versionCode", appVersionCode)
    outputs.dir(outDir)
    doLast {
        require(serverHost.isNotEmpty()) {
            "NUVA_SERVER_HOST is not set: export NUVA_SERVER_HOST=api.example.org " +
                "(CI: Settings → Secrets and variables → Actions → Variables) or set nuva.serverHost"
        }
        require(Regex("^[a-z0-9]([a-z0-9.-]*[a-z0-9])?(:[0-9]{1,5})?$").matches(serverHost)) {
            "NUVA_SERVER_HOST must be a bare host like api.example.org (no scheme, no path): '$serverHost'"
        }
        val f = outDir.get().file("app/nuva/core/BuildInfo.kt").asFile
        f.parentFile.mkdirs()
        f.writeText(
            """
            |package app.nuva.core
            |
            |/** Сгенерировано Gradle (core/build.gradle.kts). Не редактировать. */
            |public object BuildInfo {
            |    public const val SERVER_HOST: String = "$serverHost"
            |    public const val VERSION_NAME: String = "$appVersionName"
            |    public const val VERSION_CODE: Int = $appVersionCode
            |}
            |""".trimMargin()
        )
    }
}

kotlin {
    androidTarget {
        compilerOptions { jvmTarget.set(JvmTarget.JVM_17) }
    }
    jvm("desktop") {
        compilerOptions { jvmTarget.set(JvmTarget.JVM_17) }
    }

    sourceSets {
        all {
            languageSettings.optIn("kotlin.ExperimentalUnsignedTypes")
        }
        commonMain {
            kotlin.srcDir(generateBuildInfo)
            dependencies {
                api(libs.coroutines.core)
                api(libs.datetime)
                api(libs.ktor.client.core)
                api(libs.ktor.client.websockets)
                implementation(libs.serialization.json)
                implementation(libs.libsodium)
                implementation(libs.sqldelight.coroutines)
            }
        }
        androidMain.dependencies {
            api(libs.sqldelight.android)
        }
        val desktopMain by getting {
            dependencies {
                api(libs.sqldelight.jvm)
            }
        }
        commonTest.dependencies {
            implementation(kotlin("test"))
        }
    }
}

android {
    namespace = "app.nuva.core"
    compileSdk = libs.versions.androidCompileSdk.get().toInt()
    defaultConfig {
        minSdk = libs.versions.androidMinSdk.get().toInt()
        consumerProguardFiles("consumer-rules.pro")
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

sqldelight {
    databases {
        create("NuvaDatabase") {
            packageName.set("app.nuva.db")
        }
    }
}

// Эталонные векторы сервера (server/tools/test-vectors.json) — клиент обязан совпасть байт-в-байт.
tasks.withType<Test>().configureEach {
    systemProperty("nuva.vectors", rootProject.file("../server/tools/test-vectors.json").absolutePath)
}
