# libsodium через JNA: классы ищутся рефлексией.
-keep class com.sun.jna.** { *; }
-keep class * implements com.sun.jna.** { *; }
-keep class com.ionspin.kotlin.crypto.** { *; }
-dontwarn java.awt.**
