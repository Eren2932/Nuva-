package app.nuva.core

import app.nuva.core.chat.Messenger
import app.nuva.core.crypto.Identity
import app.nuva.core.crypto.NuvaCrypto
import app.nuva.core.net.NotConnectedException
import app.nuva.core.net.NuvaSocket
import app.nuva.core.net.RegistrationResult
import app.nuva.core.net.Registration
import app.nuva.core.net.isAuthed
import app.nuva.core.proto.Frames
import app.nuva.core.proto.ServerFrame
import app.nuva.core.store.Account
import app.nuva.core.store.AccountStore
import app.nuva.db.NuvaDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

public sealed interface InitResult {
    public class Ready(public val hasAccount: Boolean) : InitResult
    public class CryptoUnavailable(public val reason: String) : InitResult
}

/** Корень ядра: одна штука на процесс. UI говорит только с ним. */
public class NuvaCore(private val platform: Platform, private val scope: CoroutineScope) {
    public val serverHost: String = BuildInfo.SERVER_HOST
    public val versionName: String = BuildInfo.VERSION_NAME

    private val http by lazy { platform.createHttpClient() }
    private val db by lazy { NuvaDatabase(platform.createSqlDriver()) }
    private val accounts = AccountStore(platform.secrets)
    public val socket: NuvaSocket by lazy { NuvaSocket(http, serverHost, scope) }

    private val _account = MutableStateFlow<Account?>(null)
    public val account: StateFlow<Account?> = _account.asStateFlow()

    private val _messenger = MutableStateFlow<Messenger?>(null)
    public val messenger: StateFlow<Messenger?> = _messenger.asStateFlow()

    private var sessionScope: CoroutineScope? = null

    public suspend fun init(): InitResult = withContext(platform.io) {
        try {
            NuvaCrypto.init()
            NuvaCrypto.random(1) // проверяем, что нативная libsodium реально загрузилась
        } catch (e: Throwable) {
            return@withContext InitResult.CryptoUnavailable(e.message ?: e::class.simpleName ?: "libsodium")
        }
        val acc = accounts.load()
        if (acc != null) activate(acc)
        InitResult.Ready(acc != null)
    }

    /** Ключи генерируются здесь, на устройстве. На сервер уходят только публичные. */
    public suspend fun generateIdentity(): Identity = withContext(platform.io) { Identity.generate() }

    public suspend fun register(
        identity: Identity, invite: String, username: String, firstName: String, lastName: String,
    ): RegistrationResult {
        val r = Registration(http, serverHost, platform.name).register(identity, invite, username, firstName, lastName)
        if (r is RegistrationResult.Success) {
            withContext(platform.io) {
                accounts.save(r.account)
                db.nuvaQueries.wipeAll() // на случай остатков от прошлой учётки
            }
            activate(r.account)
        }
        return r
    }

    /** Повторная регистрация: сервер не признаёт устройство (например, новый сервер с чистой БД). */
    public suspend fun resetLocal() {
        socket.stop()
        sessionScope?.cancel()
        sessionScope = null
        _messenger.value = null
        withContext(platform.io) {
            accounts.clear()
            db.nuvaQueries.wipeAll()
        }
        _account.value = null
    }

    /** Приложение вернулось на передний план / сеть появилась. */
    public fun onForeground() {
        if (_account.value != null) socket.reconnectNow()
    }

    private fun activate(acc: Account) {
        _account.value = acc
        val s = CoroutineScope(scope.coroutineContext + SupervisorJob(scope.coroutineContext[Job]))
        sessionScope = s
        val m = Messenger(acc, db, socket, platform.io, s)
        m.start()
        _messenger.value = m
        socket.start(acc)
        if (acc.profilePending) s.launch { syncProfile() }
    }

    /** Досылаем имя, если после регистрации profile.set не дошёл. */
    private suspend fun syncProfile() {
        while (true) {
            socket.state.filter { it.isAuthed }.first()
            val acc = _account.value ?: return
            val r = try {
                socket.request { Frames.profileSet(it, acc.firstName, acc.lastName) }
            } catch (e: NotConnectedException) {
                delay(2_000)
                continue
            }
            if (r is ServerFrame.ProfileOk) {
                val updated = acc.copy(firstName = r.firstName, lastName = r.lastName, profilePending = false)
                withContext(platform.io) { accounts.save(updated) }
                _account.value = updated
            }
            return
        }
    }
}
