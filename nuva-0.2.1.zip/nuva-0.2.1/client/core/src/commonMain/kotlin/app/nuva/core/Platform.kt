package app.nuva.core

import app.cash.sqldelight.db.SqlDriver
import io.ktor.client.HttpClient
import kotlinx.coroutines.CoroutineDispatcher

/** Всё платформенное, что нужно ядру. Реализации — в app-android и app-desktop. */
public interface Platform {
    /** Значение поля device.platform при регистрации: "android" | "desktop". */
    public val name: String

    /** Диспетчер для блокирующего I/O (SQLite, файлы). */
    public val io: CoroutineDispatcher

    /** Хранилище секретов устройства (ключи). Android — Keystore, desktop — файл 0600. */
    public val secrets: SecretStore

    /** Драйвер SQLite с уже применённой схемой NuvaDatabase. */
    public fun createSqlDriver(): SqlDriver

    /** HTTP-клиент с установленным плагином WebSockets. */
    public fun createHttpClient(): HttpClient
}

public interface SecretStore {
    public fun read(): ByteArray?
    public fun write(data: ByteArray)
    public fun clear()
}
