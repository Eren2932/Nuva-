package app.nuva.core.chat

import app.cash.sqldelight.coroutines.asFlow
import app.cash.sqldelight.coroutines.mapToList
import app.cash.sqldelight.coroutines.mapToOneOrNull
import app.nuva.core.crypto.CryptoException
import app.nuva.core.crypto.NuvaCrypto
import app.nuva.core.net.NotConnectedException
import app.nuva.core.net.NuvaSocket
import app.nuva.core.net.isAuthed
import app.nuva.core.proto.ErrorCodes
import app.nuva.core.proto.Frames
import app.nuva.core.proto.RemoteAccount
import app.nuva.core.proto.ServerFrame
import app.nuva.core.store.Account
import app.nuva.core.util.Uuids
import app.nuva.db.Device
import app.nuva.db.NuvaDatabase
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.datetime.Clock
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.longOrNull

/**
 * Переписка 1:1 поверх store-and-forward сервера.
 *
 * Гарантии: исходящие — в локальной очереди (status=PENDING) до msg.sent, повтор идемпотентен
 * по client_msg_id; входящие — ack только ПОСЛЕ записи в БД (at-least-once + дедуп по
 * (peer, client_msg_id)). Доставку подтверждает зашифрованная квитанция "rcpt" от получателя:
 * сервер не отличает её от обычного сообщения.
 */
public class Messenger(
    private val account: Account,
    private val db: NuvaDatabase,
    private val socket: NuvaSocket,
    private val io: CoroutineDispatcher,
    private val scope: CoroutineScope,
) {
    private val q get() = db.nuvaQueries
    private val json = Json { ignoreUnknownKeys = true }

    /** Открытый сейчас чат: входящие в него не увеличивают счётчик непрочитанных. */
    public val activeChat: MutableStateFlow<String?> = MutableStateFlow(null)

    private val outboxKick = Channel<Unit>(Channel.CONFLATED)
    private val acks = Channel<Long>(Channel.UNLIMITED)
    private val receipts = Channel<Pair<String, String>>(Channel.UNLIMITED)

    public fun start() {
        scope.launch { processDeliveries() }
        scope.launch { ackLoop() }
        scope.launch { receiptLoop() }
        scope.launch { outboxLoop() }
        scope.launch { socket.state.collect { if (it.isAuthed) outboxKick.trySend(Unit) } }
    }

    // ─────────────── Наблюдаемые данные для UI ───────────────

    public fun chats(): Flow<List<ChatSummary>> =
        q.chatList { peerId, lastText, lastTs, lastOutgoing, lastStatus, unread, username, firstName, lastName ->
            ChatSummary(peerId, username, firstName, lastName, lastText, lastTs, lastOutgoing == 1L,
                MsgStatus.of(lastStatus), unread.toInt())
        }.asFlow().mapToList(io)

    public fun messages(peerId: String, limit: Long): Flow<List<ChatMessage>> =
        q.messagesFor(peerId, limit) { localId, _, clientMsgId, outgoing, body, ts, _, status ->
            ChatMessage(localId, clientMsgId, outgoing == 1L, body, ts, MsgStatus.of(status))
        }.asFlow().mapToList(io)

    public fun peer(peerId: String): Flow<Peer?> =
        q.contactById(peerId) { accountId, username, firstName, lastName, identityKey, keyChanged, _ ->
            Peer(accountId, username, firstName, lastName, identityKey, keyChanged == 1L)
        }.asFlow().mapToOneOrNull(io)

    // ─────────────── Поиск и контакты ───────────────

    public suspend fun lookup(username: String): LookupResult {
        val name = username.trim().removePrefix("@").lowercase()
        if (!Limits.USERNAME.matches(name)) return LookupResult.NotFound
        if (!socket.state.value.isAuthed) return LookupResult.Offline
        val r = try {
            socket.request { Frames.lookupUsername(it, name) }
        } catch (e: NotConnectedException) {
            return LookupResult.Offline
        }
        return when (r) {
            is ServerFrame.UserInfo -> verified(r.account)?.let { LookupResult.Found(it) } ?: LookupResult.NotFound
            is ServerFrame.Error -> if (r.code == ErrorCodes.RATE_LIMITED) LookupResult.RateLimited else LookupResult.NotFound
            else -> LookupResult.NotFound
        }
    }

    /** «Написать»: закрепляем ключи собеседника (TOFU) и создаём чат. */
    public suspend fun openChat(remote: RemoteAccount): String {
        savePeer(remote, accept = false)
        withContext(io) { q.ensureChat(remote.accountId) }
        return remote.accountId
    }

    /** Пользователь сверил код безопасности / согласился с новым ключом собеседника. */
    public suspend fun acceptKeyChange(peerId: String): Boolean {
        val remote = fetchAccount(peerId) ?: return false
        savePeer(remote, accept = true)
        return true
    }

    public fun safetyNumber(peer: Peer): String = NuvaCrypto.safetyNumber(account.identity.ikPub, peer.identityKey)

    public suspend fun markRead(peerId: String) {
        withContext(io) { q.markRead(peerId) }
    }

    // ─────────────── Отправка ───────────────

    public suspend fun sendText(peerId: String, text: String) {
        val body = text.trim().take(Limits.MAX_TEXT)
        if (body.isEmpty()) return
        val cmid = newMsgId()
        val ts = now()
        withContext(io) {
            db.transaction {
                q.ensureChat(peerId)
                q.insertMessage(peerId, cmid, 1L, body, ts, null, MsgStatus.PENDING.code)
                refreshChatLast(peerId)
            }
        }
        outboxKick.trySend(Unit)
    }

    public suspend fun retry(peerId: String, clientMsgId: String) {
        withContext(io) {
            db.transaction {
                q.retryFailed(peerId, clientMsgId)
                refreshChatLast(peerId)
            }
        }
        outboxKick.trySend(Unit)
    }

    private suspend fun outboxLoop() {
        for (kick in outboxKick) {
            if (socket.state.value.isAuthed) drainOutbox()
        }
    }

    private suspend fun drainOutbox() {
        val done = HashSet<Long>()
        while (true) {
            val batch = withContext(io) { q.pendingOutgoing().executeAsList() }.filter { it.local_id !in done }
            if (batch.isEmpty()) return
            for (m in batch) {
                done += m.local_id
                val plain = textPlaintext(m.ts, m.body)
                when (val r = deliverEncrypted(m.peer_id, m.client_msg_id, plain)) {
                    is SendResult.Sent -> withContext(io) {
                        db.transaction {
                            q.setSent(r.serverTs, m.peer_id, m.client_msg_id)
                            refreshChatLast(m.peer_id)
                        }
                    }
                    SendResult.NotFound, is SendResult.Rejected -> withContext(io) {
                        db.transaction {
                            q.setFailed(m.peer_id, m.client_msg_id)
                            refreshChatLast(m.peer_id)
                        }
                    }
                    SendResult.RateLimited -> {
                        scope.launch { delay(10_000); outboxKick.trySend(Unit) }
                        return
                    }
                    SendResult.Offline -> return // повторим при следующем входе (state → authed)
                }
            }
        }
    }

    private sealed interface SendResult {
        class Sent(val serverTs: Long) : SendResult
        data object NotFound : SendResult
        data object RateLimited : SendResult
        data object Offline : SendResult
        class Rejected(val code: String) : SendResult
    }

    /** Шифрует под каждое активное устройство получателя; при devices_mismatch обновляет список и повторяет. */
    private suspend fun deliverEncrypted(peerId: String, cmid: String, plaintext: ByteArray): SendResult {
        var devices = withContext(io) { q.devicesFor(peerId).executeAsList() }
        if (devices.isEmpty()) devices = refreshPeer(peerId) ?: return SendResult.Offline
        repeat(2) {
            if (devices.isEmpty()) return SendResult.NotFound
            val envelopes = devices.map { d ->
                d.device_id to NuvaCrypto.seal(
                    account.identity.xkPriv, d.x25519_key, account.deviceId, d.device_id, cmid, plaintext,
                )
            }
            val r = try {
                socket.request { id -> Frames.msgSend(id, peerId, cmid, envelopes) }
            } catch (e: NotConnectedException) {
                return SendResult.Offline
            }
            when (r) {
                is ServerFrame.MsgSent -> return SendResult.Sent(r.serverTs)
                is ServerFrame.Error -> when (r.code) {
                    ErrorCodes.DEVICES_MISMATCH -> devices = refreshPeer(peerId) ?: return SendResult.Offline
                    ErrorCodes.NOT_FOUND -> return SendResult.NotFound
                    ErrorCodes.RATE_LIMITED -> return SendResult.RateLimited
                    else -> return SendResult.Rejected(r.code)
                }
                else -> return SendResult.Rejected("unexpected")
            }
        }
        return SendResult.Rejected(ErrorCodes.DEVICES_MISMATCH)
    }

    // ─────────────── Приём ───────────────

    private suspend fun processDeliveries() {
        for (d in socket.deliveries) {
            try {
                handleDeliver(d)
            } catch (e: CancellationException) {
                throw e
            } catch (e: NotConnectedException) {
                // без ack: сервер выдаст конверт повторно при следующем входе
            } catch (e: Exception) {
                acks.send(d.serverId) // «ядовитый» конверт не должен блокировать очередь вечно
            }
        }
    }

    private suspend fun handleDeliver(d: ServerFrame.Deliver) {
        val from = d.fromAccount
        val fromDevice = d.fromDevice
        if (from == null || fromDevice == null || fromDevice == account.deviceId) {
            acks.send(d.serverId)
            return
        }
        val plain = openFrom(from, fromDevice, d) ?: run {
            acks.send(d.serverId)
            return
        }
        val obj = try {
            json.parseToJsonElement(plain.decodeToString()).jsonObject
        } catch (e: Exception) {
            null
        }
        when ((obj?.get("t") as? JsonPrimitive)?.contentOrNull) {
            "text" -> {
                val body = (obj!!["body"] as? JsonPrimitive)?.contentOrNull.orEmpty().take(Limits.MAX_TEXT * 4)
                val sentTs = (obj["ts"] as? JsonPrimitive)?.longOrNull
                val ts = if (sentTs == null || sentTs <= 0 || sentTs > now() + DAY_MS) d.serverTs else sentTs
                if (body.isNotEmpty()) storeIncoming(from, d.clientMsgId, body, ts, d.serverTs)
                receipts.send(from to d.clientMsgId)
            }
            "rcpt" -> {
                val ids = (obj!!["ids"] as? JsonArray).orEmpty()
                    .mapNotNull { (it as? JsonPrimitive)?.contentOrNull }.take(500)
                if (ids.isNotEmpty()) withContext(io) {
                    db.transaction {
                        q.markDelivered(from, ids)
                        refreshChatLast(from)
                    }
                }
            }
            else -> Unit // неизвестный тип из будущей версии — молча пропускаем
        }
        acks.send(d.serverId)
    }

    /** Ключи отправителя: из кэша; если устройство незнакомо или ключ сменился — свежий lookup. */
    private suspend fun openFrom(from: String, fromDevice: String, d: ServerFrame.Deliver): ByteArray? {
        suspend fun device(): Device? = withContext(io) { q.deviceById(fromDevice).executeAsOneOrNull() }
            ?.takeIf { it.account_id == from }

        fun tryOpen(dev: Device): ByteArray? = try {
            NuvaCrypto.open(account.identity.xkPriv, dev.x25519_key, fromDevice, account.deviceId, d.clientMsgId, d.envelope)
        } catch (e: CryptoException) {
            null
        }

        device()?.let { dev -> tryOpen(dev)?.let { return it } }
        refreshPeer(from) ?: throw NotConnectedException()
        return device()?.let { tryOpen(it) }
    }

    private suspend fun storeIncoming(from: String, cmid: String, body: String, ts: Long, serverTs: Long) {
        val open = activeChat.value == from
        withContext(io) {
            db.transaction {
                q.ensureChat(from)
                if (q.countMessage(from, 0L, cmid).executeAsOne() == 0L) {
                    q.insertMessage(from, cmid, 0L, body, ts, serverTs, MsgStatus.INCOMING.code)
                    if (!open) q.incUnread(from)
                    refreshChatLast(from)
                }
            }
        }
    }

    private suspend fun ackLoop() {
        val buf = ArrayList<Long>()
        while (true) {
            buf += acks.receive()
            withTimeoutOrNull(300) { while (buf.size < 100) buf += acks.receive() }
            socket.sendNoReply(Frames.msgAck(buf.toList())) // нет связи — сервер передоставит, дедуп спасёт
            buf.clear()
        }
    }

    private suspend fun receiptLoop() {
        while (true) {
            val byPeer = LinkedHashMap<String, MutableList<String>>()
            fun add(p: Pair<String, String>) = byPeer.getOrPut(p.first) { ArrayList() }.add(p.second)
            add(receipts.receive())
            withTimeoutOrNull(700) { while (true) add(receipts.receive()) }
            for ((peer, ids) in byPeer) {
                for (chunk in ids.distinct().chunked(200)) {
                    deliverEncrypted(peer, newMsgId(), receiptPlaintext(chunk)) // best effort
                }
            }
        }
    }

    // ─────────────── Синхронизация ключей собеседника ───────────────

    /** null — нет связи; пустой список — аккаунта больше нет. */
    private suspend fun refreshPeer(peerId: String): List<Device>? {
        val remote = try {
            fetchAccountOrThrow(peerId)
        } catch (e: NotConnectedException) {
            return null
        }
        if (remote == null) {
            withContext(io) { q.deleteDevices(peerId) }
            return emptyList()
        }
        savePeer(remote, accept = false)
        return withContext(io) { q.devicesFor(peerId).executeAsList() }
    }

    private suspend fun fetchAccount(peerId: String): RemoteAccount? = try {
        fetchAccountOrThrow(peerId)
    } catch (e: NotConnectedException) {
        null
    }

    private suspend fun fetchAccountOrThrow(peerId: String): RemoteAccount? =
        when (val r = socket.request { Frames.lookupAccount(it, peerId) }) {
            is ServerFrame.UserInfo -> verified(r.account)
            is ServerFrame.Error -> if (r.code == ErrorCodes.NOT_FOUND) null else throw NotConnectedException(r.code)
            else -> throw NotConnectedException("unexpected")
        }

    /** Оставляем только устройства с валидной подписью X25519-ключа их identity-ключом. */
    private fun verified(a: RemoteAccount): RemoteAccount? {
        val ok = a.devices.filter { d ->
            d.identityKey.size == 32 && d.x25519Key.size == 32 &&
                NuvaCrypto.verify(d.identityKey, NuvaCrypto.xkPayload(d.x25519Key), d.x25519Sig)
        }
        if (ok.isEmpty() || !Uuids.isValid(a.accountId) || ok.any { !Uuids.isValid(it.deviceId) }) return null
        return RemoteAccount(a.accountId, a.username, a.firstName, a.lastName, ok)
    }

    private suspend fun savePeer(remote: RemoteAccount, accept: Boolean) {
        val primary = remote.devices.first().identityKey
        withContext(io) {
            db.transaction {
                val existing = q.contactById(remote.accountId).executeAsOneOrNull()
                val changed = !accept && existing != null &&
                    (existing.key_changed == 1L || !existing.identity_key.contentEquals(primary))
                val pinned = if (existing == null || accept) primary else existing.identity_key
                q.upsertContact(remote.accountId, remote.username, remote.firstName, remote.lastName,
                    pinned, if (changed) 1L else 0L, now())
                q.deleteDevices(remote.accountId)
                for (d in remote.devices) q.insertDevice(d.deviceId, remote.accountId, d.identityKey, d.x25519Key)
            }
        }
    }

    // ─────────────── helpers ───────────────

    /** Вызывать внутри транзакции. */
    private fun refreshChatLast(peerId: String) {
        val m = q.lastMessage(peerId).executeAsOneOrNull() ?: return
        q.setChatLast(m.body, m.ts, m.outgoing, m.status, peerId)
    }

    private fun textPlaintext(ts: Long, body: String): ByteArray = JsonObject(linkedMapOf(
        "v" to JsonPrimitive(1), "t" to JsonPrimitive("text"), "ts" to JsonPrimitive(ts), "body" to JsonPrimitive(body),
    )).toString().encodeToByteArray()

    private fun receiptPlaintext(ids: List<String>): ByteArray = JsonObject(linkedMapOf(
        "v" to JsonPrimitive(1), "t" to JsonPrimitive("rcpt"), "ts" to JsonPrimitive(now()),
        "ids" to JsonArray(ids.map { JsonPrimitive(it) }),
    )).toString().encodeToByteArray()

    private fun newMsgId(): String = Uuids.v7(now(), NuvaCrypto.random(10))

    private fun now(): Long = Clock.System.now().toEpochMilliseconds()

    private companion object {
        const val DAY_MS = 86_400_000L
    }
}
