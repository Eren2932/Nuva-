package app.nuva.core.chat

public enum class MsgStatus(public val code: Long) {
    PENDING(0), SENT(1), DELIVERED(2), FAILED(3), INCOMING(10);

    public companion object {
        public fun of(code: Long): MsgStatus = entries.firstOrNull { it.code == code } ?: INCOMING
    }
}

public data class ChatSummary(
    val peerId: String,
    val username: String,
    val firstName: String,
    val lastName: String,
    val lastText: String,
    val lastTs: Long,
    val lastOutgoing: Boolean,
    val lastStatus: MsgStatus,
    val unread: Int,
) {
    val title: String get() = displayName(firstName, lastName, username)
}

public data class ChatMessage(
    val localId: Long,
    val clientMsgId: String,
    val outgoing: Boolean,
    val body: String,
    val ts: Long,
    val status: MsgStatus,
)

public class Peer(
    public val accountId: String,
    public val username: String,
    public val firstName: String,
    public val lastName: String,
    public val identityKey: ByteArray,
    public val keyChanged: Boolean,
) {
    public val title: String get() = displayName(firstName, lastName, username)
}

/** Результат поиска: найденный аккаунт ещё не сохранён — сохраняем только при «Написать». */
public sealed interface LookupResult {
    public class Found(public val account: app.nuva.core.proto.RemoteAccount) : LookupResult {
        public val title: String get() = displayName(account.firstName, account.lastName, account.username)
    }
    public data object NotFound : LookupResult
    public data object RateLimited : LookupResult
    public data object Offline : LookupResult
}

public fun displayName(first: String, last: String, username: String): String =
    listOf(first, last).filter { it.isNotBlank() }.joinToString(" ").ifBlank { "@$username" }

public object Limits {
    /** Как у Telegram: длинный текст режется на стороне UI. С запасом влезает в конверт 64 КиБ. */
    public const val MAX_TEXT: Int = 4096
    public val USERNAME: Regex = Regex("^[a-z0-9_]{3,32}$")
    public const val NAME_MAX: Int = 64
}
