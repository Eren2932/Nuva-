package app.nuva.core.crypto

import app.nuva.core.util.Uuids
import app.nuva.core.util.compareUnsigned
import app.nuva.core.util.concat

public class CryptoException(message: String) : Exception(message)

/**
 * Криптография v1 — побайтовое зеркало server/tools/vectors.py (эталон).
 * Любое расхождение ловит VectorsTest (desktopTest) на тех же test-vectors.json.
 */
public object NuvaCrypto {
    private val SEP = byteArrayOf(0)
    private val LABEL_XK = "NUVA-XK-V1".encodeToByteArray()
    private val LABEL_AUTH = "NUVA-AUTH-V1".encodeToByteArray()
    private val LABEL_REG = "NUVA-REG-V1".encodeToByteArray()
    private val LABEL_MSG = "NUVA-MSG-V1".encodeToByteArray()
    private val LABEL_SN = "NUVA-SN-V1".encodeToByteArray()

    public const val ENVELOPE_VERSION: Int = 0x01
    public const val PAD_BLOCK: Int = 256
    public const val KEY_LEN: Int = 32
    public const val NONCE_LEN: Int = 24
    public const val TAG_LEN: Int = 16
    public const val HEADER_LEN: Int = 1 + 32 + NONCE_LEN // 57

    /** Инициализация libsodium. Вызывать один раз до любых операций (дёшево при повторе). */
    public suspend fun init(): Unit = Sodium.init()

    public fun random(n: Int): ByteArray = Sodium.random(n)

    // ─────────────── HMAC / HKDF (RFC 2104 / RFC 5869) поверх SHA-256 libsodium ───────────────

    public fun hmacSha256(key: ByteArray, data: ByteArray): ByteArray {
        val block = 64
        val k0 = (if (key.size > block) Sodium.sha256(key) else key).copyOf(block)
        val ipad = ByteArray(block) { (k0[it].toInt() xor 0x36).toByte() }
        val opad = ByteArray(block) { (k0[it].toInt() xor 0x5c).toByte() }
        return Sodium.sha256(concat(opad, Sodium.sha256(concat(ipad, data))))
    }

    public fun hkdfExtract(salt: ByteArray, ikm: ByteArray): ByteArray =
        hmacSha256(if (salt.isEmpty()) ByteArray(32) else salt, ikm)

    public fun hkdfExpand(prk: ByteArray, info: ByteArray, length: Int): ByteArray {
        require(length in 1..255 * 32) { "HKDF-SHA256: L must be in 1..8160" }
        val okm = ByteArray(length)
        var prev = ByteArray(0)
        var off = 0
        var counter = 1
        while (off < length) {
            prev = hmacSha256(prk, concat(prev, info, byteArrayOf(counter.toByte())))
            val n = minOf(prev.size, length - off)
            prev.copyInto(okm, off, 0, n)
            off += n
            counter++
        }
        return okm
    }

    public fun hkdf(salt: ByteArray, ikm: ByteArray, info: ByteArray, length: Int): ByteArray =
        hkdfExpand(hkdfExtract(salt, ikm), info, length)

    // ─────────────── Ключи и подписи ───────────────

    public fun x25519Public(priv: ByteArray): ByteArray = Sodium.x25519Base(priv)

    /** X25519 с отказом на нулевом результате (точка малого порядка). */
    public fun x25519(priv: ByteArray, pub: ByteArray): ByteArray {
        if (priv.size != 32 || pub.size != 32) throw CryptoException("bad X25519 key length")
        val shared = try {
            Sodium.x25519(priv, pub)
        } catch (e: Exception) {
            throw CryptoException("X25519 failed")
        }
        var acc = 0
        for (b in shared) acc = acc or b.toInt()
        if (acc == 0) throw CryptoException("X25519 produced all-zero output")
        return shared
    }

    public fun verify(publicKey: ByteArray, message: ByteArray, signature: ByteArray): Boolean =
        Sodium.verify(publicKey, message, signature)

    // ─────────────── Payload-ы подписей (§4.1) ───────────────

    public fun xkPayload(xkPub: ByteArray): ByteArray = concat(LABEL_XK, SEP, xkPub)

    public fun authPayload(host: String, deviceId: String, nonce: ByteArray): ByteArray =
        concat(LABEL_AUTH, SEP, ascii(host), SEP, Uuids.toBytes(deviceId), nonce)

    public fun regPayload(host: String, nonce: ByteArray, ikPub: ByteArray, xkPub: ByteArray, username: String): ByteArray =
        concat(LABEL_REG, SEP, ascii(host), SEP, nonce, ikPub, xkPub, username.encodeToByteArray())

    public fun msgInfo(senderDevice: String, recipientDevice: String, ePub: ByteArray): ByteArray =
        concat(LABEL_MSG, Uuids.toBytes(senderDevice), Uuids.toBytes(recipientDevice), ePub)

    public fun msgAd(senderDevice: String, recipientDevice: String, clientMsgId: String, ePub: ByteArray): ByteArray =
        concat(
            LABEL_MSG, SEP, byteArrayOf(ENVELOPE_VERSION.toByte()), Uuids.toBytes(senderDevice),
            Uuids.toBytes(recipientDevice), Uuids.toBytes(clientMsgId), ePub,
        )

    private fun ascii(s: String): ByteArray {
        require(s.all { it.code in 0x20..0x7e }) { "host must be ASCII" }
        return s.encodeToByteArray()
    }

    // ─────────────── Паддинг ISO/IEC 7816-4 (как sodium_pad/sodium_unpad) ───────────────

    public fun pad(data: ByteArray, block: Int = PAD_BLOCK): ByteArray {
        val padded = ByteArray((data.size / block + 1) * block)
        data.copyInto(padded)
        padded[data.size] = 0x80.toByte()
        return padded
    }

    public fun unpad(padded: ByteArray, block: Int = PAD_BLOCK): ByteArray {
        if (padded.isEmpty() || padded.size % block != 0) throw CryptoException("bad padded length")
        var i = padded.size - 1
        val stop = padded.size - block
        while (i >= stop && padded[i].toInt() == 0) i--
        if (i < stop || padded[i] != 0x80.toByte()) throw CryptoException("bad padding")
        return padded.copyOf(i)
    }

    // ─────────────── Конверт v1 (Noise K: e, es, ss) ───────────────

    /** [ePriv]/[nonce] передаются только тестами (детерминизм векторов); в бою — случайные. */
    public fun seal(
        senderXkPriv: ByteArray,
        recipientXkPub: ByteArray,
        senderDevice: String,
        recipientDevice: String,
        clientMsgId: String,
        plaintext: ByteArray,
        ePriv: ByteArray = Sodium.random(32),
        nonce: ByteArray = Sodium.random(NONCE_LEN),
    ): ByteArray {
        require(ePriv.size == 32 && nonce.size == NONCE_LEN) { "bad e_priv / nonce length" }
        val ePub = Sodium.x25519Base(ePriv)
        val es = x25519(ePriv, recipientXkPub)
        val ss = x25519(senderXkPriv, recipientXkPub)
        val key = hkdf(ByteArray(0), concat(es, ss), msgInfo(senderDevice, recipientDevice, ePub), KEY_LEN)
        val ad = msgAd(senderDevice, recipientDevice, clientMsgId, ePub)
        val ct = Sodium.aeadEncrypt(pad(plaintext), ad, nonce, key)
        return concat(byteArrayOf(ENVELOPE_VERSION.toByte()), ePub, nonce, ct)
    }

    public fun open(
        recipientXkPriv: ByteArray,
        senderXkPub: ByteArray,
        senderDevice: String,
        recipientDevice: String,
        clientMsgId: String,
        envelope: ByteArray,
    ): ByteArray {
        if (envelope.size < HEADER_LEN + TAG_LEN + PAD_BLOCK) throw CryptoException("envelope too short")
        if (envelope[0].toInt() != ENVELOPE_VERSION) throw CryptoException("unsupported envelope version")
        val ePub = envelope.copyOfRange(1, 33)
        val nonce = envelope.copyOfRange(33, HEADER_LEN)
        val ct = envelope.copyOfRange(HEADER_LEN, envelope.size)
        val es = x25519(recipientXkPriv, ePub)
        val ss = x25519(recipientXkPriv, senderXkPub)
        val key = hkdf(ByteArray(0), concat(es, ss), msgInfo(senderDevice, recipientDevice, ePub), KEY_LEN)
        val ad = msgAd(senderDevice, recipientDevice, clientMsgId, ePub)
        val padded = Sodium.aeadDecrypt(ct, ad, nonce, key) ?: throw CryptoException("decryption failed")
        return unpad(padded)
    }

    // ─────────────── Код безопасности (сверка ключей вне канала) ───────────────

    public fun safetyNumber(ikA: ByteArray, ikB: ByteArray): String {
        val (lo, hi) = if (compareUnsigned(ikA, ikB) <= 0) ikA to ikB else ikB to ikA
        val sn = Sodium.sha256(concat(LABEL_SN, SEP, lo, hi))
        return (0 until 30 step 5).joinToString(" ") { i ->
            var v = 0L
            for (j in 0 until 5) v = (v shl 8) or (sn[i + j].toLong() and 0xFF)
            (v % 100000).toString().padStart(5, '0')
        }
    }
}

/** Ключи этого устройства. Ed25519 — из seed (как PyNaCl), X25519 — приватный скаляр. */
public class Identity(public val ikSeed: ByteArray, public val xkPriv: ByteArray) {
    init {
        require(ikSeed.size == 32 && xkPriv.size == 32)
    }

    private val ed = Sodium.ed25519FromSeed(ikSeed)
    public val ikPub: ByteArray get() = ed.first.copyOf()
    public val xkPub: ByteArray = Sodium.x25519Base(xkPriv)

    public fun sign(message: ByteArray): ByteArray = Sodium.sign(message, ed.second)

    public val xkSig: ByteArray by lazy { sign(NuvaCrypto.xkPayload(xkPub)) }

    public companion object {
        public fun generate(): Identity = Identity(Sodium.random(32), Sodium.random(32))
    }
}
