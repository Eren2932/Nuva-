package app.nuva.core.crypto

import com.ionspin.kotlin.crypto.LibsodiumInitializer
import com.ionspin.kotlin.crypto.aead.AuthenticatedEncryptionWithAssociatedData
import com.ionspin.kotlin.crypto.hash.Hash
import com.ionspin.kotlin.crypto.scalarmult.ScalarMultiplication
import com.ionspin.kotlin.crypto.signature.Signature
import com.ionspin.kotlin.crypto.util.LibsodiumRandom

/**
 * Единственное место, где клиент касается libsodium (ionspin bindings).
 * Всё остальное работает с ByteArray — замена/обновление биндингов затрагивает только этот файл.
 */
internal object Sodium {
    suspend fun init() {
        if (!LibsodiumInitializer.isInitialized()) LibsodiumInitializer.initialize()
    }

    fun random(n: Int): ByteArray = LibsodiumRandom.buf(n).asByteArray()

    fun sha256(data: ByteArray): ByteArray = Hash.sha256(data.asUByteArray()).asByteArray()

    /** Ed25519 из 32-байтного seed: (pk 32, sk 64) — как SigningKey(seed) в PyNaCl. */
    fun ed25519FromSeed(seed: ByteArray): Pair<ByteArray, ByteArray> {
        val kp = Signature.seedKeypair(seed.asUByteArray())
        return kp.publicKey.asByteArray() to kp.secretKey.asByteArray()
    }

    fun sign(message: ByteArray, secretKey: ByteArray): ByteArray =
        Signature.detached(message.asUByteArray(), secretKey.asUByteArray()).asByteArray()

    fun verify(publicKey: ByteArray, message: ByteArray, signature: ByteArray): Boolean {
        if (publicKey.size != 32 || signature.size != 64) return false
        return try {
            Signature.verifyDetached(signature.asUByteArray(), message.asUByteArray(), publicKey.asUByteArray())
            true
        } catch (e: Exception) {
            false
        }
    }

    fun x25519Base(priv: ByteArray): ByteArray =
        ScalarMultiplication.scalarMultiplicationBase(priv.asUByteArray()).asByteArray()

    fun x25519(priv: ByteArray, pub: ByteArray): ByteArray =
        ScalarMultiplication.scalarMultiplication(priv.asUByteArray(), pub.asUByteArray()).asByteArray()

    fun aeadEncrypt(message: ByteArray, ad: ByteArray, nonce: ByteArray, key: ByteArray): ByteArray =
        AuthenticatedEncryptionWithAssociatedData.xChaCha20Poly1305IetfEncrypt(
            message.asUByteArray(), ad.asUByteArray(), nonce.asUByteArray(), key.asUByteArray(),
        ).asByteArray()

    fun aeadDecrypt(ciphertext: ByteArray, ad: ByteArray, nonce: ByteArray, key: ByteArray): ByteArray? =
        try {
            AuthenticatedEncryptionWithAssociatedData.xChaCha20Poly1305IetfDecrypt(
                ciphertext.asUByteArray(), ad.asUByteArray(), nonce.asUByteArray(), key.asUByteArray(),
            ).asByteArray()
        } catch (e: Exception) {
            null
        }
}
