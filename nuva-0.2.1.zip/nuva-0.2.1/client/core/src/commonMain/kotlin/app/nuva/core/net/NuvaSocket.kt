package app.nuva.core.net

import app.nuva.core.crypto.NuvaCrypto
import app.nuva.core.proto.ErrorCodes
import app.nuva.core.proto.Frames
import app.nuva.core.proto.ServerFrame
import app.nuva.core.store.Account
import io.ktor.client.HttpClient
import io.ktor.client.plugins.websocket.DefaultClientWebSocketSession
import io.ktor.client.plugins.websocket.webSocket
import io.ktor.client.request.header
import io.ktor.http.HttpHeaders
import io.ktor.websocket.Frame
import io.ktor.websocket.readText
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.channels.ReceiveChannel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.random.Random

public sealed interface SocketState {
    public data object Offline : SocketState
    public data object Connecting : SocketState
    /** Авторизованы, сервер выгружает офлайн-очередь. */
    public data object Syncing : SocketState
    public data object Online : SocketState
    /** Сервер не признаёт устройство (аккаунт удалён / устройство отозвано / сервер сброшен). */
    public data object Rejected : SocketState
}

public val SocketState.isAuthed: Boolean get() = this == SocketState.Syncing || this == SocketState.Online

public class NotConnectedException(message: String = "not connected") : Exception(message)

/**
 * Постоянное WebSocket-соединение: авторизация по challenge, реконнект с экспоненциальной
 * задержкой и джиттером, корреляция запрос/ответ по id, прикладной ping (сервер рвёт молчащих через 60 с).
 */
public class NuvaSocket(
    private val http: HttpClient,
    private val host: String,
    private val scope: CoroutineScope,
) {
    private val url = "wss://$host/ws"

    private val _state = MutableStateFlow<SocketState>(SocketState.Offline)
    public val state: StateFlow<SocketState> = _state.asStateFlow()

    private val _deliveries = Channel<ServerFrame.Deliver>(Channel.UNLIMITED)
    public val deliveries: ReceiveChannel<ServerFrame.Deliver> get() = _deliveries

    private val _synced = MutableSharedFlow<Unit>(extraBufferCapacity = 8)
    /** Срабатывает на каждый queue.empty: офлайн-очередь выгружена. */
    public val synced: SharedFlow<Unit> = _synced.asSharedFlow()

    private val current = MutableStateFlow<DefaultClientWebSocketSession?>(null)
    private val lock = Mutex()
    private val pending = HashMap<String, CompletableDeferred<ServerFrame>>()
    private var counter = 0L
    private val kicks = Channel<Unit>(Channel.CONFLATED)
    private var job: Job? = null

    public fun start(account: Account) {
        if (job?.isActive == true) return
        job = scope.launch { runLoop(account) }
    }

    public suspend fun stop() {
        job?.cancelAndJoin()
        job = null
        current.value = null
        failPending()
        _state.value = SocketState.Offline
    }

    /** Переподключиться немедленно (сеть вернулась, приложение на переднем плане). */
    public fun reconnectNow() {
        kicks.trySend(Unit)
    }

    public suspend fun awaitAuthed() {
        state.first { it.isAuthed }
    }

    /** Запрос с ответом по id. Бросает [NotConnectedException] при обрыве/таймауте. */
    public suspend fun request(timeoutMs: Long = 15_000, build: (id: String) -> String): ServerFrame {
        val ws = current.value ?: throw NotConnectedException()
        val deferred = CompletableDeferred<ServerFrame>()
        val id = lock.withLock {
            val id = "c${++counter}"
            pending[id] = deferred
            id
        }
        try {
            ws.send(Frame.Text(build(id)))
            return withTimeoutOrNull(timeoutMs) { deferred.await() } ?: throw NotConnectedException("timeout")
        } catch (e: NotConnectedException) {
            throw e
        } catch (e: Throwable) {
            currentCoroutineContext().ensureActive()
            throw NotConnectedException(e.message ?: "send failed")
        } finally {
            lock.withLock { pending.remove(id) }
        }
    }

    /** Фрейм без ответа (msg.ack). false — соединения нет. */
    public suspend fun sendNoReply(text: String): Boolean {
        val ws = current.value ?: return false
        return try {
            ws.send(Frame.Text(text))
            true
        } catch (e: Throwable) {
            currentCoroutineContext().ensureActive()
            false
        }
    }

    private enum class Outcome { RETRY, REJECTED, REPLACED }

    private suspend fun runLoop(account: Account) {
        var attempt = 0
        while (true) {
            _state.value = SocketState.Connecting
            var outcome = Outcome.RETRY
            try {
                http.webSocket(urlString = url, request = {
                    header(HttpHeaders.SecWebSocketProtocol, Frames.SUBPROTOCOL)
                }) {
                    outcome = session(this, account) { attempt = 0 }
                }
            } catch (e: Throwable) {
                currentCoroutineContext().ensureActive() // наша отмена — выходим; сетевая ошибка — ретрай
            }
            current.value = null
            failPending()
            if (outcome == Outcome.REJECTED) {
                _state.value = SocketState.Rejected
                return
            }
            _state.value = SocketState.Offline
            val wait = if (outcome == Outcome.REPLACED) 30_000L else backoffMs(attempt++)
            withTimeoutOrNull(wait) { kicks.receive() }
        }
    }

    private suspend fun session(
        ws: DefaultClientWebSocketSession,
        account: Account,
        onAuthed: () -> Unit,
    ): Outcome = coroutineScope {
        val challenge = withTimeoutOrNull(10_000) { readFrame(ws) } as? ServerFrame.Challenge
            ?: return@coroutineScope Outcome.RETRY
        val sig = account.identity.sign(NuvaCrypto.authPayload(host, account.deviceId, challenge.nonce))
        ws.send(Frame.Text(Frames.authResponse("auth", account.deviceId, sig)))
        when (val r = withTimeoutOrNull(10_000) { readFrame(ws) }) {
            is ServerFrame.AuthOk -> Unit
            is ServerFrame.Error ->
                return@coroutineScope if (r.code == ErrorCodes.AUTH_FAILED) Outcome.REJECTED else Outcome.RETRY
            else -> return@coroutineScope Outcome.RETRY
        }
        onAuthed()
        _state.value = SocketState.Syncing
        current.value = ws

        val pinger = launch {
            var n = 0
            while (isActive) {
                delay(PING_INTERVAL_MS)
                ws.send(Frame.Text(Frames.ping("p${n++}")))
            }
        }
        try {
            while (true) {
                val f = readFrame(ws) ?: break
                dispatch(f)
            }
        } finally {
            pinger.cancel()
            current.value = null
        }
        val code = withTimeoutOrNull(1_000) { ws.closeReason.await() }?.code?.toInt()
        if (code == CLOSE_REPLACED) Outcome.REPLACED else Outcome.RETRY
    }

    private suspend fun readFrame(ws: DefaultClientWebSocketSession): ServerFrame? {
        while (true) {
            val f = ws.incoming.receiveCatching().getOrNull() ?: return null
            if (f is Frame.Text) return Frames.parse(f.readText())
        }
    }

    private suspend fun dispatch(f: ServerFrame) {
        when (f) {
            is ServerFrame.Deliver -> _deliveries.send(f)
            ServerFrame.QueueEmpty -> {
                _state.value = SocketState.Online
                _synced.tryEmit(Unit)
            }
            is ServerFrame.Pong -> Unit
            else -> {
                val id = f.id ?: return
                lock.withLock { pending.remove(id) }?.complete(f)
            }
        }
    }

    private suspend fun failPending() {
        val all = lock.withLock { pending.values.toList().also { pending.clear() } }
        all.forEach { it.completeExceptionally(NotConnectedException()) }
    }

    private fun backoffMs(attempt: Int): Long {
        val base = (1_000L shl minOf(attempt, 5)).coerceAtMost(30_000L)
        return (base * Random.nextDouble(0.7, 1.3)).toLong()
    }

    private companion object {
        const val PING_INTERVAL_MS = 25_000L
        const val CLOSE_REPLACED = 4409
    }
}
