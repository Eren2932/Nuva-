package app.nuva.core.net

import app.nuva.core.crypto.Identity
import app.nuva.core.crypto.NuvaCrypto
import app.nuva.core.proto.ErrorCodes
import app.nuva.core.proto.Frames
import app.nuva.core.proto.ServerFrame
import app.nuva.core.store.Account
import io.ktor.client.HttpClient
import io.ktor.client.plugins.websocket.DefaultClientWebSocketSession
import io.ktor.client.plugins.websocket.webSocket
import io.ktor.client.request.header
import io.ktor.http.HttpHeaders
import io.ktor.websocket.Frame
import io.ktor.websocket.close
import io.ktor.websocket.readText
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.withTimeoutOrNull

public sealed interface RegistrationResult {
    public class Success(public val account: Account) : RegistrationResult
    public data object InviteInvalid : RegistrationResult
    public data object UsernameTaken : RegistrationResult
    public data object UsernameInvalid : RegistrationResult
    public data object RateLimited : RegistrationResult
    public data object Network : RegistrationResult
    public class Failed(public val code: String) : RegistrationResult
}

/**
 * Регистрация по инвайту (§5.2) одним коротким соединением: challenge → account.register →
 * profile.set (имя/фамилия) → закрытие. Пред-авторизационное окно сервера — 10 с,
 * поэтому весь ввод пользователя собирается ДО подключения.
 */
public class Registration(private val http: HttpClient, private val host: String, private val platform: String) {

    public suspend fun register(
        identity: Identity,
        invite: String,
        username: String,
        firstName: String,
        lastName: String,
    ): RegistrationResult {
        var result: RegistrationResult = RegistrationResult.Network
        try {
            withTimeoutOrNull(25_000) {
                http.webSocket(urlString = "wss://$host/ws", request = {
                    header(HttpHeaders.SecWebSocketProtocol, Frames.SUBPROTOCOL)
                }) {
                    result = perform(this, identity, invite, username, firstName, lastName)
                    close()
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            if (result !is RegistrationResult.Success) result = RegistrationResult.Network
        }
        return result
    }

    private suspend fun perform(
        ws: DefaultClientWebSocketSession,
        identity: Identity,
        invite: String,
        username: String,
        firstName: String,
        lastName: String,
    ): RegistrationResult {
        val challenge = withTimeoutOrNull(10_000) { read(ws) } as? ServerFrame.Challenge
            ?: return RegistrationResult.Network
        val ikPub = identity.ikPub
        val xkPub = identity.xkPub
        val sig = identity.sign(NuvaCrypto.regPayload(host, challenge.nonce, ikPub, xkPub, username))
        ws.send(Frame.Text(Frames.register("reg", invite, username, ikPub, xkPub, identity.xkSig, platform, sig)))

        val registered = when (val r = withTimeoutOrNull(10_000) { read(ws) }) {
            is ServerFrame.Registered -> r
            is ServerFrame.Error -> return when (r.code) {
                ErrorCodes.INVITE_INVALID -> RegistrationResult.InviteInvalid
                ErrorCodes.USERNAME_TAKEN -> RegistrationResult.UsernameTaken
                ErrorCodes.USERNAME_INVALID -> RegistrationResult.UsernameInvalid
                ErrorCodes.RATE_LIMITED -> RegistrationResult.RateLimited
                else -> RegistrationResult.Failed(r.code)
            }
            else -> return RegistrationResult.Network
        }

        // Аккаунт создан. Имя — best effort: при сбое досылаем после следующего входа.
        var first = firstName
        var last = lastName
        var profilePending = true
        ws.send(Frame.Text(Frames.profileSet("prof", firstName, lastName)))
        while (true) {
            val f = withTimeoutOrNull(10_000) { read(ws) } ?: break
            if (f is ServerFrame.ProfileOk) {
                first = f.firstName
                last = f.lastName
                profilePending = false
                break
            }
            if (f is ServerFrame.Error && f.id == "prof") break
            // queue.empty и прочее после регистрации — пропускаем
        }
        return RegistrationResult.Success(
            Account(registered.accountId, registered.deviceId, username, first, last, identity, profilePending),
        )
    }

    private suspend fun read(ws: DefaultClientWebSocketSession): ServerFrame? {
        while (true) {
            val f = ws.incoming.receiveCatching().getOrNull() ?: return null
            if (f is Frame.Text) return Frames.parse(f.readText())
        }
    }
}
