package app.nuva.core.store

import app.nuva.core.SecretStore
import app.nuva.core.crypto.Identity
import app.nuva.core.util.hexToBytes
import app.nuva.core.util.toHex
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject

/** Учётная запись этого устройства. Приватные ключи живут только здесь (и в SecretStore). */
public class Account(
    public val accountId: String,
    public val deviceId: String,
    public val username: String,
    public val firstName: String,
    public val lastName: String,
    public val identity: Identity,
    /** true — имя ещё не доехало до сервера (profile.set упал после регистрации). */
    public val profilePending: Boolean = false,
) {
    public val displayName: String get() = listOf(firstName, lastName).filter { it.isNotBlank() }.joinToString(" ")
        .ifBlank { "@$username" }

    public fun copy(firstName: String = this.firstName, lastName: String = this.lastName,
                    profilePending: Boolean = this.profilePending): Account =
        Account(accountId, deviceId, username, firstName, lastName, identity, profilePending)
}

public class AccountStore(private val secrets: SecretStore) {
    private val json = Json { ignoreUnknownKeys = true }

    public fun load(): Account? {
        val raw = try { secrets.read() } catch (e: Exception) { null } ?: return null
        return try {
            val o = json.parseToJsonElement(raw.decodeToString()).jsonObject
            fun s(k: String) = (o[k] as? JsonPrimitive)?.contentOrNull ?: error("missing $k")
            Account(
                accountId = s("account_id"), deviceId = s("device_id"), username = s("username"),
                firstName = s("first_name"), lastName = s("last_name"),
                identity = Identity(s("ik_seed").hexToBytes(), s("xk_priv").hexToBytes()),
                profilePending = (o["profile_pending"] as? JsonPrimitive)?.contentOrNull == "true",
            )
        } catch (e: Exception) {
            null
        }
    }

    public fun save(a: Account) {
        val o = JsonObject(mapOf(
            "v" to JsonPrimitive(1),
            "account_id" to JsonPrimitive(a.accountId),
            "device_id" to JsonPrimitive(a.deviceId),
            "username" to JsonPrimitive(a.username),
            "first_name" to JsonPrimitive(a.firstName),
            "last_name" to JsonPrimitive(a.lastName),
            "ik_seed" to JsonPrimitive(a.identity.ikSeed.toHex()),
            "xk_priv" to JsonPrimitive(a.identity.xkPriv.toHex()),
            "profile_pending" to JsonPrimitive(if (a.profilePending) "true" else "false"),
        ))
        secrets.write(o.toString().encodeToByteArray())
    }

    public fun clear(): Unit = secrets.clear()
}
