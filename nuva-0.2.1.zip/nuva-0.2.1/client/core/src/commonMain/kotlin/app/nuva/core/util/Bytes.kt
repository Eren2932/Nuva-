package app.nuva.core.util

/** Байтовые утилиты протокола: строгий base64url (§2), hex, UUID ↔ 16 байт. */
public object B64 {
    private const val ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_"
    private val INDEX = IntArray(128) { -1 }.also { t -> ALPHABET.forEachIndexed { i, c -> t[c.code] = i } }

    public fun encode(data: ByteArray): String {
        val sb = StringBuilder((data.size * 4 + 2) / 3)
        var i = 0
        while (i + 3 <= data.size) {
            val n = (data[i].u() shl 16) or (data[i + 1].u() shl 8) or data[i + 2].u()
            sb.append(ALPHABET[n ushr 18 and 63]).append(ALPHABET[n ushr 12 and 63])
                .append(ALPHABET[n ushr 6 and 63]).append(ALPHABET[n and 63])
            i += 3
        }
        when (data.size - i) {
            1 -> {
                val n = data[i].u() shl 16
                sb.append(ALPHABET[n ushr 18 and 63]).append(ALPHABET[n ushr 12 and 63])
            }
            2 -> {
                val n = (data[i].u() shl 16) or (data[i + 1].u() shl 8)
                sb.append(ALPHABET[n ushr 18 and 63]).append(ALPHABET[n ushr 12 and 63])
                    .append(ALPHABET[n ushr 6 and 63])
            }
        }
        return sb.toString()
    }

    /** Строго: только алфавит url-safe, без '=', каноническая форма (лишние биты = 0). */
    public fun decode(s: String): ByteArray {
        require(s.length % 4 != 1) { "bad base64url length" }
        val out = ByteArray(s.length * 3 / 4)
        var buf = 0
        var bits = 0
        var o = 0
        for (c in s) {
            val v = if (c.code < 128) INDEX[c.code] else -1
            require(v >= 0) { "bad base64url char" }
            buf = (buf shl 6) or v
            bits += 6
            if (bits >= 8) {
                bits -= 8
                out[o++] = (buf ushr bits).toByte()
                buf = buf and ((1 shl bits) - 1)
            }
        }
        require(buf == 0) { "non-canonical base64url" }
        return if (o == out.size) out else out.copyOf(o)
    }

    private fun Byte.u(): Int = toInt() and 0xFF
}

public fun ByteArray.toHex(): String = joinToString("") { (it.toInt() and 0xFF).toString(16).padStart(2, '0') }

public fun String.hexToBytes(): ByteArray {
    require(length % 2 == 0) { "odd hex length" }
    return ByteArray(length / 2) { i -> substring(i * 2, i * 2 + 2).toInt(16).toByte() }
}

public fun concat(vararg parts: ByteArray): ByteArray {
    val out = ByteArray(parts.sumOf { it.size })
    var off = 0
    for (p in parts) {
        p.copyInto(out, off)
        off += p.size
    }
    return out
}

/** Сравнение как у Python `bytes` (беззнаково, лексикографически). */
public fun compareUnsigned(a: ByteArray, b: ByteArray): Int {
    for (i in 0 until minOf(a.size, b.size)) {
        val d = (a[i].toInt() and 0xFF) - (b[i].toInt() and 0xFF)
        if (d != 0) return d
    }
    return a.size - b.size
}

public object Uuids {
    private val CANON = Regex("^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$")

    public fun isValid(uuid: String): Boolean = CANON.matches(uuid.lowercase())

    /** Канонический UUID (регистр не важен) → 16 байт big-endian (= uuid.bytes в Python). */
    public fun toBytes(uuid: String): ByteArray {
        val s = uuid.lowercase()
        require(CANON.matches(s)) { "bad uuid" }
        return s.replace("-", "").hexToBytes()
    }

    public fun format(b: ByteArray): String {
        require(b.size == 16)
        val h = b.toHex()
        return "${h.substring(0, 8)}-${h.substring(8, 12)}-${h.substring(12, 16)}-${h.substring(16, 20)}-${h.substring(20)}"
    }

    /** UUIDv7 (RFC 9562): 48 бит мс + случайные биты. Монотонен по времени → удобен для client_msg_id. */
    public fun v7(nowMs: Long, random10: ByteArray): String {
        require(random10.size >= 10)
        val b = ByteArray(16)
        for (i in 0 until 6) b[i] = (nowMs ushr (8 * (5 - i))).toByte()
        b[6] = (0x70 or (random10[0].toInt() and 0x0F)).toByte()
        b[7] = random10[1]
        b[8] = (0x80 or (random10[2].toInt() and 0x3F)).toByte()
        for (i in 9 until 16) b[i] = random10[i - 6]
        return format(b)
    }
}
