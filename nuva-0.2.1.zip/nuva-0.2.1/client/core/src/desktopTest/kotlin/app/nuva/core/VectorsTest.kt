package app.nuva.core

import app.nuva.core.crypto.CryptoException
import app.nuva.core.crypto.Identity
import app.nuva.core.crypto.NuvaCrypto
import app.nuva.core.util.B64
import app.nuva.core.util.Uuids
import app.nuva.core.util.hexToBytes
import app.nuva.core.util.toHex
import kotlinx.coroutines.runBlocking
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.int
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import java.io.File
import kotlin.test.BeforeTest
import kotlin.test.Test
import kotlin.test.assertContentEquals
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertFalse
import kotlin.test.assertTrue

/** Клиент обязан совпасть с эталоном сервера (server/tools/test-vectors.json) байт-в-байт. */
class VectorsTest {
    private val v: JsonObject by lazy {
        val path = System.getProperty("nuva.vectors") ?: error("system property nuva.vectors not set")
        Json.parseToJsonElement(File(path).readText()).jsonObject
    }

    private fun JsonObject.s(k: String) = this[k]!!.jsonPrimitive.content
    private fun JsonObject.h(k: String) = s(k).hexToBytes()
    private fun JsonObject.o(k: String) = this[k]!!.jsonObject
    private fun party(name: String) = v.o("parties").o(name)
    private fun identity(name: String) = party(name).let { Identity(it.h("ik_seed"), it.h("xk_priv")) }

    @BeforeTest
    fun init() = runBlocking { NuvaCrypto.init() }

    @Test
    fun hkdfRfc5869() {
        for (t in v["hkdf_sha256_rfc5869"]!!.jsonArray.map { it.jsonObject }) {
            val prk = NuvaCrypto.hkdfExtract(t.h("salt"), t.h("ikm"))
            assertEquals(t.s("prk"), prk.toHex(), t.s("name"))
            val okm = NuvaCrypto.hkdfExpand(prk, t.h("info"), t["length"]!!.jsonPrimitive.int)
            assertEquals(t.s("okm"), okm.toHex(), t.s("name"))
        }
    }

    @Test
    fun partiesKeysAndXkSignature() {
        for (name in listOf("alice", "bob")) {
            val p = party(name)
            val id = identity(name)
            assertEquals(p.s("ik_pub"), id.ikPub.toHex(), name)
            assertEquals(p.s("xk_pub"), id.xkPub.toHex(), name)
            assertEquals(p.s("xk_payload"), NuvaCrypto.xkPayload(id.xkPub).toHex(), name)
            assertEquals(p.s("x25519_sig"), id.xkSig.toHex(), name) // Ed25519 детерминирован
            assertTrue(NuvaCrypto.verify(id.ikPub, NuvaCrypto.xkPayload(id.xkPub), id.xkSig))
        }
    }

    @Test
    fun authPayloadAndSignature() {
        val a = v.o("auth")
        val payload = NuvaCrypto.authPayload(a.s("host"), a.s("device_id"), a.h("nonce"))
        assertEquals(a.s("payload"), payload.toHex())
        assertEquals(a.s("sig"), identity(a.s("party")).sign(payload).toHex())
    }

    @Test
    fun registerPayloadAndSignature() {
        for (r in v["register"]!!.jsonArray.map { it.jsonObject }) {
            val id = identity(r.s("party"))
            val payload = NuvaCrypto.regPayload(r.s("host"), r.h("nonce"), id.ikPub, id.xkPub, r.s("username"))
            assertEquals(r.s("payload"), payload.toHex(), r.s("username"))
            assertEquals(r.s("sig"), id.sign(payload).toHex(), r.s("username"))
        }
    }

    @Test
    fun envelopesSealOpenTamper() {
        for (e in v["envelopes"]!!.jsonArray.map { it.jsonObject }) {
            val name = e.s("name")
            val sender = party(e.s("sender"))
            val recipient = party(e.s("recipient"))
            val sDev = e.s("sender_device_id")
            val rDev = e.s("recipient_device_id")
            val cmid = e.s("client_msg_id")
            val plaintext = e.h("plaintext")

            assertEquals(e.s("padded"), NuvaCrypto.pad(plaintext).toHex(), name)
            assertEquals(e.s("hkdf_info"), NuvaCrypto.msgInfo(sDev, rDev, e.h("e_pub")).toHex(), name)
            assertEquals(e.s("ad"), NuvaCrypto.msgAd(sDev, rDev, cmid, e.h("e_pub")).toHex(), name)
            assertEquals(e.s("es"), NuvaCrypto.x25519(e.h("e_priv"), recipient.h("xk_pub")).toHex(), name)
            assertEquals(e.s("ss"), NuvaCrypto.x25519(sender.h("xk_priv"), recipient.h("xk_pub")).toHex(), name)

            val sealed = NuvaCrypto.seal(
                sender.h("xk_priv"), recipient.h("xk_pub"), sDev, rDev, cmid, plaintext,
                ePriv = e.h("e_priv"), nonce = e.h("nonce"),
            )
            assertEquals(e.s("envelope"), sealed.toHex(), name)

            val opened = NuvaCrypto.open(recipient.h("xk_priv"), sender.h("xk_pub"), sDev, rDev, cmid, e.h("envelope"))
            assertContentEquals(plaintext, opened, name)

            assertFailsWith<CryptoException>(name) {
                NuvaCrypto.open(recipient.h("xk_priv"), sender.h("xk_pub"), sDev, rDev, cmid, e.h("tampered_envelope"))
            }
            // Чужой client_msg_id (AD) — тоже отказ.
            assertFailsWith<CryptoException>(name) {
                NuvaCrypto.open(recipient.h("xk_priv"), sender.h("xk_pub"), sDev, rDev,
                    "0192f3a1-0000-7000-8000-0000000fffff", e.h("envelope"))
            }
        }
    }

    @Test
    fun lowOrderPointsRejected() {
        val priv = party("alice").h("xk_priv")
        for (p in v["x25519_low_order_points_must_fail"]!!.jsonArray) {
            assertFailsWith<CryptoException> { NuvaCrypto.x25519(priv, p.jsonPrimitive.content.hexToBytes()) }
        }
    }

    @Test
    fun paddingLengths() {
        for (p in v["padding"]!!.jsonArray.map { it.jsonObject }) {
            val n = p["len"]!!.jsonPrimitive.int
            val data = ByteArray(n) { 0x41 }
            val padded = NuvaCrypto.pad(data)
            assertEquals(p["padded_len"]!!.jsonPrimitive.int, padded.size, "len=$n")
            assertContentEquals(data, NuvaCrypto.unpad(padded))
        }
        assertFailsWith<CryptoException> { NuvaCrypto.unpad(ByteArray(256)) }
    }

    @Test
    fun safetyNumber() {
        val s = v.o("safety_number")
        assertEquals(s.s("digits"), NuvaCrypto.safetyNumber(s.h("ik_a"), s.h("ik_b")))
        assertEquals(s.s("digits"), NuvaCrypto.safetyNumber(s.h("ik_b"), s.h("ik_a")))
    }

    @Test
    fun base64urlStrict() {
        val raw = (0..255).map { it.toByte() }.toByteArray()
        assertContentEquals(raw, B64.decode(B64.encode(raw)))
        for (bad in listOf("AB", "ab+/", "AAA=", "A")) assertFailsWith<IllegalArgumentException>(bad) { B64.decode(bad) }
        assertEquals("", B64.encode(ByteArray(0)))
    }

    @Test
    fun uuidV7Shape() {
        val id = Uuids.v7(1_793_434_200_000L, ByteArray(10) { 0xFF.toByte() })
        assertTrue(Uuids.isValid(id))
        assertEquals('7', id[14])
        assertTrue(id[19] in "89ab")
        assertFalse(Uuids.isValid("not-a-uuid"))
    }
}
