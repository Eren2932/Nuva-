// pluginManagement обязан идти первым блоком скрипта — иначе Gradle падает на конфигурации.
pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.PREFER_SETTINGS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "nuva"

include(":core", ":ui", ":app-android", ":app-desktop")
