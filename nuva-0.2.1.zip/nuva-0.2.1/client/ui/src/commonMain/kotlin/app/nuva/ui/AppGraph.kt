package app.nuva.ui

import app.nuva.core.InitResult
import app.nuva.core.NuvaCore
import app.nuva.core.Platform
import app.nuva.ui.nav.Router
import app.nuva.ui.onboarding.OnboardingState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async

/** Корень приложения: один на процесс (Android — в Application, desktop — в main). */
class AppGraph(platform: Platform) {
    val scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    val core: NuvaCore = NuvaCore(platform, scope)
    val router: Router = Router()
    val onboarding: OnboardingState = OnboardingState()

    // Инициализация ровно один раз, даже если заставку пересоздали (поворот экрана).
    private val boot = scope.async(start = CoroutineStart.LAZY) { core.init() }

    suspend fun init(): InitResult = boot.await()

    fun onForeground() = core.onForeground()

    /**
     * Системная «назад». Во время регистрации назад нельзя (запрос уже ушёл на сервер),
     * но после ошибки — можно: возвращаем к исправлению ввода.
     */
    fun back(): Boolean {
        val top = router.state.value.top
        val phase = onboarding.phase
        if (top == app.nuva.ui.nav.Screen.KeyGen && phase is app.nuva.ui.onboarding.RegPhase.Error &&
            onboarding.job?.isActive != true) {
            router.backTo(phase.back ?: app.nuva.ui.nav.Screen.Username)
            return true
        }
        return router.back()
    }
}
