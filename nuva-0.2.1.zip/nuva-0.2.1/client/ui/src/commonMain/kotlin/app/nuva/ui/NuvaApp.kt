package app.nuva.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.ContentTransform
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import app.nuva.ui.chat.ChatScreen
import app.nuva.ui.chats.ChatsScreen
import app.nuva.ui.chats.SearchScreen
import app.nuva.ui.nav.NavState
import app.nuva.ui.nav.Screen
import app.nuva.ui.onboarding.FatalScreen
import app.nuva.ui.onboarding.InviteScreen
import app.nuva.ui.onboarding.KeyGenScreen
import app.nuva.ui.onboarding.NameScreen
import app.nuva.ui.onboarding.SplashScreen
import app.nuva.ui.onboarding.UsernameScreen
import app.nuva.ui.onboarding.WelcomeScreen
import app.nuva.ui.profile.ProfileScreen
import app.nuva.ui.theme.NuvaTheme

/** Корневой composable: общий для Android и desktop. */
@Composable
fun NuvaApp(graph: AppGraph) {
    NuvaTheme {
        val nav by graph.router.state.collectAsState()
        Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
            AnimatedContent(
                targetState = nav,
                // Ключ — экран, а не весь стек: иначе push того же экрана перезапускал бы анимацию.
                contentKey = { it.top },
                transitionSpec = { transitionFor(initialState, targetState) },
                label = "nav",
            ) { state ->
                ScreenHost(graph, state.top)
            }
        }
    }
}

private const val NAV_MS = 280

private fun transitionFor(from: NavState, to: NavState): ContentTransform {
    // Заставка уходит растворением: системная заставка → наша → контент без единого скачка.
    if (from.top == Screen.Splash || to.top is Screen.Fatal) {
        return fadeIn(tween(220)) togetherWith fadeOut(tween(180))
    }
    val dir = if (to.forward) 1 else -1
    val easing = FastOutSlowInEasing
    return (slideInHorizontally(tween(NAV_MS, easing = easing)) { w -> dir * w / 4 } + fadeIn(tween(NAV_MS))) togetherWith
        (slideOutHorizontally(tween(NAV_MS, easing = easing)) { w -> -dir * w / 6 } + fadeOut(tween(NAV_MS / 2)))
}

@Composable
private fun ScreenHost(graph: AppGraph, screen: Screen) {
    when (screen) {
        Screen.Splash -> SplashScreen(graph)
        Screen.Welcome -> WelcomeScreen(graph)
        Screen.Invite -> InviteScreen(graph)
        Screen.Name -> NameScreen(graph)
        Screen.Username -> UsernameScreen(graph)
        Screen.KeyGen -> KeyGenScreen(graph)
        Screen.Chats -> ChatsScreen(graph)
        Screen.Search -> SearchScreen(graph)
        Screen.Profile -> ProfileScreen(graph)
        is Screen.Chat -> ChatScreen(graph, screen.peerId)
        is Screen.Fatal -> FatalScreen(screen.message)
    }
}
