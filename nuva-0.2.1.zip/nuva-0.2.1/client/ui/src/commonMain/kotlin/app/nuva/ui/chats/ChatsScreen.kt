package app.nuva.ui.chats

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.nuva.core.chat.ChatSummary
import app.nuva.core.chat.Messenger
import app.nuva.core.net.SocketState
import app.nuva.ui.AppGraph
import app.nuva.ui.components.Avatar
import app.nuva.ui.components.ConnectionTitle
import app.nuva.ui.components.NuvaMark
import app.nuva.ui.components.NuvaTopBar
import app.nuva.ui.components.PrimaryButton
import app.nuva.ui.components.StatusTicks
import app.nuva.ui.components.chatListTime
import app.nuva.ui.nav.Screen

/** Мессенджер есть только при активной учётке. Нет учётки — возвращаем на приветствие. */
@Composable
internal fun requireMessenger(graph: AppGraph): Messenger? {
    val m by graph.core.messenger.collectAsState()
    if (m == null) LaunchedEffect(Unit) { graph.router.replaceAll(Screen.Welcome) }
    return m
}

@Composable
fun ChatsScreen(graph: AppGraph) {
    val m = requireMessenger(graph) ?: return
    val account by graph.core.account.collectAsState()
    val socket by graph.core.socket.state.collectAsState()
    // null — ещё читаем БД: не показываем «пусто» на долю секунды.
    val chats by remember(m) { m.chats() }.collectAsState(initial = null)

    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Column(Modifier.fillMaxSize()) {
            NuvaTopBar {
                val acc = account
                IconButton(onClick = { graph.router.push(Screen.Profile) }) {
                    if (acc != null) Avatar(acc.accountId, acc.displayName, 34.dp)
                }
                Spacer(Modifier.width(6.dp))
                Box(Modifier.weight(1f)) { ConnectionTitle(socket, "Nuva") }
                IconButton(onClick = { graph.router.push(Screen.Search) }) {
                    Icon(Icons.Filled.Search, contentDescription = "Поиск")
                }
            }
            if (socket == SocketState.Rejected) RejectedBanner(graph)

            val list = chats
            when {
                list == null -> Unit
                list.isEmpty() -> EmptyChats(Modifier.weight(1f)) { graph.router.push(Screen.Search) }
                else -> LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                    items(list, key = { it.peerId }) { c ->
                        ChatRow(c, Modifier.animateItem()) { graph.router.push(Screen.Chat(c.peerId)) }
                    }
                    item { Spacer(Modifier.height(96.dp).navigationBarsPadding()) }
                }
            }
        }
        if (!chats.isNullOrEmpty()) {
            FloatingActionButton(
                onClick = { graph.router.push(Screen.Search) },
                modifier = Modifier.align(Alignment.BottomEnd).navigationBarsPadding().padding(20.dp),
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                shape = CircleShape,
            ) { Icon(Icons.Filled.Edit, contentDescription = "Новый чат") }
        }
    }
}

@Composable
private fun ChatRow(c: ChatSummary, modifier: Modifier, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(
        modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Avatar(c.peerId, c.title, 54.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(c.title, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (c.lastOutgoing) {
                    StatusTicks(c.lastStatus, cs.secondary)
                    Spacer(Modifier.width(4.dp))
                }
                Text(chatListTime(c.lastTs), style = MaterialTheme.typography.bodySmall,
                    color = if (c.unread > 0) cs.secondary else cs.onSurfaceVariant)
            }
            Spacer(Modifier.height(3.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    (if (c.lastOutgoing) "Вы: " else "") + c.lastText.replace('\n', ' '),
                    Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium,
                    color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
                if (c.unread > 0) {
                    Spacer(Modifier.width(8.dp))
                    Box(
                        Modifier.defaultMinSize(minWidth = 22.dp, minHeight = 22.dp).clip(RoundedCornerShape(11.dp))
                            .background(cs.primary).padding(horizontal = 7.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(if (c.unread > 999) "999+" else c.unread.toString(), color = cs.onPrimary,
                            fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyChats(modifier: Modifier, onFind: () -> Unit) {
    Column(
        modifier.fillMaxWidth().padding(horizontal = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        NuvaMark(84.dp)
        Spacer(Modifier.height(24.dp))
        Text("Пока нет чатов", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        Text(
            "Найдите собеседника по имени пользователя и напишите первым.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
        )
        Spacer(Modifier.height(28.dp))
        PrimaryButton("Найти собеседника", onClick = onFind)
    }
}

/** Сервер не признаёт устройство: например, сервер переехал на чистую БД. */
@Composable
internal fun RejectedBanner(graph: AppGraph) {
    var confirm by remember { mutableStateOf(false) }
    if (confirm) app.nuva.ui.profile.ResetAccountDialog(graph, onDismiss = { confirm = false })
    Surface(color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.25f)) {
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 8.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.Warning, null, tint = MaterialTheme.colorScheme.error)
            Spacer(Modifier.width(12.dp))
            Text("Сервер не узнаёт это устройство. Нужна новая регистрация.",
                Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
            TextButton(onClick = { confirm = true }) { Text("Заново") }
        }
    }
}
