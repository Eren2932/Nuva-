package app.nuva.ui.chats

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.nuva.core.chat.Limits
import app.nuva.core.chat.LookupResult
import app.nuva.core.proto.RemoteAccount
import app.nuva.ui.AppGraph
import app.nuva.ui.components.Avatar
import app.nuva.ui.components.CenteredHint
import app.nuva.ui.components.NuvaTopBar
import app.nuva.ui.nav.Screen
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private sealed interface Remote {
    data object None : Remote
    data object Loading : Remote
    data class Done(val query: String, val result: LookupResult) : Remote
}

/** Пауза перед запросом: не дёргаем сервер на каждую букву (и не упираемся в лимит 30/мин). */
private const val DEBOUNCE_MS = 400L

/**
 * Поиск. Локально — по уже открытым чатам (имя/юзернейм), на сервере — точный @username.
 * Сервер не отдаёт «похожих»: это защита от перебора базы пользователей.
 */
@Composable
fun SearchScreen(graph: AppGraph) {
    val m = requireMessenger(graph) ?: return
    val me by graph.core.account.collectAsState()
    val chats by remember(m) { m.chats() }.collectAsState(initial = emptyList())
    var query by remember { mutableStateOf("") }
    var remote by remember { mutableStateOf<Remote>(Remote.None) }
    var opening by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val focus = remember { FocusRequester() }

    val q = query.trim()
    val username = q.removePrefix("@").lowercase()
    val exact = Limits.USERNAME.matches(username)
    val local = remember(q, chats) {
        if (q.isEmpty()) emptyList()
        else chats.filter {
            it.title.contains(q, ignoreCase = true) || (username.isNotEmpty() && it.username.contains(username))
        }
    }

    LaunchedEffect(username, exact) {
        if (!exact) { remote = Remote.None; return@LaunchedEffect }
        delay(DEBOUNCE_MS)
        remote = Remote.Loading
        remote = Remote.Done(username, m.lookup(username))
    }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }

    fun open(acc: RemoteAccount) {
        if (opening) return
        opening = true
        scope.launch {
            try {
                val id = m.openChat(acc)
                graph.router.replaceTop(Screen.Chat(id))
            } finally {
                opening = false
            }
        }
    }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).imePadding()) {
        NuvaTopBar {
            IconButton(onClick = { graph.router.back() }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Назад")
            }
            Box(Modifier.weight(1f).padding(end = 4.dp), contentAlignment = Alignment.CenterStart) {
                if (query.isEmpty()) {
                    Text("Имя или @username", color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.bodyLarge)
                }
                BasicTextField(
                    value = query,
                    onValueChange = { query = it.take(64) },
                    singleLine = true,
                    textStyle = MaterialTheme.typography.bodyLarge.copy(color = MaterialTheme.colorScheme.onSurface),
                    cursorBrush = SolidColor(MaterialTheme.colorScheme.secondary),
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.None,
                        autoCorrectEnabled = false, imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = {
                        (remote as? Remote.Done)?.result?.let { if (it is LookupResult.Found) open(it.account) }
                    }),
                    modifier = Modifier.fillMaxWidth().focusRequester(focus),
                )
            }
            if (query.isNotEmpty()) {
                IconButton(onClick = { query = "" }) { Icon(Icons.Filled.Close, contentDescription = "Очистить") }
            }
        }

        LazyColumn(Modifier.fillMaxSize()) {
            if (exact) {
                item(key = "remote") {
                    SectionTitle("Глобальный поиск")
                    AnimatedContent(remote, transitionSpec = { fadeIn(tween(150)) togetherWith fadeOut(tween(100)) },
                        label = "remote") { r ->
                        RemoteBlock(r, me?.accountId, opening, ::open)
                    }
                }
            }
            if (local.isNotEmpty()) {
                item(key = "local-title") { SectionTitle("Чаты") }
                items(local, key = { "l-" + it.peerId }) { c ->
                    PersonRow(c.peerId, c.title, "@${c.username}") { graph.router.replaceTop(Screen.Chat(c.peerId)) }
                }
            }
            if (q.isEmpty()) {
                item(key = "hint") {
                    CenteredHint(
                        "Найдите собеседника",
                        "Введите его имя пользователя целиком, например @sobir. " +
                            "Nuva не показывает списки людей — найти можно только того, чьё имя вы знаете.",
                        Modifier.fillMaxWidth().padding(top = 48.dp),
                    )
                }
            } else if (!exact && local.isEmpty()) {
                item(key = "nothing") {
                    CenteredHint("Ничего не найдено",
                        "Имя пользователя — это латиница a–z, цифры и _, от 3 до 32 символов.",
                        Modifier.fillMaxWidth().padding(top = 48.dp))
                }
            }
        }
    }
}

@Composable
private fun RemoteBlock(r: Remote, myId: String?, opening: Boolean, open: (RemoteAccount) -> Unit) {
    when (r) {
        Remote.None, Remote.Loading -> Box(Modifier.fillMaxWidth().height(76.dp), contentAlignment = Alignment.Center) {
            if (r == Remote.Loading) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
        }
        is Remote.Done -> when (val res = r.result) {
            is LookupResult.Found -> {
                val a = res.account
                val self = a.accountId == myId
                Row(
                    Modifier.fillMaxWidth().clickable(enabled = !self && !opening) { open(a) }
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Avatar(a.accountId, res.title, 50.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(res.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold,
                            maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("@${a.username}", style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.secondary)
                    }
                    if (self) {
                        Text("Это вы", color = MaterialTheme.colorScheme.onSurfaceVariant,
                            style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(end = 8.dp))
                    } else {
                        Button(onClick = { open(a) }, enabled = !opening, shape = RoundedCornerShape(12.dp)) {
                            Text("Написать")
                        }
                    }
                }
            }
            LookupResult.NotFound -> InfoLine("Пользователь @${r.query} не найден")
            LookupResult.Offline -> InfoLine("Нет соединения с сервером — поиск заработает, когда связь вернётся")
            LookupResult.RateLimited -> InfoLine("Слишком много запросов. Подождите минуту")
        }
    }
}

@Composable
private fun InfoLine(text: String) {
    Text(text, Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 18.dp),
        style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

@Composable
private fun SectionTitle(text: String) {
    Surface(color = MaterialTheme.colorScheme.surfaceContainerLow, modifier = Modifier.fillMaxWidth()) {
        Text(text, Modifier.padding(horizontal = 16.dp, vertical = 8.dp), style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
internal fun PersonRow(seed: String, title: String, subtitle: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Avatar(seed, title, 50.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

