package app.nuva.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.sp

private val palettes = listOf(
    Color(0xFF8A7FCB) to Color(0xFF5B4F9B),
    Color(0xFFFF8E8E) to Color(0xFFD9506A),
    Color(0xFFFFC37A) to Color(0xFFE08A3C),
    Color(0xFF7FD4A0) to Color(0xFF3E9B6B),
    Color(0xFF7FC8F0) to Color(0xFF3C86C4),
    Color(0xFFF59AD0) to Color(0xFFC0569A),
    Color(0xFF9FA8FF) to Color(0xFF5865D9),
)

fun initials(title: String): String {
    val parts = title.removePrefix("@").split(' ').filter { it.isNotBlank() }
    return when {
        parts.isEmpty() -> "?"
        parts.size == 1 -> parts[0].take(1).uppercase()
        else -> (parts[0].take(1) + parts[1].take(1)).uppercase()
    }
}

/** Аватар-инициалы; цвет стабилен для аккаунта (по его id), как в Telegram. */
@Composable
fun Avatar(seed: String, title: String, size: Dp, modifier: Modifier = Modifier) {
    val (a, b) = palettes[(seed.hashCode() and 0x7fffffff) % palettes.size]
    Box(
        modifier.size(size).clip(CircleShape).background(Brush.linearGradient(listOf(a, b))),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            initials(title),
            color = Color.White,
            fontWeight = FontWeight.SemiBold,
            fontSize = (size.value * 0.38f).sp,
        )
    }
}
