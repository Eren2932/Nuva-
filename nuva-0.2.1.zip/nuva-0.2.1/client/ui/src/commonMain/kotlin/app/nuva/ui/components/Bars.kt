package app.nuva.ui.components

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import app.nuva.core.net.SocketState

/** Верхняя панель: фон surfaceContainer, учитывает статус-бар. */
@Composable
fun NuvaTopBar(content: @Composable RowScope.() -> Unit) {
    Surface(color = MaterialTheme.colorScheme.surfaceContainer, tonalElevation = 0.dp) {
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().height(60.dp).padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            content = content,
        )
    }
}

/** Как в Telegram: пока нет связи, заголовок заменяется на «Соединение…». null — всё хорошо. */
fun connectionLabel(s: SocketState): String? = when (s) {
    SocketState.Online -> null
    SocketState.Syncing -> "Обновление…"
    SocketState.Connecting, SocketState.Offline -> "Соединение…"
    SocketState.Rejected -> "Устройство не авторизовано"
}

@Composable
fun ConnectionTitle(state: SocketState, idleTitle: String) {
    val label = connectionLabel(state)
    Row(verticalAlignment = Alignment.CenterVertically) {
        if (label != null && state != SocketState.Rejected) {
            CircularProgressIndicator(Modifier.size(14.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.secondary)
            Spacer(Modifier.width(10.dp))
        }
        Text(label ?: idleTitle, style = MaterialTheme.typography.titleLarge, maxLines = 1)
    }
}

fun hexGrid(bytes: ByteArray, take: Int = 16): String =
    bytes.take(take).joinToString("") { (it.toInt() and 0xff).toString(16).padStart(2, '0') }
        .chunked(8).joinToString("\n") { it.chunked(2).joinToString(" ") }
