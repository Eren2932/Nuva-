package app.nuva.ui.components

import kotlinx.datetime.Clock
import kotlinx.datetime.Instant
import kotlinx.datetime.LocalDateTime
import kotlinx.datetime.TimeZone
import kotlinx.datetime.toLocalDateTime

private val MONTHS_GEN = listOf("января", "февраля", "марта", "апреля", "мая", "июня", "июля",
    "августа", "сентября", "октября", "ноября", "декабря")
private val MONTHS_SHORT = listOf("янв.", "февр.", "мар.", "апр.", "мая", "июн.", "июл.",
    "авг.", "сент.", "окт.", "нояб.", "дек.")
private val WEEKDAYS = listOf("пн", "вт", "ср", "чт", "пт", "сб", "вс")

private fun local(ms: Long): LocalDateTime =
    Instant.fromEpochMilliseconds(ms).toLocalDateTime(TimeZone.currentSystemDefault())

private fun Int.p2() = toString().padStart(2, '0')

fun nowMs(): Long = Clock.System.now().toEpochMilliseconds()

fun timeHm(ms: Long): String = local(ms).let { "${it.hour.p2()}:${it.minute.p2()}" }

fun dayKey(ms: Long): Int = local(ms).date.toEpochDays()

/** Время в списке чатов: 21:25 · вчера · пн · 5 нояб. · 05.11.24 */
fun chatListTime(ms: Long, now: Long = nowMs()): String {
    val t = local(ms)
    val n = local(now)
    val days = n.date.toEpochDays() - t.date.toEpochDays()
    return when {
        days <= 0 -> timeHm(ms)
        days == 1 -> "вчера"
        days < 7 -> WEEKDAYS[t.date.dayOfWeek.ordinal]
        t.year == n.year -> "${t.dayOfMonth} ${MONTHS_SHORT[t.monthNumber - 1]}"
        else -> "${t.dayOfMonth.p2()}.${t.monthNumber.p2()}.${(t.year % 100).p2()}"
    }
}

/** Разделитель дней в чате: Сегодня · Вчера · 5 ноября · 5 ноября 2024 */
fun daySeparator(ms: Long, now: Long = nowMs()): String {
    val t = local(ms)
    val n = local(now)
    val days = n.date.toEpochDays() - t.date.toEpochDays()
    return when {
        days == 0 -> "Сегодня"
        days == 1 -> "Вчера"
        t.year == n.year -> "${t.dayOfMonth} ${MONTHS_GEN[t.monthNumber - 1]}"
        else -> "${t.dayOfMonth} ${MONTHS_GEN[t.monthNumber - 1]} ${t.year}"
    }
}
