package app.nuva.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.unit.Dp
import app.nuva.ui.theme.NuvaColors
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/** Знак Nuva: фиолетовая сфера, кольцо-орбита и «новая звезда» на ней. Рисуется кодом — без ресурсов. */
fun DrawScope.drawNuvaMark(orbit: Float = 0f, glow: Float = 1f) {
    val r = size.minDimension / 2f
    val c = Offset(size.width / 2f, size.height / 2f)
    drawCircle(
        brush = Brush.linearGradient(
            listOf(NuvaColors.BrandLight, NuvaColors.Brand, NuvaColors.BrandDeep),
            start = Offset(c.x - r, c.y - r), end = Offset(c.x + r, c.y + r),
        ),
        radius = r, center = c,
    )
    drawCircle(Color.White.copy(alpha = 0.92f), radius = r * 0.44f, center = c, style = Stroke(width = r * 0.10f))
    val a = orbit - (PI / 4).toFloat()
    val star = Offset(c.x + cos(a) * r * 0.44f, c.y + sin(a) * r * 0.44f)
    drawCircle(NuvaColors.Night.copy(alpha = 0.35f), radius = r * 0.17f, center = star)
    drawCircle(Color.White, radius = r * 0.12f * (0.85f + 0.15f * glow), center = star)
}

@Composable
fun NuvaMark(size: Dp, modifier: Modifier = Modifier, orbit: Float = 0f, glow: Float = 1f) {
    Canvas(modifier.size(size)) { drawNuvaMark(orbit, glow) }
}

/** Painter знака — для иконки окна на desktop. */
class NuvaMarkPainter : Painter() {
    override val intrinsicSize: Size = Size(256f, 256f)
    override fun DrawScope.onDraw() {
        drawNuvaMark()
    }
}
