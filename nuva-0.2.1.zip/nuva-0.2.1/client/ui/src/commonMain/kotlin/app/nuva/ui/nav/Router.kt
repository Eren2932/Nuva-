package app.nuva.ui.nav

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

sealed interface Screen {
    data object Splash : Screen
    data object Welcome : Screen
    data object Invite : Screen
    data object Name : Screen
    data object Username : Screen
    data object KeyGen : Screen
    data object Chats : Screen
    data object Search : Screen
    data object Profile : Screen
    data class Chat(val peerId: String) : Screen
    data class Fatal(val message: String) : Screen
}

data class NavState(val stack: List<Screen>, val forward: Boolean) {
    val top: Screen get() = stack.last()
}

/** Простой стек экранов без зависимостей. Живёт в AppGraph, переживает пересоздание Activity. */
class Router {
    private val _state = MutableStateFlow(NavState(listOf(Screen.Splash), forward = true))
    val state: StateFlow<NavState> = _state.asStateFlow()

    fun push(s: Screen) = _state.update { if (it.top == s) it else NavState(it.stack + s, forward = true) }

    fun replaceTop(s: Screen) = _state.update { NavState(it.stack.dropLast(1) + s, forward = true) }

    fun replaceAll(s: Screen) = _state.update { NavState(listOf(s), forward = true) }

    /** Вернуться к [s], если он есть в стеке; иначе — сделать его единственным экраном поверх корня. */
    fun backTo(s: Screen) = _state.update {
        val i = it.stack.lastIndexOf(s)
        if (i >= 0) NavState(it.stack.take(i + 1), forward = false) else NavState(it.stack.take(1) + s, forward = false)
    }

    /** false — стек пуст, системная «назад» должна закрыть приложение. */
    fun back(): Boolean {
        val cur = _state.value
        if (cur.top == Screen.KeyGen || cur.top == Screen.Splash) return true // нельзя прервать регистрацию
        if (cur.stack.size <= 1) return false
        _state.value = NavState(cur.stack.dropLast(1), forward = false)
        return true
    }
}
