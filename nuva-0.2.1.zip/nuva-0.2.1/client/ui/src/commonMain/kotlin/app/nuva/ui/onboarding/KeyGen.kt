package app.nuva.ui.onboarding

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.nuva.core.net.RegistrationResult
import app.nuva.ui.AppGraph
import app.nuva.ui.components.NuvaMark
import app.nuva.ui.components.PrimaryButton
import app.nuva.ui.nav.Screen
import app.nuva.ui.theme.NuvaColors
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.random.Random

/** Минимальное время показа генерации: меньше — «мигнуло», больше — раздражает. */
private const val KEYGEN_MIN_MS = 1_200L

private const val HEX = "0123456789abcdef"

private fun fingerprint(bytes: ByteArray): String =
    bytes.take(16).joinToString("") { b -> (b.toInt() and 0xff).toString(16).padStart(2, '0') }

/** 32 hex → 4 строки по 4 группы. */
private fun grid(hex: String): String = hex.chunked(8).joinToString("\n") { it.chunked(2).joinToString(" ") }

/**
 * Запуск регистрации в скоупе приложения. Повторный вызов при живом job — no-op,
 * поэтому пересоздание экрана (поворот, смена темы) не шлёт второй account.register.
 */
private fun AppGraph.startRegistration() {
    val ob = onboarding
    if (ob.job?.isActive == true || ob.phase == RegPhase.Done) return
    ob.job = scope.launch {
        ob.phase = RegPhase.Generating
        val started = app.nuva.ui.components.nowMs()
        val id = ob.identity ?: core.generateIdentity().also { ob.identity = it }
        val left = KEYGEN_MIN_MS - (app.nuva.ui.components.nowMs() - started)
        if (left > 0) delay(left)

        ob.phase = RegPhase.Registering
        val r = core.register(id, ob.invite, ob.username, ob.firstName, ob.lastName)
        ob.phase = when (r) {
            is RegistrationResult.Success -> RegPhase.Done
            RegistrationResult.InviteInvalid -> {
                ob.inviteError = "Код недействителен или уже использован"
                RegPhase.Error("Приглашение не подошло: оно недействительно или уже использовано.", Screen.Invite)
            }
            RegistrationResult.UsernameTaken -> {
                ob.usernameError = "@${ob.username} уже занято"
                RegPhase.Error("Имя @${ob.username} уже занято. Выберите другое.", Screen.Username)
            }
            RegistrationResult.UsernameInvalid -> {
                ob.usernameError = "Сервер не принял это имя"
                RegPhase.Error("Сервер не принял имя пользователя.", Screen.Username)
            }
            RegistrationResult.RateLimited -> RegPhase.Error("Слишком много попыток. Подождите минуту и повторите.", null)
            RegistrationResult.Network -> RegPhase.Error("Нет связи с сервером ${core.serverHost}. Проверьте интернет.", null)
            is RegistrationResult.Failed -> RegPhase.Error("Сервер ответил ошибкой: ${r.code}", null)
        }
    }
}

@Composable
fun KeyGenScreen(graph: AppGraph) {
    val ob = graph.onboarding
    val phase = ob.phase

    LaunchedEffect(Unit) { graph.startRegistration() }
    LaunchedEffect(phase) {
        if (phase == RegPhase.Done) {
            delay(650) // дать увидеть «Готово»
            graph.router.replaceAll(Screen.Chats)
            // Чистим черновик после ухода экрана, иначе он «моргнёт» на анимации выхода.
            graph.scope.launch { delay(1_000); ob.clear() }
        }
    }

    // Бегущий hex, который «оседает» в настоящий отпечаток ключа, как только он готов.
    var shown by remember { mutableStateOf(grid(CharArray(32) { HEX[Random.nextInt(16)] }.concatToString())) }
    LaunchedEffect(phase) {
        val target = ob.identity?.let { fingerprint(it.ikPub) }
        if (target == null) {
            while (true) {
                shown = grid(CharArray(32) { HEX[Random.nextInt(16)] }.concatToString())
                delay(55)
            }
        } else {
            val cur = shown.filter { it in HEX }.toCharArray()
            for (i in 0 until 32) {
                cur[i] = target[i]
                for (j in i + 1 until 32) cur[j] = HEX[Random.nextInt(16)]
                shown = grid(cur.concatToString())
                delay(14)
            }
        }
    }

    val inf = rememberInfiniteTransition(label = "keygen")
    val orbit by inf.animateFloat(0f, (2 * PI).toFloat(), infiniteRepeatable(tween(1_600, easing = LinearEasing)), label = "o")
    val spin by inf.animateFloat(0f, 360f, infiniteRepeatable(tween(1_100, easing = LinearEasing)), label = "s")
    val progress = remember { Animatable(0f) }
    LaunchedEffect(phase) {
        when (phase) {
            RegPhase.Idle, RegPhase.Generating -> progress.animateTo(0.6f, tween(KEYGEN_MIN_MS.toInt(), easing = FastOutSlowInEasing))
            RegPhase.Registering -> progress.animateTo(0.9f, tween(900))
            RegPhase.Done -> progress.animateTo(1f, tween(250))
            is RegPhase.Error -> Unit
        }
    }
    val done = phase == RegPhase.Done
    val scale = remember { Animatable(1f) }
    LaunchedEffect(done) { if (done) { scale.animateTo(1.12f, tween(180)); scale.animateTo(1f, tween(220)) } }

    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).systemBarsPadding().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.weight(1f))
        Box(Modifier.size(168.dp), contentAlignment = Alignment.Center) {
            val err = phase is RegPhase.Error
            val ringColor = if (err) MaterialTheme.colorScheme.error else NuvaColors.BrandSoft
            val track = MaterialTheme.colorScheme.surfaceContainerHigh
            Canvas(Modifier.fillMaxSize()) {
                val sw = 4.dp.toPx()
                drawArc(track, 0f, 360f, false, style = Stroke(sw))
                val sweep = 360f * progress.value
                drawArc(ringColor, -90f + if (done || err) 0f else spin * 0.25f, sweep, false,
                    style = Stroke(sw, cap = StrokeCap.Round))
            }
            NuvaMark(
                96.dp,
                modifier = Modifier.graphicsLayer { scaleX = scale.value; scaleY = scale.value },
                orbit = if (done || phase is RegPhase.Error) 0f else orbit,
            )
        }
        Spacer(Modifier.height(36.dp))
        AnimatedContent(
            targetState = titleFor(phase),
            transitionSpec = { fadeIn(tween(200)) togetherWith fadeOut(tween(150)) },
            label = "title",
        ) { t -> Text(t, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center) }
        Spacer(Modifier.height(18.dp))
        Text(
            shown,
            fontFamily = FontFamily.Monospace,
            fontSize = 15.sp,
            lineHeight = 22.sp,
            letterSpacing = 1.sp,
            textAlign = TextAlign.Center,
            color = if (ob.identity != null) NuvaColors.BrandSoft else MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(12.dp))
        Text(
            if (phase is RegPhase.Error) phase.message
            else "Приватный ключ не покидает устройство. На сервер уходит только публичный.",
            style = MaterialTheme.typography.bodyMedium,
            color = if (phase is RegPhase.Error) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 8.dp),
        )
        Spacer(Modifier.weight(1.3f))
        if (phase is RegPhase.Error) {
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp),
                horizontalAlignment = Alignment.CenterHorizontally) {
                val back = phase.back
                if (back == null) {
                    PrimaryButton("Повторить", onClick = { graph.startRegistration() })
                    TextButton(onClick = { graph.router.backTo(Screen.Username) }) { Text("Изменить данные") }
                } else {
                    PrimaryButton("Исправить", onClick = { graph.router.backTo(back) })
                }
            }
        }
    }
}

private fun titleFor(p: RegPhase): String = when (p) {
    RegPhase.Idle, RegPhase.Generating -> "Создаём ключи шифрования"
    RegPhase.Registering -> "Регистрируем аккаунт"
    RegPhase.Done -> "Готово"
    is RegPhase.Error -> "Не получилось"
}
