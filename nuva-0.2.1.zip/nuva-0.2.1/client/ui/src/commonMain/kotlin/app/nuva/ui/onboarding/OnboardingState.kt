package app.nuva.ui.onboarding

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import app.nuva.core.chat.Limits
import app.nuva.core.crypto.Identity
import kotlinx.coroutines.Job

/** Фаза шага «ключи + регистрация». Живёт в AppGraph — переживает поворот экрана. */
sealed interface RegPhase {
    data object Idle : RegPhase
    data object Generating : RegPhase
    data object Registering : RegPhase
    data object Done : RegPhase
    /** [back] — куда вернуть пользователя исправлять ввод; null — ошибка сети, можно повторить. */
    data class Error(val message: String, val back: app.nuva.ui.nav.Screen?) : RegPhase
}

/** Черновик регистрации. Всё собирается локально и уходит на сервер одним запросом на шаге ключей. */
class OnboardingState {
    var invite by mutableStateOf("")          // нормализованные 10 символов Crockford
    var inviteError by mutableStateOf<String?>(null)
    var firstName by mutableStateOf("")
    var lastName by mutableStateOf("")
    var username by mutableStateOf("")
    var usernameError by mutableStateOf<String?>(null)
    var phase by mutableStateOf<RegPhase>(RegPhase.Idle)

    /** Ключи генерируются один раз и переиспользуются при повторных попытках регистрации. */
    var identity: Identity? = null
    internal var job: Job? = null

    fun clear() {
        invite = ""; inviteError = null; firstName = ""; lastName = ""
        username = ""; usernameError = null; identity = null
        phase = RegPhase.Idle; job = null
    }

    companion object {
        const val INVITE_LEN = 10
        private const val CROCKFORD = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"

        /** Как на сервере: верхний регистр, I/L→1, O→0, дефисы/пробелы выкидываем, прочее — мусор. */
        fun normalizeInvite(raw: String): String = buildString {
            for (ch in raw.uppercase()) {
                val c = when (ch) {
                    'I', 'L' -> '1'
                    'O' -> '0'
                    else -> ch
                }
                if (c in CROCKFORD) append(c)
                if (length == INVITE_LEN) break
            }
        }

        fun cleanName(s: String): String =
            s.split(Regex("\\s+")).filter { it.isNotEmpty() }.joinToString(" ").take(Limits.NAME_MAX)

        /** Ввод юзернейма: нижний регистр, только допустимые символы, не длиннее 32. */
        fun filterUsername(raw: String): String =
            raw.removePrefix("@").lowercase().filter { it in 'a'..'z' || it in '0'..'9' || it == '_' }.take(32)

        fun usernameHint(u: String): String? = when {
            u.isEmpty() -> null
            u.length < 3 -> "Минимум 3 символа"
            u.length > 32 -> "Максимум 32 символа"
            !Limits.USERNAME.matches(u) -> "Только латиница a–z, цифры и _"
            else -> null
        }
    }
}
