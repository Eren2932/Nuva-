package app.nuva.ui.onboarding

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.nuva.core.InitResult
import app.nuva.ui.AppGraph
import app.nuva.ui.components.NuvaMark
import app.nuva.ui.components.PrimaryButton
import app.nuva.ui.nav.Screen
import app.nuva.ui.theme.NuvaColors
import kotlin.math.PI

/**
 * Заставка. Знак 96dp строго по центру на фоне Night — ровно то же, что рисует системная
 * заставка Android (splash_mark.xml), поэтому подмена незаметна: ни вспышки, ни скачка.
 * Искусственных задержек нет: экран живёт ровно столько, сколько идёт init().
 */
@Composable
fun SplashScreen(graph: AppGraph) {
    LaunchedEffect(Unit) {
        when (val r = graph.init()) {
            is InitResult.CryptoUnavailable -> graph.router.replaceAll(Screen.Fatal(
                "Не удалось загрузить модуль шифрования на этом устройстве.\n\n${r.reason}"))
            is InitResult.Ready -> graph.router.replaceAll(if (r.hasAccount) Screen.Chats else Screen.Welcome)
        }
    }
    Box(Modifier.fillMaxSize().background(NuvaColors.Night), contentAlignment = Alignment.Center) {
        NuvaMark(96.dp)
    }
}

@Composable
fun WelcomeScreen(graph: AppGraph) {
    val t = rememberInfiniteTransition(label = "orbit")
    val orbit by t.animateFloat(0f, (2 * PI).toFloat(),
        infiniteRepeatable(tween(9_000, easing = LinearEasing)), label = "orbit")
    val glow by t.animateFloat(0.6f, 1f,
        infiniteRepeatable(tween(1_400), RepeatMode.Reverse), label = "glow")
    // Знак «въезжает» из положения заставки вверх, текст проявляется следом.
    val rise = remember { Animatable(0f) }
    LaunchedEffect(Unit) { rise.animateTo(1f, tween(650)) }

    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).systemBarsPadding()
            .padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.weight(1f))
        NuvaMark(112.dp, orbit = orbit, glow = glow)
        Spacer(Modifier.height(32.dp))
        Column(Modifier.alpha(rise.value), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Nuva", fontSize = 34.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            Text(
                "Переписка, которую видите только вы.\nКлючи шифрования создаются и хранятся на этом устройстве.",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
            )
        }
        Spacer(Modifier.weight(1.2f))
        Column(Modifier.fillMaxWidth().alpha(rise.value).navigationBarsPadding().padding(bottom = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
            PrimaryButton("Начать", onClick = { graph.router.push(Screen.Invite) })
            Text(
                "Регистрация по приглашению · v${graph.core.versionName}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
fun FatalScreen(message: String) {
    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).systemBarsPadding().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        NuvaMark(72.dp, modifier = Modifier.alpha(0.5f))
        Spacer(Modifier.height(24.dp))
        Text("Nuva не может запуститься", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(12.dp))
        Text(message, style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
    }
}
