"""Пул asyncpg и применение миграций."""
from __future__ import annotations

import logging
from pathlib import Path

import asyncpg

from .config import Settings

log = logging.getLogger("nuva.db")

# Произвольная константа для pg_advisory_xact_lock: два процесса не накатят миграции одновременно.
_MIGRATION_LOCK_ID = 0x4E555641  # "NUVA"


async def create_pool(settings: Settings) -> asyncpg.Pool:
    pool = await asyncpg.create_pool(
        dsn=settings.database_url,
        min_size=settings.db_pool_min,
        max_size=settings.db_pool_max,
        command_timeout=settings.db_command_timeout_s,
    )
    if pool is None:  # create_pool типизирован как Optional
        raise RuntimeError("asyncpg.create_pool returned None")
    return pool


async def apply_migrations(pool: asyncpg.Pool, directory: Path) -> list[str]:
    """Накатывает migrations/*.sql по порядку имён. Каждый файл — ровно один раз."""
    files = sorted(p for p in directory.glob("*.sql") if p.is_file())
    if not files:
        raise RuntimeError(f"no migrations found in {directory}")
    applied_now: list[str] = []
    async with pool.acquire() as con:
        async with con.transaction():
            await con.execute("SELECT pg_advisory_xact_lock($1)", _MIGRATION_LOCK_ID)
            await con.execute(
                "CREATE TABLE IF NOT EXISTS schema_migrations ("
                " version TEXT PRIMARY KEY,"
                " applied_at TIMESTAMPTZ NOT NULL DEFAULT now())"
            )
            done = {r["version"] for r in await con.fetch("SELECT version FROM schema_migrations")}
            for path in files:
                if path.stem in done:
                    continue
                # Без аргументов execute идёт простым протоколом: несколько стейтментов допустимы.
                await con.execute(path.read_text("utf-8"))
                await con.execute("INSERT INTO schema_migrations (version) VALUES ($1)", path.stem)
                applied_now.append(path.stem)
    for v in applied_now:
        log.info("migration applied: %s", v)
    return applied_now
