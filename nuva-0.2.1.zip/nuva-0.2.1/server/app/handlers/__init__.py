"""Обработчики фреймов. Общий контекст соединения и сигнал закрытия."""
from __future__ import annotations

import time
import uuid
from collections import deque
from dataclasses import dataclass, field

import asyncpg

from ..config import Settings
from ..hub import Connection, Hub


class CloseSession(Exception):
    """Обработчик требует закрыть соединение с кодом (после отправки error, если нужно)."""

    def __init__(self, code: int, reason: str = ""):
        super().__init__(reason)
        self.code = code
        self.reason = reason


@dataclass(slots=True)
class Session:
    conn: Connection
    nonce: bytes
    settings: Settings
    pool: asyncpg.Pool
    hub: Hub
    register_attempts: int = 0
    lookup_times: deque[float] = field(default_factory=deque)
    send_times: deque[float] = field(default_factory=deque)
    account_id: uuid.UUID | None = field(default=None)
    device_id: uuid.UUID | None = field(default=None)

    @property
    def authenticated(self) -> bool:
        return self.device_id is not None

    async def become_authenticated(self, account_id: uuid.UUID, device_id: uuid.UUID) -> None:
        """Порядок важен (§5.5): сначала хаб, потом выгрузка очереди по курсору."""
        self.account_id = account_id
        self.device_id = device_id
        self.conn.account_id = account_id
        self.conn.device_id = device_id
        await self.hub.register(self.conn)


def within_rate(times: deque[float], limit: int, window_s: float = 60.0) -> bool:
    """Скользящее окно: True — действие разрешено (и учтено)."""
    now = time.monotonic()
    while times and now - times[0] >= window_s:
        times.popleft()
    if len(times) >= limit:
        return False
    times.append(now)
    return True
