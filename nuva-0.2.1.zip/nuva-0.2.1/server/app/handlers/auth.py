"""auth.response (§5.3) и выгрузка офлайн-очереди после входа."""
from __future__ import annotations

import logging

from .. import crypto, protocol
from ..protocol import AuthResponse
from . import CloseSession, Session

log = logging.getLogger("nuva.auth")

_SQL_DEVICE = """
SELECT d.account_id, d.identity_key, d.revoked_at, a.status
  FROM devices d
  JOIN accounts a ON a.id = d.account_id
 WHERE d.id = $1
"""

_SQL_TOUCH = """
UPDATE devices SET last_seen_on = current_date
 WHERE id = $1 AND last_seen_on IS DISTINCT FROM current_date
"""

_SQL_PENDING = """
SELECT count(*) FROM messages WHERE recipient_device_id = $1 AND expires_at > now()
"""

_SQL_QUEUE_BATCH = """
SELECT m.server_id, m.sender_device_id, s.account_id AS sender_account_id,
       m.client_msg_id, m.envelope, m.created_at
  FROM messages m
  LEFT JOIN devices s ON s.id = m.sender_device_id
 WHERE m.recipient_device_id = $1 AND m.server_id > $2 AND m.expires_at > now()
 ORDER BY m.server_id
 LIMIT $3
"""


async def handle_auth_response(s: Session, frame: AuthResponse) -> None:
    async with s.pool.acquire() as con:
        row = await con.fetchrow(_SQL_DEVICE, frame.device_id)
    payload = crypto.auth_payload(s.settings.server_host, frame.device_id, s.nonce)
    ok = (
        row is not None
        and row["revoked_at"] is None
        and row["status"] == "active"
        and crypto.verify_ed25519(bytes(row["identity_key"]), payload, frame.sig)
    )
    if not ok:
        log.info("auth failed for device %s", frame.device_id)
        await s.conn.send(protocol.error(protocol.E_AUTH_FAILED, frame.id))
        raise CloseSession(protocol.CLOSE_UNAUTHORIZED, "auth failed")

    await s.become_authenticated(row["account_id"], frame.device_id)
    async with s.pool.acquire() as con:
        await con.execute(_SQL_TOUCH, frame.device_id)
        pending = int(await con.fetchval(_SQL_PENDING, frame.device_id))
    await s.conn.send(protocol.auth_ok(frame.id, row["account_id"], frame.device_id, pending))
    log.info("device %s authenticated, pending=%d", frame.device_id, pending)
    await drain_queue(s)


async def drain_queue(s: Session) -> int:
    """Выгружает очередь пачками по курсору server_id, в конце queue.empty.

    Ничего не удаляет: удаление только по msg.ack (at-least-once, §5.5).
    """
    assert s.device_id is not None
    cursor, sent = 0, 0
    while True:
        async with s.pool.acquire() as con:
            rows = await con.fetch(_SQL_QUEUE_BATCH, s.device_id, cursor, s.settings.queue_batch)
        for r in rows:
            await s.conn.send(protocol.msg_deliver(
                server_id=r["server_id"],
                from_account=r["sender_account_id"],
                from_device=r["sender_device_id"],
                client_msg_id=r["client_msg_id"],
                envelope=bytes(r["envelope"]),
                server_ts=int(r["created_at"].timestamp() * 1000),
            ))
            cursor = r["server_id"]
            sent += 1
        if len(rows) < s.settings.queue_batch:
            break
    await s.conn.send(protocol.queue_empty())
    return sent
