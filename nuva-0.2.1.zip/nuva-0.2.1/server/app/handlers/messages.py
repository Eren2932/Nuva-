"""msg.send / msg.ack (протокол 0.2, §5.9): store-and-forward зашифрованных конвертов.

Сервер не видит содержимого: только кому (device_id), от какого устройства и размер.
Порядок: INSERT + COMMIT → только потом push онлайн-получателю. Удаление — только по msg.ack
самого получателя (at-least-once; клиент дедуплицирует по server_id / client_msg_id).
"""
from __future__ import annotations

import logging

from .. import protocol
from ..protocol import MsgAck, MsgSend, now_ms
from . import Session, within_rate

log = logging.getLogger("nuva.messages")

_SQL_RECIPIENT_DEVICES = """
SELECT d.id
  FROM devices d
  JOIN accounts a ON a.id = d.account_id
 WHERE d.account_id = $1 AND d.revoked_at IS NULL AND a.status = 'active'
"""

# Идемпотентность: повтор того же client_msg_id не создаёт дублей (UNIQUE в 0001_init.sql).
_SQL_INSERT = """
INSERT INTO messages (recipient_device_id, sender_device_id, client_msg_id, envelope)
SELECT t.r, $2, $3, t.e FROM unnest($1::uuid[], $4::bytea[]) AS t(r, e)
ON CONFLICT (sender_device_id, client_msg_id, recipient_device_id) DO NOTHING
RETURNING server_id, recipient_device_id, envelope, created_at
"""

_SQL_ACK = """
DELETE FROM messages WHERE recipient_device_id = $1 AND server_id = ANY($2::bigint[])
"""


async def handle_msg_send(s: Session, frame: MsgSend) -> None:
    if not within_rate(s.send_times, s.settings.sends_per_minute):
        await s.conn.send(protocol.error(protocol.E_RATE_LIMITED, frame.id, "too many messages"))
        return
    if len(frame.envelopes) > s.settings.max_envelopes_per_send:
        await s.conn.send(protocol.error(protocol.E_BAD_REQUEST, frame.id, "too many envelopes"))
        return
    if any(len(e.envelope) > s.settings.max_envelope_bytes for e in frame.envelopes):
        await s.conn.send(protocol.error(protocol.E_PAYLOAD_TOO_LARGE, frame.id, "envelope too large"))
        return
    given = [e.device_id for e in frame.envelopes]
    if len(set(given)) != len(given):
        await s.conn.send(protocol.error(protocol.E_BAD_REQUEST, frame.id, "duplicate device_id"))
        return

    async with s.pool.acquire() as con:
        active = {r["id"] for r in await con.fetch(_SQL_RECIPIENT_DEVICES, frame.to)}
        if not active:
            await s.conn.send(protocol.error(protocol.E_NOT_FOUND, frame.id))
            return
        if active != set(given):
            # Клиент обновляет список устройств через user.lookup и шифрует заново.
            await s.conn.send(protocol.error(
                protocol.E_DEVICES_MISMATCH, frame.id, details={
                    "missing": sorted(str(d) for d in active - set(given)),
                    "extra": sorted(str(d) for d in set(given) - active),
                }))
            return
        async with con.transaction():
            rows = await con.fetch(_SQL_INSERT, given, s.device_id, frame.client_msg_id,
                                   [e.envelope for e in frame.envelopes])

    for r in rows:
        await s.hub.send_to(r["recipient_device_id"], protocol.msg_deliver(
            server_id=r["server_id"], from_account=s.account_id, from_device=s.device_id,
            client_msg_id=frame.client_msg_id, envelope=bytes(r["envelope"]),
            server_ts=int(r["created_at"].timestamp() * 1000),
        ))
    # Повтор (все строки уже были) — тоже успех: отправитель просто не получил прошлый msg.sent.
    server_ts = int(rows[0]["created_at"].timestamp() * 1000) if rows else now_ms()
    await s.conn.send(protocol.msg_sent(frame.id, frame.client_msg_id, server_ts))


async def handle_msg_ack(s: Session, frame: MsgAck) -> None:
    """Без ответа: ack идемпотентен, чужие server_id молча игнорируются."""
    async with s.pool.acquire() as con:
        await con.execute(_SQL_ACK, s.device_id, list(frame.server_ids))
