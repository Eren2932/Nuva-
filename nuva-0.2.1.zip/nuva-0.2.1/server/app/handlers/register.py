"""account.register (§5.3): инвайт + юзернейм + ключи устройства, одной транзакцией (§3)."""
from __future__ import annotations

import logging
import re

import asyncpg

from .. import crypto, protocol
from ..protocol import AccountRegister
from . import CloseSession, Session

log = logging.getLogger("nuva.register")

# Клиент нормализует (lower-case) ДО подписи; сервер не меняет строку, иначе подпись разъедется.
USERNAME_RE = re.compile(r"^[a-z0-9_]{3,32}$")

_SQL_USE_INVITE = """
UPDATE invites
   SET use_count = use_count + 1
 WHERE code_hash = $1
   AND revoked_at IS NULL
   AND expires_at > now()
   AND use_count < max_uses
RETURNING code_hash
"""

_SQL_INSERT_ACCOUNT = """
INSERT INTO accounts (id, username, invite_code_hash) VALUES ($1, $2, $3)
"""

_SQL_INSERT_DEVICE = """
INSERT INTO devices (id, account_id, identity_key, x25519_key, x25519_sig, platform, last_seen_on)
VALUES ($1, $2, $3, $4, $5, $6, current_date)
"""


class _RegisterRejected(Exception):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code
        self.message = message


async def handle_register(s: Session, frame: AccountRegister) -> None:
    s.register_attempts += 1
    if s.register_attempts > s.settings.register_attempts_per_conn:
        await s.conn.send(protocol.error(protocol.E_RATE_LIMITED, frame.id, "too many attempts"))
        raise CloseSession(protocol.CLOSE_RATE_LIMIT, "register attempts exceeded")

    dev = frame.device
    # 1. Подписи: XK подписан IK; весь запрос подписан IK и привязан к nonce и HOST.
    xk_ok = crypto.verify_ed25519(dev.identity_key, crypto.xk_payload(dev.x25519_key), dev.x25519_sig)
    reg_ok = crypto.verify_ed25519(
        dev.identity_key,
        crypto.reg_payload(s.settings.server_host, s.nonce, dev.identity_key, dev.x25519_key,
                           frame.username),
        frame.sig,
    )
    if not (xk_ok and reg_ok):
        await s.conn.send(protocol.error(protocol.E_AUTH_FAILED, frame.id, "bad signature"))
        raise CloseSession(protocol.CLOSE_UNAUTHORIZED, "bad signature")

    # 2. Формат юзернейма и инвайта — до похода в БД.
    if not USERNAME_RE.fullmatch(frame.username):
        await s.conn.send(protocol.error(
            protocol.E_USERNAME_INVALID, frame.id, "3-32 chars: a-z, 0-9, _ (lower-case)"))
        return
    if not crypto.invite_well_formed(frame.invite):
        await s.conn.send(protocol.error(protocol.E_INVITE_INVALID, frame.id))
        return

    account_id, device_id = crypto.uuid7(), crypto.uuid7()
    code_hash = crypto.invite_hash(frame.invite)
    try:
        async with s.pool.acquire() as con:
            async with con.transaction():
                used = await con.fetchval(_SQL_USE_INVITE, code_hash)
                if used is None:
                    raise _RegisterRejected(protocol.E_INVITE_INVALID, "invite invalid or used")
                try:
                    await con.execute(_SQL_INSERT_ACCOUNT, account_id, frame.username, code_hash)
                    await con.execute(_SQL_INSERT_DEVICE, device_id, account_id, dev.identity_key,
                                      dev.x25519_key, dev.x25519_sig, dev.platform)
                except asyncpg.UniqueViolationError as exc:
                    if exc.constraint_name == "accounts_username_key":
                        raise _RegisterRejected(protocol.E_USERNAME_TAKEN, "username taken") from None
                    if exc.constraint_name == "devices_identity_key_key":
                        raise _RegisterRejected(protocol.E_BAD_REQUEST,
                                                "identity key already registered") from None
                    raise
    except _RegisterRejected as rej:
        # Транзакция откатилась целиком: инвайт не сгорел.
        await s.conn.send(protocol.error(rej.code, frame.id, rej.message))
        return

    await s.become_authenticated(account_id, device_id)
    await s.conn.send(protocol.account_registered(frame.id, account_id, device_id))
    await s.conn.send(protocol.queue_empty())
    log.info("account registered, device %s", device_id)
