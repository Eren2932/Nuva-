"""Реестр активных соединений device_id → Connection (в памяти, 1 воркер, §2).

При >1 воркере у каждого процесса свой реестр — нужна маршрутизация через Redis pub/sub.
"""
from __future__ import annotations

import asyncio
import logging
import uuid
from typing import Any

from starlette.websockets import WebSocket, WebSocketState

from . import protocol

log = logging.getLogger("nuva.hub")


class Connection:
    """Обёртка над WebSocket: сериализованная отправка и идемпотентное закрытие."""

    __slots__ = ("ws", "_send_lock", "_closed", "device_id", "account_id")

    def __init__(self, ws: WebSocket):
        self.ws = ws
        self._send_lock = asyncio.Lock()
        self._closed = False
        self.device_id: uuid.UUID | None = None
        self.account_id: uuid.UUID | None = None

    @property
    def closed(self) -> bool:
        return self._closed or self.ws.application_state != WebSocketState.CONNECTED

    async def send(self, frame: dict[str, Any]) -> None:
        text = protocol.dumps(frame)
        async with self._send_lock:
            if self.closed:
                raise ConnectionError("connection closed")
            await self.ws.send_text(text)

    async def close(self, code: int, reason: str = "") -> None:
        async with self._send_lock:
            if self._closed:
                return
            self._closed = True
            if self.ws.application_state == WebSocketState.CONNECTED:
                try:
                    await self.ws.close(code=code, reason=reason[:120])
                except Exception:  # noqa: BLE001 — клиент уже ушёл (WebSocketDisconnect/OSError)
                    pass


class Hub:
    def __init__(self) -> None:
        self._conns: dict[uuid.UUID, Connection] = {}
        self._lock = asyncio.Lock()

    async def register(self, conn: Connection) -> None:
        """Одно активное соединение на устройство: новое вытесняет старое (4409)."""
        if conn.device_id is None:
            raise ValueError("connection is not authenticated")
        async with self._lock:
            old = self._conns.get(conn.device_id)
            self._conns[conn.device_id] = conn
        if old is not None and old is not conn:
            log.info("device %s: previous connection replaced", conn.device_id)
            await old.close(protocol.CLOSE_REPLACED, "replaced by a new connection")

    async def unregister(self, conn: Connection) -> None:
        if conn.device_id is None:
            return
        async with self._lock:
            if self._conns.get(conn.device_id) is conn:
                del self._conns[conn.device_id]

    def get(self, device_id: uuid.UUID) -> Connection | None:
        return self._conns.get(device_id)

    def is_online(self, device_id: uuid.UUID) -> bool:
        return device_id in self._conns

    async def send_to(self, device_id: uuid.UUID, frame: dict[str, Any]) -> bool:
        """True — фрейм ушёл в сокет. False — устройства нет онлайн или сокет умер
        (конверт остаётся в очереди и доедет при следующем входе)."""
        conn = self._conns.get(device_id)
        if conn is None:
            return False
        try:
            await conn.send(frame)
            return True
        except Exception:  # noqa: BLE001 — мёртвый сокет: WebSocketDisconnect, OSError, RuntimeError
            await self.unregister(conn)
            return False

    def __len__(self) -> int:
        return len(self._conns)

    async def close_all(self, code: int = 1001, reason: str = "server shutdown") -> None:
        async with self._lock:
            conns = list(self._conns.values())
            self._conns.clear()
        await asyncio.gather(*(c.close(code, reason) for c in conns), return_exceptions=True)
