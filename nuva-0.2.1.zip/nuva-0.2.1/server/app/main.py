"""Точка входа: FastAPI + WebSocket-шлюз /ws (§5).

Запуск (PoC — строго 1 воркер, хаб в памяти):
    uvicorn app.main:app --host 0.0.0.0 --port 8000 --workers 1 --no-access-log --ws-max-size 262144
"""
from __future__ import annotations

import asyncio
import logging
from contextlib import asynccontextmanager
from typing import AsyncIterator

from fastapi import FastAPI, WebSocket
from fastapi.responses import JSONResponse
from starlette.websockets import WebSocketDisconnect

from . import protocol
from .config import get_settings
from .crypto import new_nonce
from .db import apply_migrations, create_pool
from .handlers import CloseSession, Session
from .handlers.auth import handle_auth_response
from .handlers.messages import handle_msg_ack, handle_msg_send
from .handlers.profile import handle_profile_set, handle_user_lookup
from .handlers.register import handle_register
from .hub import Connection, Hub
from .protocol import (AccountRegister, AuthResponse, FrameInvalid, MsgAck, MsgSend, Ping,
                       ProfileSet, ProtocolViolation, UserLookup)

SERVER_VERSION = "0.2.0"

log = logging.getLogger("nuva")


def _setup_logging(level: str) -> None:
    logging.basicConfig(level=level.upper(),
                        format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    # Access-лог uvicorn содержит IP клиента — глушим и здесь, не только флагом запуска.
    logging.getLogger("uvicorn.access").disabled = True


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    settings = get_settings()
    _setup_logging(settings.log_level)
    pool = await create_pool(settings)
    if settings.apply_migrations_on_start:
        await apply_migrations(pool, settings.migrations_dir)
    app.state.settings = settings
    app.state.pool = pool
    app.state.hub = Hub()
    log.info("nuva server started, host=%s", settings.server_host)
    try:
        yield
    finally:
        await app.state.hub.close_all()
        await pool.close()
        log.info("nuva server stopped")


app = FastAPI(title="nuva", docs_url=None, redoc_url=None, openapi_url=None, lifespan=lifespan)


@app.get("/healthz")
async def healthz() -> JSONResponse:
    try:
        async with app.state.pool.acquire() as con:
            await con.fetchval("SELECT 1")
    except Exception:  # noqa: BLE001 — health не должен падать трейсом
        return JSONResponse({"status": "degraded"}, status_code=503)
    return JSONResponse({"status": "ok", "online": len(app.state.hub), "version": SERVER_VERSION})


class _Disconnected(Exception):
    pass


async def _receive_text(conn: Connection, max_bytes: int) -> str:
    msg = await conn.ws.receive()
    if msg["type"] == "websocket.disconnect":
        raise _Disconnected()
    text = msg.get("text")
    if text is None:
        raise CloseSession(protocol.CLOSE_PROTOCOL, "binary frames are not supported in v1")
    if len(text) > max_bytes or len(text.encode("utf-8")) > max_bytes:
        await conn.send(protocol.error(protocol.E_PAYLOAD_TOO_LARGE, None, "frame too large"))
        raise CloseSession(protocol.CLOSE_PROTOCOL, "frame too large")
    return text


async def _pre_auth(s: Session) -> None:
    """До авторизации: только account.register / auth.response, таймаут 10 с на всё."""
    loop = asyncio.get_running_loop()
    deadline = loop.time() + s.settings.auth_timeout_s
    while not s.authenticated:
        remaining = deadline - loop.time()
        if remaining <= 0:
            raise CloseSession(protocol.CLOSE_AUTH_TIMEOUT, "auth timeout")
        try:
            text = await asyncio.wait_for(_receive_text(s.conn, s.settings.max_frame_bytes), remaining)
        except TimeoutError:
            raise CloseSession(protocol.CLOSE_AUTH_TIMEOUT, "auth timeout") from None
        obj = _parse_or_close(text)
        if obj.get("type") not in protocol.PRE_AUTH_TYPES:
            raise CloseSession(protocol.CLOSE_UNAUTHORIZED, "authenticate first")
        try:
            frame = protocol.validate_frame(obj)
        except FrameInvalid as exc:
            await s.conn.send(protocol.error(protocol.E_BAD_REQUEST, exc.frame_id, str(exc)))
            continue
        if isinstance(frame, AccountRegister):
            await handle_register(s, frame)
        elif isinstance(frame, AuthResponse):
            await handle_auth_response(s, frame)


async def _authenticated(s: Session) -> None:
    while True:
        try:
            text = await asyncio.wait_for(_receive_text(s.conn, s.settings.max_frame_bytes),
                                          s.settings.idle_timeout_s)
        except TimeoutError:
            raise CloseSession(protocol.CLOSE_NORMAL, "idle timeout") from None
        obj = _parse_or_close(text)
        try:
            frame = protocol.validate_frame(obj)
        except FrameInvalid as exc:
            await s.conn.send(protocol.error(protocol.E_BAD_REQUEST, exc.frame_id, str(exc)))
            continue
        if isinstance(frame, Ping):
            await s.conn.send(protocol.pong(frame.id))
        elif isinstance(frame, MsgSend):
            await handle_msg_send(s, frame)
        elif isinstance(frame, MsgAck):
            await handle_msg_ack(s, frame)
        elif isinstance(frame, UserLookup):
            await handle_user_lookup(s, frame)
        elif isinstance(frame, ProfileSet):
            await handle_profile_set(s, frame)
        else:
            await s.conn.send(protocol.error(protocol.E_BAD_REQUEST, frame.id, "already authenticated"))


def _parse_or_close(text: str) -> dict:
    try:
        return protocol.parse_json(text)
    except ProtocolViolation as exc:
        raise CloseSession(protocol.CLOSE_PROTOCOL, str(exc)) from None


@app.websocket("/ws")
async def ws_endpoint(websocket: WebSocket) -> None:
    offered = websocket.scope.get("subprotocols") or []
    if protocol.SUBPROTOCOL not in offered:
        await websocket.accept()
        await websocket.close(code=protocol.CLOSE_PROTOCOL, reason="subprotocol nuva.v1 required")
        return
    await websocket.accept(subprotocol=protocol.SUBPROTOCOL)

    conn = Connection(websocket)
    s = Session(conn=conn, nonce=new_nonce(), settings=app.state.settings,
                pool=app.state.pool, hub=app.state.hub)
    try:
        await conn.send(protocol.auth_challenge(s.nonce))
        await _pre_auth(s)
        await _authenticated(s)
    except CloseSession as cs:
        await conn.close(cs.code, cs.reason)
    except (_Disconnected, WebSocketDisconnect, ConnectionError):
        pass
    except Exception:  # noqa: BLE001
        # Без содержимого фреймов и без IP: только тип исключения и device_id.
        log.exception("unhandled error, device=%s", s.device_id)
        try:
            await conn.send(protocol.error(protocol.E_INTERNAL))
        except Exception:  # noqa: BLE001
            pass
        await conn.close(1011, "internal error")
    finally:
        await s.hub.unregister(conn)
