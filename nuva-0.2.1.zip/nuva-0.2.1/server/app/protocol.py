"""WebSocket-протокол v1 (§5): разбор клиентских фреймов и сборка серверных.

Правила (§6.2 спецификации):
  * кривой JSON / не объект           → ProtocolViolation → закрытие 4400;
  * неизвестный type / неверные поля  → FrameInvalid      → error bad_request (соединение живёт).
"""
from __future__ import annotations

import json
import time
import uuid
from typing import Annotated, Any, Callable, Literal, Union

from pydantic import (BaseModel, ConfigDict, Field, PlainValidator, StrictInt, TypeAdapter,
                      ValidationError, model_validator)

from .crypto import B64Error, b64url_decode, b64url_encode

PROTOCOL_VERSION = 1
SUBPROTOCOL = "nuva.v1"

# Коды закрытия WS (§5.6).
CLOSE_NORMAL = 1000
CLOSE_PROTOCOL = 4400
CLOSE_UNAUTHORIZED = 4401
CLOSE_AUTH_TIMEOUT = 4408
CLOSE_REPLACED = 4409
CLOSE_RATE_LIMIT = 4429

# Коды ошибок (§5.6).
E_BAD_REQUEST = "bad_request"
E_UNAUTHORIZED = "unauthorized"
E_AUTH_FAILED = "auth_failed"
E_INVITE_INVALID = "invite_invalid"
E_USERNAME_TAKEN = "username_taken"
E_USERNAME_INVALID = "username_invalid"
E_NOT_FOUND = "not_found"
E_DEVICES_MISMATCH = "devices_mismatch"
E_PAYLOAD_TOO_LARGE = "payload_too_large"
E_RATE_LIMITED = "rate_limited"
E_INTERNAL = "internal"

T_REGISTER = "account.register"
T_AUTH_RESPONSE = "auth.response"
T_PING = "ping"
T_PROFILE_SET = "profile.set"
T_USER_LOOKUP = "user.lookup"
T_MSG_SEND = "msg.send"
T_MSG_ACK = "msg.ack"
PRE_AUTH_TYPES = frozenset({T_REGISTER, T_AUTH_RESPONSE})

NAME_MAX = 64          # кодовых точек; имя/фамилия — публичный профиль (как юзернейм)
ACK_MAX = 100          # server_id в одном msg.ack


class ProtocolViolation(Exception):
    """Нарушение уровня транспорта/JSON: соединение закрывается 4400."""


class FrameInvalid(Exception):
    """Фрейм разобран как JSON, но не прошёл схему: ответ error bad_request."""

    def __init__(self, message: str, frame_id: str | None):
        super().__init__(message)
        self.frame_id = frame_id


# ── Типы полей ──

def _b64_exact(n: int) -> Callable[[Any], bytes]:
    def validate(value: Any) -> bytes:
        if not isinstance(value, str):
            raise ValueError("expected base64url string")
        try:
            raw = b64url_decode(value)
        except B64Error as exc:
            raise ValueError(str(exc)) from exc
        if len(raw) != n:
            raise ValueError(f"expected {n} bytes")
        return raw
    return validate


def _b64_any(value: Any) -> bytes:
    if not isinstance(value, str):
        raise ValueError("expected base64url string")
    try:
        raw = b64url_decode(value)
    except B64Error as exc:
        raise ValueError(str(exc)) from exc
    if not raw:
        raise ValueError("empty")
    return raw


# Запрещены управляющие символы, переводы строк и bidi-override (подмена имени справа-налево).
_FORBIDDEN_NAME_CHARS = frozenset(
    [chr(c) for c in range(0x00, 0x20)] + [chr(0x7F)] + [chr(c) for c in range(0x80, 0xA0)]
    + ["\u2028", "\u2029", "\u202a", "\u202b", "\u202c", "\u202d", "\u202e",
       "\u2066", "\u2067", "\u2068", "\u2069", "\ufeff"]
)


def _name(required: bool) -> Callable[[Any], str]:
    def validate(value: Any) -> str:
        if not isinstance(value, str):
            raise ValueError("expected string")
        v = " ".join(value.split())  # trim + схлопывание пробелов
        if any(ch in _FORBIDDEN_NAME_CHARS for ch in v):
            raise ValueError("forbidden characters")
        if len(v) > NAME_MAX:
            raise ValueError(f"max {NAME_MAX} chars")
        if required and not v:
            raise ValueError("required")
        return v
    return validate


Key32 = Annotated[bytes, PlainValidator(_b64_exact(32))]
Blob = Annotated[bytes, PlainValidator(_b64_any)]
FirstName = Annotated[str, PlainValidator(_name(True))]
LastName = Annotated[str, PlainValidator(_name(False))]
ServerId = Annotated[StrictInt, Field(gt=0, lt=2**63)]
Sig64 = Annotated[bytes, PlainValidator(_b64_exact(64))]
FrameId = Annotated[str, Field(min_length=1, max_length=64)]


class _Frame(BaseModel):
    # extra="ignore": новые необязательные поля от свежих клиентов не ломают старый сервер.
    model_config = ConfigDict(extra="ignore", frozen=True)
    v: Literal[1]


class DeviceKeys(BaseModel):
    model_config = ConfigDict(extra="ignore", frozen=True)
    identity_key: Key32
    x25519_key: Key32
    x25519_sig: Sig64
    platform: Literal["android", "desktop", "ios"]


class AccountRegister(_Frame):
    type: Literal["account.register"]
    id: FrameId
    invite: Annotated[str, Field(min_length=1, max_length=32)]
    # Формат юзернейма проверяет обработчик (нужен отдельный код username_invalid).
    username: Annotated[str, Field(min_length=1, max_length=64)]
    device: DeviceKeys
    sig: Sig64


class AuthResponse(_Frame):
    type: Literal["auth.response"]
    id: FrameId
    device_id: uuid.UUID
    sig: Sig64


class Ping(_Frame):
    type: Literal["ping"]
    id: FrameId | None = None


class ProfileSet(_Frame):
    type: Literal["profile.set"]
    id: FrameId
    first_name: FirstName
    last_name: LastName = ""


class UserLookup(_Frame):
    """Поиск строго по точному юзернейму или по account_id (префиксного поиска нет: анти-перебор)."""
    type: Literal["user.lookup"]
    id: FrameId
    username: Annotated[str, Field(min_length=1, max_length=64)] | None = None
    account_id: uuid.UUID | None = None

    @model_validator(mode="after")
    def _exactly_one(self) -> "UserLookup":
        if (self.username is None) == (self.account_id is None):
            raise ValueError("exactly one of username / account_id")
        return self


class OutEnvelope(BaseModel):
    model_config = ConfigDict(extra="ignore", frozen=True)
    device_id: uuid.UUID
    envelope: Blob


class MsgSend(_Frame):
    type: Literal["msg.send"]
    id: FrameId
    to: uuid.UUID
    client_msg_id: uuid.UUID
    envelopes: Annotated[list[OutEnvelope], Field(min_length=1, max_length=100)]


class MsgAck(_Frame):
    type: Literal["msg.ack"]
    id: FrameId | None = None
    server_ids: Annotated[list[ServerId], Field(min_length=1, max_length=ACK_MAX)]


AnyClientFrame = Union[AccountRegister, AuthResponse, Ping, ProfileSet, UserLookup, MsgSend, MsgAck]
ClientFrame = Annotated[AnyClientFrame, Field(discriminator="type")]
_adapter: TypeAdapter[Any] = TypeAdapter(ClientFrame)


def parse_json(text: str) -> dict[str, Any]:
    try:
        obj = json.loads(text)
    except (ValueError, RecursionError) as exc:
        raise ProtocolViolation("malformed json") from exc
    if not isinstance(obj, dict):
        raise ProtocolViolation("frame must be a json object")
    return obj


def frame_id_of(obj: dict[str, Any]) -> str | None:
    fid = obj.get("id")
    return fid if isinstance(fid, str) and 0 < len(fid) <= 64 else None


def validate_frame(obj: dict[str, Any]) -> AnyClientFrame:
    try:
        return _adapter.validate_python(obj)
    except ValidationError as exc:
        first = exc.errors(include_url=False, include_input=False)[0]
        loc = ".".join(str(p) for p in first.get("loc", ()))
        kind = first.get("type", "invalid")
        if kind in ("union_tag_invalid", "union_tag_not_found"):
            msg = "unknown frame type"
        else:
            msg = f"invalid field {loc}: {kind}" if loc else f"invalid frame: {kind}"
        raise FrameInvalid(msg, frame_id_of(obj)) from None


# ── Серверные фреймы ──

def now_ms() -> int:
    return time.time_ns() // 1_000_000


def _f(type_: str, frame_id: str | None = None, **fields: Any) -> dict[str, Any]:
    out: dict[str, Any] = {"v": PROTOCOL_VERSION, "type": type_}
    if frame_id is not None:
        out["id"] = frame_id
    out.update(fields)
    return out


def auth_challenge(nonce: bytes) -> dict[str, Any]:
    return _f("auth.challenge", nonce=b64url_encode(nonce), server_time=now_ms())


def account_registered(frame_id: str, account_id: uuid.UUID, device_id: uuid.UUID) -> dict[str, Any]:
    return _f("account.registered", frame_id, account_id=str(account_id), device_id=str(device_id))


def auth_ok(frame_id: str, account_id: uuid.UUID, device_id: uuid.UUID, pending: int) -> dict[str, Any]:
    return _f("auth.ok", frame_id, account_id=str(account_id), device_id=str(device_id), pending=pending)


def msg_deliver(server_id: int, from_account: uuid.UUID | None, from_device: uuid.UUID | None,
                client_msg_id: uuid.UUID, envelope: bytes, server_ts: int) -> dict[str, Any]:
    return _f("msg.deliver", server_id=server_id,
              from_account=str(from_account) if from_account else None,
              from_device=str(from_device) if from_device else None,
              client_msg_id=str(client_msg_id), envelope=b64url_encode(envelope), server_ts=server_ts)


def profile_ok(frame_id: str, first_name: str, last_name: str) -> dict[str, Any]:
    return _f("profile.ok", frame_id, first_name=first_name, last_name=last_name)


def user_info(frame_id: str, account_id: uuid.UUID, username: str, first_name: str, last_name: str,
              devices: list[dict[str, Any]]) -> dict[str, Any]:
    return _f("user.info", frame_id, account={
        "account_id": str(account_id), "username": username,
        "first_name": first_name, "last_name": last_name, "devices": devices,
    })


def device_info(device_id: uuid.UUID, identity_key: bytes, x25519_key: bytes,
                x25519_sig: bytes) -> dict[str, Any]:
    return {"device_id": str(device_id), "identity_key": b64url_encode(identity_key),
            "x25519_key": b64url_encode(x25519_key), "x25519_sig": b64url_encode(x25519_sig)}


def msg_sent(frame_id: str, client_msg_id: uuid.UUID, server_ts: int) -> dict[str, Any]:
    return _f("msg.sent", frame_id, client_msg_id=str(client_msg_id), server_ts=server_ts)


def queue_empty() -> dict[str, Any]:
    return _f("queue.empty")


def pong(frame_id: str | None) -> dict[str, Any]:
    return _f("pong", frame_id, server_time=now_ms())


def error(code: str, frame_id: str | None = None, message: str | None = None,
          details: dict[str, Any] | None = None) -> dict[str, Any]:
    fields: dict[str, Any] = {"code": code}
    if message is not None:
        fields["message"] = message
    if details is not None:
        fields["details"] = details
    return _f("error", frame_id, **fields)


def dumps(frame: dict[str, Any]) -> str:
    return json.dumps(frame, ensure_ascii=False, separators=(",", ":"))
