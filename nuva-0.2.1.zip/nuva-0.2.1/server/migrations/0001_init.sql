-- 0001_init.sql — схема PoC (NUVA_PHASE1_POC.md §3, spec 1.0.1).
-- Применяется app/db.py:apply_migrations в одной транзакции под advisory lock.
-- UUID генерирует приложение (UUIDv7, app/crypto.py:uuid7).

CREATE TABLE invites (
    code_hash   BYTEA PRIMARY KEY CHECK (octet_length(code_hash) = 32), -- SHA-256(нормализованный код)
    created_by  UUID NULL,                                              -- FK ниже; NULL = выдан админом
    max_uses    INT  NOT NULL DEFAULT 1 CHECK (max_uses > 0),
    use_count   INT  NOT NULL DEFAULT 0 CHECK (use_count >= 0),
    expires_at  TIMESTAMPTZ NOT NULL DEFAULT now() + INTERVAL '14 days',
    revoked_at  TIMESTAMPTZ NULL,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    CHECK (use_count <= max_uses)
);

CREATE TABLE accounts (
    id                UUID PRIMARY KEY,
    username          TEXT NOT NULL UNIQUE
                      CHECK (username ~ '^[a-z0-9_]{3,32}$'),            -- храним в нижнем регистре
    invite_code_hash  BYTEA NULL REFERENCES invites(code_hash) ON DELETE SET NULL,
    status            TEXT NOT NULL DEFAULT 'active'
                      CHECK (status IN ('active', 'banned', 'deleted')),
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE invites
    ADD CONSTRAINT invites_created_by_fk
    FOREIGN KEY (created_by) REFERENCES accounts(id) ON DELETE SET NULL;

CREATE TABLE devices (
    id            UUID PRIMARY KEY,
    account_id    UUID NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
    identity_key  BYTEA NOT NULL UNIQUE CHECK (octet_length(identity_key) = 32), -- Ed25519 public (IK)
    x25519_key    BYTEA NOT NULL CHECK (octet_length(x25519_key) = 32),         -- X25519 public (XK)
    x25519_sig    BYTEA NOT NULL CHECK (octet_length(x25519_sig) = 64),         -- подпись IK над XK, §4.2
    key_version   INT  NOT NULL DEFAULT 1,                                      -- ротация XK в будущем
    platform      TEXT NOT NULL CHECK (platform IN ('android', 'desktop', 'ios')),
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_seen_on  DATE NULL,                                                    -- только день: минимизация метаданных
    revoked_at    TIMESTAMPTZ NULL
);
CREATE INDEX devices_account_active_idx ON devices (account_id) WHERE revoked_at IS NULL;

-- Очередь store-and-forward: одна строка = один конверт для одного устройства.
CREATE TABLE messages (
    server_id            BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    recipient_device_id  UUID NOT NULL REFERENCES devices(id) ON DELETE CASCADE,
    sender_device_id     UUID NULL REFERENCES devices(id) ON DELETE SET NULL,   -- станет NULL с sealed sender
    client_msg_id        UUID NOT NULL,                                         -- от отправителя, для идемпотентности
    envelope             BYTEA NOT NULL CHECK (octet_length(envelope) <= 65536),
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
    expires_at           TIMESTAMPTZ NOT NULL DEFAULT now() + INTERVAL '30 days',
    UNIQUE (sender_device_id, client_msg_id, recipient_device_id)
);
CREATE INDEX messages_queue_idx  ON messages (recipient_device_id, server_id);
CREATE INDEX messages_expiry_idx ON messages (expires_at);
