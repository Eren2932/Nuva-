-- 0002_profile.sql — публичный профиль (протокол 0.2): имя и фамилия.
-- Как и username, видны любому, кто знает @username. Пустая строка = не задано.
ALTER TABLE accounts
    ADD COLUMN first_name TEXT NOT NULL DEFAULT '' CHECK (char_length(first_name) <= 64),
    ADD COLUMN last_name  TEXT NOT NULL DEFAULT '' CHECK (char_length(last_name)  <= 64);
