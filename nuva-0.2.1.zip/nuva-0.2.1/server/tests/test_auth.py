"""Шаг 3 DoD: регистрация и вход работают из pytest (+ негативные кейсы)."""
from __future__ import annotations

import uuid

import pytest
from starlette.websockets import WebSocketDisconnect

from conftest import Device, b64, challenge, connect, db, make_invite, register


def expect_close(ws, code: int):
    with pytest.raises(WebSocketDisconnect) as ei:
        while True:
            ws.receive_json()
    assert ei.value.code == code


def test_subprotocol_required(client):
    with client.websocket_connect("/ws") as ws:
        expect_close(ws, 4400)


def test_register_then_login(client):
    dev = register(client, Device(), "alice")
    rows = db("SELECT username FROM accounts")
    assert [r["username"] for r in rows] == ["alice"]
    assert db("SELECT use_count FROM invites")[0]["use_count"] == 1

    with connect(client) as ws:
        nonce = challenge(ws)
        ws.send_json(dev.auth_frame(nonce, "c-9"))
        ok = ws.receive_json()
        assert ok == {"v": 1, "type": "auth.ok", "id": "c-9", "account_id": dev.account_id,
                      "device_id": dev.device_id, "pending": 0}
        assert ws.receive_json()["type"] == "queue.empty"
        ws.send_json({"v": 1, "type": "ping", "id": "p1"})
        pong = ws.receive_json()
        assert pong["type"] == "pong" and pong["id"] == "p1" and isinstance(pong["server_time"], int)


def test_register_connection_is_authenticated(client):
    invite = make_invite()
    dev = Device()
    with connect(client) as ws:
        nonce = challenge(ws)
        ws.send_json(dev.register_frame(nonce, invite, "bob"))
        assert ws.receive_json()["type"] == "account.registered"
        assert ws.receive_json()["type"] == "queue.empty"
        ws.send_json({"v": 1, "type": "ping", "id": "p"})
        assert ws.receive_json()["type"] == "pong"


def test_username_taken_keeps_invite(client):
    register(client, Device(), "alice")
    invite = make_invite()
    with connect(client) as ws:
        nonce = challenge(ws)
        ws.send_json(Device().register_frame(nonce, invite, "alice"))
        assert ws.receive_json()["code"] == "username_taken"
    assert db("SELECT use_count FROM invites WHERE use_count = 0")  # не сгорел


@pytest.mark.parametrize("username", ["Alice", "ab", "a" * 33, "al ice", "алиса"])
def test_username_invalid(client, username):
    with connect(client) as ws:
        nonce = challenge(ws)
        ws.send_json(Device().register_frame(nonce, make_invite(), username))
        assert ws.receive_json()["code"] == "username_invalid"


def test_invite_single_use(client):
    invite = make_invite(uses=1)
    register(client, Device(), "first", invite)
    with connect(client) as ws:
        nonce = challenge(ws)
        ws.send_json(Device().register_frame(nonce, invite, "second"))
        assert ws.receive_json()["code"] == "invite_invalid"


@pytest.mark.parametrize("kind", ["revoked", "expired", "unknown", "malformed"])
def test_invite_invalid(client, kind):
    if kind == "revoked":
        invite = make_invite(revoked=True)
    elif kind == "expired":
        invite = make_invite(days=-1)
    elif kind == "unknown":
        invite = "ABCDE-FGHJK"
    else:
        invite = "nope"
    with connect(client) as ws:
        nonce = challenge(ws)
        ws.send_json(Device().register_frame(nonce, invite, "carol"))
        assert ws.receive_json()["code"] == "invite_invalid"
    assert not db("SELECT 1 FROM accounts")


def test_invite_lenient_typing(client):
    invite = make_invite()
    typed = invite.lower().replace("-", "")
    register(client, Device(), "dave", typed)


def test_register_bad_signature_closes_4401(client):
    with connect(client) as ws:
        nonce = challenge(ws)
        ws.send_json(Device().register_frame(nonce, make_invite(), "eve", sig_override=bytes(64)))
        assert ws.receive_json()["code"] == "auth_failed"
        expect_close(ws, 4401)


def test_register_signature_bound_to_nonce(client):
    dev = Device()
    with connect(client) as ws:
        challenge(ws)
        ws.send_json(dev.register_frame(b"\x01" * 32, make_invite(), "frank"))
        assert ws.receive_json()["code"] == "auth_failed"
        expect_close(ws, 4401)


def test_register_attempts_limit_4429(client):
    with connect(client) as ws:
        nonce = challenge(ws)
        dev = Device()
        for i in range(3):
            ws.send_json(dev.register_frame(nonce, "ABCDE-FGHJK", "gina", fid=f"c-{i}"))
            assert ws.receive_json()["code"] == "invite_invalid"
        ws.send_json(dev.register_frame(nonce, "ABCDE-FGHJK", "gina", fid="c-4"))
        assert ws.receive_json()["code"] == "rate_limited"
        expect_close(ws, 4429)


def test_auth_wrong_key_4401(client):
    dev = register(client, Device(), "henry")
    impostor = Device(device_id=dev.device_id)
    with connect(client) as ws:
        nonce = challenge(ws)
        ws.send_json(impostor.auth_frame(nonce))
        assert ws.receive_json()["code"] == "auth_failed"
        expect_close(ws, 4401)


def test_auth_replay_old_nonce_4401(client):
    dev = register(client, Device(), "irene")
    with connect(client) as ws:
        challenge(ws)
        ws.send_json(dev.auth_frame(b"\x02" * 32))
        assert ws.receive_json()["code"] == "auth_failed"
        expect_close(ws, 4401)


def test_auth_unknown_device_4401(client):
    dev = Device(device_id=str(uuid.uuid4()))
    with connect(client) as ws:
        nonce = challenge(ws)
        ws.send_json(dev.auth_frame(nonce))
        assert ws.receive_json()["code"] == "auth_failed"
        expect_close(ws, 4401)


def test_auth_revoked_device_4401(client):
    dev = register(client, Device(), "jack")
    db("UPDATE devices SET revoked_at = now()")
    with connect(client) as ws:
        nonce = challenge(ws)
        ws.send_json(dev.auth_frame(nonce))
        assert ws.receive_json()["code"] == "auth_failed"
        expect_close(ws, 4401)


def test_auth_banned_account_4401(client):
    dev = register(client, Device(), "kate")
    db("UPDATE accounts SET status = 'banned'")
    with connect(client) as ws:
        nonce = challenge(ws)
        ws.send_json(dev.auth_frame(nonce))
        assert ws.receive_json()["code"] == "auth_failed"
        expect_close(ws, 4401)


def test_other_frame_before_auth_4401(client):
    with connect(client) as ws:
        challenge(ws)
        ws.send_json({"v": 1, "type": "ping", "id": "p"})
        expect_close(ws, 4401)


def test_malformed_json_4400(client):
    with connect(client) as ws:
        challenge(ws)
        ws.send_text("{not json")
        expect_close(ws, 4400)


def test_bad_fields_bad_request(client):
    with connect(client) as ws:
        challenge(ws)
        ws.send_json({"v": 1, "type": "auth.response", "id": "c-1", "device_id": "x", "sig": "y"})
        r = ws.receive_json()
        assert r["type"] == "error" and r["code"] == "bad_request" and r["id"] == "c-1"


def test_unknown_type_after_auth_bad_request(client):
    dev = register(client, Device(), "leo")
    with connect(client) as ws:
        nonce = challenge(ws)
        ws.send_json(dev.auth_frame(nonce))
        ws.receive_json(); ws.receive_json()
        ws.send_json({"v": 1, "type": "does.not.exist", "id": "z"})
        r = ws.receive_json()
        assert r["code"] == "bad_request" and r["id"] == "z"


def test_auth_timeout_4408(client):
    with connect(client) as ws:
        challenge(ws)
        expect_close(ws, 4408)


def test_new_connection_evicts_old_4409(client):
    dev = register(client, Device(), "mia")
    with connect(client) as ws1:
        n1 = challenge(ws1)
        ws1.send_json(dev.auth_frame(n1))
        assert ws1.receive_json()["type"] == "auth.ok"
        assert ws1.receive_json()["type"] == "queue.empty"
        with connect(client) as ws2:
            n2 = challenge(ws2)
            ws2.send_json(dev.auth_frame(n2))
            assert ws2.receive_json()["type"] == "auth.ok"
            expect_close(ws1, 4409)
            assert ws2.receive_json()["type"] == "queue.empty"


def test_offline_queue_drained_after_login(client):
    alice = register(client, Device(), "alice")
    bob = register(client, Device(), "bob")
    envs = [bytes([i]) * 400 for i in range(3)]
    for e in envs:
        db("INSERT INTO messages (recipient_device_id, sender_device_id, client_msg_id, envelope)"
           " VALUES ($1, $2, $3, $4)",
           uuid.UUID(bob.device_id), uuid.UUID(alice.device_id), uuid.uuid4(), e)
    with connect(client) as ws:
        nonce = challenge(ws)
        ws.send_json(bob.auth_frame(nonce))
        assert ws.receive_json()["pending"] == 3
        got = [ws.receive_json() for _ in range(3)]
        assert [g["type"] for g in got] == ["msg.deliver"] * 3
        assert [g["envelope"] for g in got] == [b64(e) for e in envs]
        assert all(g["from_account"] == alice.account_id and g["from_device"] == alice.device_id
                   for g in got)
        assert got[0]["server_id"] < got[1]["server_id"] < got[2]["server_id"]
        assert ws.receive_json()["type"] == "queue.empty"
    # Без ack ничего не удаляется (at-least-once).
    assert len(db("SELECT 1 FROM messages")) == 3


def test_healthz(client):
    r = client.get("/healthz")
    assert r.status_code == 200 and r.json()["status"] == "ok"
