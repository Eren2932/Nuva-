"""Серверные payload-ы байт-в-байт совпадают с эталоном tools/vectors.py (без БД)."""
from __future__ import annotations

import json
import uuid
from pathlib import Path

import pytest

from app import crypto

VECTORS = json.loads((Path(__file__).resolve().parent.parent / "tools" / "test-vectors.json")
                     .read_text("utf-8"))


def test_auth_payload_and_signature_match_vectors():
    a = VECTORS["auth"]
    alice = VECTORS["parties"]["alice"]
    payload = crypto.auth_payload(a["host"], uuid.UUID(a["device_id"]), bytes.fromhex(a["nonce"]))
    assert payload.hex() == a["payload"]
    assert crypto.verify_ed25519(bytes.fromhex(alice["ik_pub"]), payload, bytes.fromhex(a["sig"]))
    bob = VECTORS["parties"]["bob"]
    assert not crypto.verify_ed25519(bytes.fromhex(bob["ik_pub"]), payload, bytes.fromhex(a["sig"]))


@pytest.mark.parametrize("case", VECTORS["register"], ids=lambda c: c["username"])
def test_reg_payload_matches_vectors(case):
    party = VECTORS["parties"][case["party"]]
    payload = crypto.reg_payload(case["host"], bytes.fromhex(case["nonce"]),
                                 bytes.fromhex(party["ik_pub"]), bytes.fromhex(party["xk_pub"]),
                                 case["username"])
    assert payload.hex() == case["payload"]
    assert crypto.verify_ed25519(bytes.fromhex(party["ik_pub"]), payload, bytes.fromhex(case["sig"]))


@pytest.mark.parametrize("name", ["alice", "bob"])
def test_xk_signature(name):
    p = VECTORS["parties"][name]
    assert crypto.xk_payload(bytes.fromhex(p["xk_pub"])).hex() == p["xk_payload"]
    assert crypto.verify_ed25519(bytes.fromhex(p["ik_pub"]), bytes.fromhex(p["xk_payload"]),
                                 bytes.fromhex(p["x25519_sig"]))


def test_b64url_strict():
    for raw in (b"", b"\x00", b"\xff\xfe", bytes(range(64))):
        assert crypto.b64url_decode(crypto.b64url_encode(raw)) == raw
    for bad in ("a", "ab=", "ab+/", "a b", "AB", "____A"):
        with pytest.raises(crypto.B64Error):
            crypto.b64url_decode(bad)


def test_invite_normalization():
    code = crypto.generate_invite_code()
    assert len(code) == 11 and code[5] == "-" and crypto.invite_well_formed(code)
    assert crypto.invite_hash(code) == crypto.invite_hash(code.lower().replace("-", " "))
    assert crypto.normalize_invite("abcio-l0000") == "ABC1010000"
    assert not crypto.invite_well_formed("ABCDE-1234U")


def test_uuid7_shape_and_order():
    ids = [crypto.uuid7() for _ in range(50)]
    assert all(u.version == 7 and u.variant == uuid.RFC_4122 for u in ids)
    assert len(set(ids)) == 50
    assert ids[0].int >> 80 <= ids[-1].int >> 80
