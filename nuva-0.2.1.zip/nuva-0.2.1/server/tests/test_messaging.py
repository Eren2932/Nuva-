"""Протокол 0.2: профиль, поиск, отправка/доставка/ack конвертов (нужен PostgreSQL)."""
from __future__ import annotations

import uuid
from contextlib import contextmanager

from conftest import Device, b64, challenge, connect, db, register


@contextmanager
def online(client, dev: Device):
    """Авторизованное соединение с пустой очередью."""
    with connect(client) as ws:
        nonce = challenge(ws)
        ws.send_json(dev.auth_frame(nonce))
        assert ws.receive_json()["type"] == "auth.ok"
        assert ws.receive_json()["type"] == "queue.empty"
        yield ws


def send_frame(to: Device, envelope: bytes, cmid: str | None = None, fid: str = "s-1",
               device_ids: list[str] | None = None) -> dict:
    ids = device_ids if device_ids is not None else [to.device_id]
    return {"v": 1, "type": "msg.send", "id": fid, "to": to.account_id,
            "client_msg_id": cmid or str(uuid.uuid4()),
            "envelopes": [{"device_id": d, "envelope": b64(envelope)} for d in ids]}


def test_profile_set_then_lookup_by_username(client):
    alice = register(client, Device(), "alice")
    bob = register(client, Device(), "bob")
    with online(client, alice) as ws:
        ws.send_json({"v": 1, "type": "profile.set", "id": "p1",
                      "first_name": "  Алиса ", "last_name": "Петрова"})
        r = ws.receive_json()
        assert r == {"v": 1, "type": "profile.ok", "id": "p1",
                     "first_name": "Алиса", "last_name": "Петрова"}
    with online(client, bob) as ws:
        ws.send_json({"v": 1, "type": "user.lookup", "id": "l1", "username": "@Alice"})
        r = ws.receive_json()
        assert r["type"] == "user.info" and r["id"] == "l1"
        acc = r["account"]
        assert acc["account_id"] == alice.account_id and acc["username"] == "alice"
        assert (acc["first_name"], acc["last_name"]) == ("Алиса", "Петрова")
        assert acc["devices"] == [{
            "device_id": alice.device_id, "identity_key": b64(alice.ik),
            "x25519_key": b64(alice.xk),
            "x25519_sig": acc["devices"][0]["x25519_sig"],
        }]


def test_lookup_by_account_id_and_not_found(client):
    alice = register(client, Device(), "alice")
    bob = register(client, Device(), "bob")
    with online(client, bob) as ws:
        ws.send_json({"v": 1, "type": "user.lookup", "id": "l1", "account_id": alice.account_id})
        assert ws.receive_json()["account"]["username"] == "alice"
        for q in ("nobody", "al", "ALICE!"):
            ws.send_json({"v": 1, "type": "user.lookup", "id": "l2", "username": q})
            r = ws.receive_json()
            assert r["type"] == "error" and r["code"] == "not_found" and r["id"] == "l2"
        ws.send_json({"v": 1, "type": "user.lookup", "id": "l3"})
        assert ws.receive_json()["code"] == "bad_request"
    db("UPDATE devices SET revoked_at = now() WHERE account_id = $1", uuid.UUID(alice.account_id))
    with online(client, bob) as ws:
        ws.send_json({"v": 1, "type": "user.lookup", "id": "l4", "username": "alice"})
        assert ws.receive_json()["code"] == "not_found"


def test_profile_validation(client):
    alice = register(client, Device(), "alice")
    with online(client, alice) as ws:
        for bad in ("", "   ", "a" * 65, "evil\u202eman"):
            ws.send_json({"v": 1, "type": "profile.set", "id": "p", "first_name": bad})
            assert ws.receive_json()["code"] == "bad_request"


def test_lookup_rate_limited(client):
    bob = register(client, Device(), "bob")
    with online(client, bob) as ws:
        for i in range(30):
            ws.send_json({"v": 1, "type": "user.lookup", "id": f"l{i}", "username": "nobody"})
            assert ws.receive_json()["code"] == "not_found"
        ws.send_json({"v": 1, "type": "user.lookup", "id": "lx", "username": "nobody"})
        assert ws.receive_json()["code"] == "rate_limited"


def test_send_online_delivery_and_ack(client):
    alice = register(client, Device(), "alice")
    bob = register(client, Device(), "bob")
    env = b"\x01" * 400
    cmid = str(uuid.uuid4())
    with online(client, bob) as wb:
        with online(client, alice) as wa:
            wa.send_json(send_frame(bob, env, cmid))
            sent = wa.receive_json()
            assert sent["type"] == "msg.sent" and sent["id"] == "s-1"
            assert sent["client_msg_id"] == cmid and isinstance(sent["server_ts"], int)
        d = wb.receive_json()
        assert d["type"] == "msg.deliver" and d["envelope"] == b64(env)
        assert d["from_account"] == alice.account_id and d["from_device"] == alice.device_id
        assert d["client_msg_id"] == cmid
        assert len(db("SELECT 1 FROM messages")) == 1
        wb.send_json({"v": 1, "type": "msg.ack", "server_ids": [d["server_id"]]})
        wb.send_json({"v": 1, "type": "ping", "id": "p"})  # ack без ответа: ждём pong как барьер
        assert wb.receive_json()["type"] == "pong"
    assert not db("SELECT 1 FROM messages")


def test_send_offline_then_drain(client):
    alice = register(client, Device(), "alice")
    bob = register(client, Device(), "bob")
    with online(client, alice) as wa:
        wa.send_json(send_frame(bob, b"\x02" * 300))
        assert wa.receive_json()["type"] == "msg.sent"
    with connect(client) as ws:
        nonce = challenge(ws)
        ws.send_json(bob.auth_frame(nonce))
        assert ws.receive_json()["pending"] == 1
        d = ws.receive_json()
        assert d["type"] == "msg.deliver" and d["envelope"] == b64(b"\x02" * 300)
        assert ws.receive_json()["type"] == "queue.empty"


def test_send_is_idempotent(client):
    alice = register(client, Device(), "alice")
    bob = register(client, Device(), "bob")
    cmid = str(uuid.uuid4())
    with online(client, alice) as wa:
        for fid in ("s-1", "s-2"):
            wa.send_json(send_frame(bob, b"\x03" * 300, cmid, fid=fid))
            r = wa.receive_json()
            assert r["type"] == "msg.sent" and r["id"] == fid
    assert len(db("SELECT 1 FROM messages")) == 1


def test_devices_mismatch(client):
    alice = register(client, Device(), "alice")
    bob = register(client, Device(), "bob")
    stranger = str(uuid.uuid4())
    with online(client, alice) as wa:
        wa.send_json(send_frame(bob, b"\x04" * 300, device_ids=[stranger]))
        r = wa.receive_json()
        assert r["code"] == "devices_mismatch"
        assert r["details"] == {"missing": [bob.device_id], "extra": [stranger]}
    assert not db("SELECT 1 FROM messages")


def test_send_to_unknown_account_not_found(client):
    alice = register(client, Device(), "alice")
    ghost = Device(device_id=str(uuid.uuid4()), account_id=str(uuid.uuid4()))
    with online(client, alice) as wa:
        wa.send_json(send_frame(ghost, b"\x05" * 300))
        assert wa.receive_json()["code"] == "not_found"


def test_envelope_too_large(client):
    alice = register(client, Device(), "alice")
    bob = register(client, Device(), "bob")
    with online(client, alice) as wa:
        wa.send_json(send_frame(bob, b"\x06" * (64 * 1024 + 1)))
        assert wa.receive_json()["code"] == "payload_too_large"


def test_ack_ignores_foreign_messages(client):
    alice = register(client, Device(), "alice")
    bob = register(client, Device(), "bob")
    with online(client, alice) as wa:
        wa.send_json(send_frame(bob, b"\x07" * 300))
        assert wa.receive_json()["type"] == "msg.sent"
        sid = db("SELECT server_id FROM messages")[0]["server_id"]
        wa.send_json({"v": 1, "type": "msg.ack", "server_ids": [sid]})
        wa.send_json({"v": 1, "type": "ping", "id": "p"})
        assert wa.receive_json()["type"] == "pong"
    assert len(db("SELECT 1 FROM messages")) == 1  # чужой ack не удалил
