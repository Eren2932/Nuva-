#!/usr/bin/env python3
"""Выпуск и отзыв инвайтов (§6.6). Код печатается ОДИН раз, в БД — только SHA-256.

    python tools/invite.py                      # 1 код, 1 использование, 14 дней
    python tools/invite.py --uses 1 --days 14 --count 5
    python tools/invite.py --revoke ABCDE-12345
    python tools/invite.py --list               # статистика без кодов (их нет в БД)

На сервере:  docker compose exec api python tools/invite.py --count 3
DATABASE_URL берётся из окружения или .env (как у сервера).
"""
from __future__ import annotations

import argparse
import asyncio
import sys
from datetime import timedelta
from pathlib import Path

import asyncpg
from pydantic_settings import BaseSettings, SettingsConfigDict

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from app.crypto import generate_invite_code, invite_hash, invite_well_formed  # noqa: E402


class _DbSettings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")
    database_url: str


async def _issue(con: asyncpg.Connection, uses: int, days: int, count: int) -> list[str]:
    codes: list[str] = []
    async with con.transaction():
        while len(codes) < count:
            code = generate_invite_code()
            inserted = await con.fetchval(
                "INSERT INTO invites (code_hash, max_uses, expires_at)"
                " VALUES ($1, $2, now() + $3::interval)"
                " ON CONFLICT (code_hash) DO NOTHING RETURNING 1",
                invite_hash(code), uses, timedelta(days=days),
            )
            if inserted:  # коллизия 50-битного кода практически невозможна, но повторим
                codes.append(code)
    return codes


async def _revoke(con: asyncpg.Connection, code: str) -> bool:
    status = await con.execute(
        "UPDATE invites SET revoked_at = now() WHERE code_hash = $1 AND revoked_at IS NULL",
        invite_hash(code),
    )
    return status.endswith(" 1")


async def _list(con: asyncpg.Connection) -> None:
    rows = await con.fetch(
        "SELECT created_at, expires_at, max_uses, use_count, revoked_at,"
        "       (revoked_at IS NULL AND expires_at > now() AND use_count < max_uses) AS usable"
        "  FROM invites ORDER BY created_at DESC LIMIT 50"
    )
    print(f"{'created':<17} {'expires':<17} {'used':>7}  state")
    for r in rows:
        state = "usable" if r["usable"] else ("revoked" if r["revoked_at"] else "spent/expired")
        print(f"{r['created_at']:%Y-%m-%d %H:%M} {r['expires_at']:%Y-%m-%d %H:%M} "
              f"{r['use_count']:>3}/{r['max_uses']:<3}  {state}")


async def main_async(args: argparse.Namespace) -> int:
    con = await asyncpg.connect(_DbSettings().database_url)  # type: ignore[call-arg]
    try:
        if args.revoke:
            if not invite_well_formed(args.revoke):
                print("malformed code", file=sys.stderr)
                return 2
            ok = await _revoke(con, args.revoke)
            print("revoked" if ok else "not found or already revoked")
            return 0 if ok else 1
        if args.list:
            await _list(con)
            return 0
        for code in await _issue(con, args.uses, args.days, args.count):
            print(code)
        return 0
    finally:
        await con.close()


def main() -> int:
    ap = argparse.ArgumentParser(description="Nuva invite codes")
    ap.add_argument("--uses", type=int, default=1, help="сколько регистраций по одному коду")
    ap.add_argument("--days", type=int, default=14, help="срок действия, дней")
    ap.add_argument("--count", type=int, default=1, help="сколько кодов выпустить")
    ap.add_argument("--revoke", metavar="CODE", help="отозвать код")
    ap.add_argument("--list", action="store_true", help="последние 50 инвайтов без кодов")
    args = ap.parse_args()
    if not (1 <= args.uses <= 1000 and 1 <= args.days <= 365 and 1 <= args.count <= 100):
        ap.error("limits: uses 1..1000, days 1..365, count 1..100")
    return asyncio.run(main_async(args))


if __name__ == "__main__":
    sys.exit(main())
