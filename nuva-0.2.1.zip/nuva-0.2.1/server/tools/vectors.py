#!/usr/bin/env python3
"""Эталонная реализация криптографии v1 (NUVA_PHASE1_POC.md §4) и генератор тест-векторов.

Источник правды для клиента: тот же test-vectors.json гоняется в Kotlin commonTest
(JVM + Android). Расхождение в одном байте = красный CI.

    python tools/vectors.py                 # самопроверка + запись tools/test-vectors.json
    python tools/vectors.py --check         # самопроверка + сверка с закоммиченным файлом (CI)
    python tools/vectors.py --out path.json # записать в другое место

Все входы детерминированы (seed = SHA-256 от метки), поэтому файл воспроизводим побайтно.
Двоичные поля в JSON — hex (векторы читает человек при отладке; в протоколе — base64url).
"""
from __future__ import annotations

import argparse
import hashlib
import hmac
import json
import sys
import uuid
from pathlib import Path

from nacl.bindings import (
    crypto_aead_xchacha20poly1305_ietf_decrypt,
    crypto_aead_xchacha20poly1305_ietf_encrypt,
    crypto_scalarmult,
    crypto_scalarmult_base,
    sodium_pad,
    sodium_unpad,
)
from nacl.exceptions import BadSignatureError, CryptoError
from nacl.signing import SigningKey, VerifyKey

SPEC_VERSION = "1.0.1"
FORMAT = "nuva-test-vectors"
FORMAT_VERSION = 1
DEFAULT_OUT = Path(__file__).resolve().parent / "test-vectors.json"

SEP = b"\x00"
LABEL_XK = b"NUVA-XK-V1"
LABEL_AUTH = b"NUVA-AUTH-V1"
LABEL_REG = b"NUVA-REG-V1"
LABEL_MSG = b"NUVA-MSG-V1"
LABEL_SN = b"NUVA-SN-V1"
ENVELOPE_VERSION = 0x01
PAD_BLOCK = 256
KEY_LEN = 32
NONCE_LEN = 24
TAG_LEN = 16
HEADER_LEN = 1 + 32 + NONCE_LEN  # 57
ZERO32 = bytes(32)


# ───────────────────────────── HKDF (RFC 5869) ─────────────────────────────

def hkdf_extract(salt: bytes, ikm: bytes) -> bytes:
    if not salt:
        salt = bytes(hashlib.sha256().digest_size)  # RFC 5869 §2.2: пустая соль = HashLen нулей
    return hmac.new(salt, ikm, hashlib.sha256).digest()


def hkdf_expand(prk: bytes, info: bytes, length: int) -> bytes:
    if length <= 0 or length > 255 * 32:
        raise ValueError("HKDF-SHA256: L must be in 1..8160")
    okm, block, counter = b"", b"", 1
    while len(okm) < length:
        block = hmac.new(prk, block + info + bytes([counter]), hashlib.sha256).digest()
        okm += block
        counter += 1
    return okm[:length]


def hkdf_sha256(salt: bytes, ikm: bytes, info: bytes, length: int) -> bytes:
    return hkdf_expand(hkdf_extract(salt, ikm), info, length)


RFC5869_CASES = [
    {
        "name": "RFC 5869 A.1 (basic)",
        "ikm": "0b" * 22,
        "salt": "000102030405060708090a0b0c",
        "info": "f0f1f2f3f4f5f6f7f8f9",
        "length": 42,
        "prk": "077709362c2e32df0ddc3f0dc47bba6390b6c73bb50f9c3122ec844ad7c2b3e5",
        "okm": "3cb25f25faacd57a90434f64d0362f2a2d2d0a90cf1a5a4c5db02d56ecc4c5bf"
               "34007208d5b887185865",
    },
    {
        "name": "RFC 5869 A.2 (long inputs)",
        "ikm": bytes(range(0x00, 0x50)).hex(),
        "salt": bytes(range(0x60, 0xB0)).hex(),
        "info": bytes(range(0xB0, 0x100)).hex(),
        "length": 82,
        "prk": "06a6b88c5853361a06104c9ceb35b45cef760014904671014a193f40c15fc244",
        "okm": "b11e398dc80327a1c8e7f78c596a49344f012eda2d4efad8a050cc4c19afa97c"
               "59045a99cac7827271cb41c65e590e09da3275600c2f09b8367793a9aca3db71"
               "cc30c58179ec3e87c14c01d5c1f3434f1d87",
    },
    {
        "name": "RFC 5869 A.3 (zero-length salt/info)",
        "ikm": "0b" * 22,
        "salt": "",
        "info": "",
        "length": 42,
        "prk": "19ef24a32c717b167f33a91d6f648bdf96596776afdb6377ac434c1c293ccb04",
        "okm": "8da4e775a563c18f715f802a063c5a31b8a11f5c5ee1879ec3454e5f3c738d2d"
               "9d201395faa4b61a96c8",
    },
]


def check_rfc5869() -> list[dict]:
    out = []
    for case in RFC5869_CASES:
        ikm, salt, info = (bytes.fromhex(case[k]) for k in ("ikm", "salt", "info"))
        prk = hkdf_extract(salt, ikm)
        okm = hkdf_expand(prk, info, case["length"])
        if prk.hex() != case["prk"] or okm.hex() != case["okm"]:
            raise AssertionError(f"HKDF mismatch: {case['name']}")
        out.append(dict(case))
    return out


# ───────────────────────────── Примитивы v1 ─────────────────────────────

def uuid_bytes(value: str | uuid.UUID) -> bytes:
    return (value if isinstance(value, uuid.UUID) else uuid.UUID(value)).bytes  # RFC 4122, big-endian


def x25519(priv: bytes, pub: bytes) -> bytes:
    """X25519 с отказом на нулевом результате (точка малого порядка)."""
    try:
        shared = crypto_scalarmult(priv, pub)
    except RuntimeError as exc:  # libsodium вернул -1
        raise CryptoError("X25519 produced all-zero output") from exc
    if hmac.compare_digest(shared, ZERO32):
        raise CryptoError("X25519 produced all-zero output")
    return shared


def xk_payload(xk_pub: bytes) -> bytes:
    return LABEL_XK + SEP + xk_pub


def auth_payload(host: str, device_id: str, nonce: bytes) -> bytes:
    return LABEL_AUTH + SEP + host.encode("ascii") + SEP + uuid_bytes(device_id) + nonce


def reg_payload(host: str, nonce: bytes, ik_pub: bytes, xk_pub: bytes, username: str) -> bytes:
    return (LABEL_REG + SEP + host.encode("ascii") + SEP + nonce + ik_pub + xk_pub
            + username.encode("utf-8"))


def msg_info(sender_device: str, recipient_device: str, e_pub: bytes) -> bytes:
    return LABEL_MSG + uuid_bytes(sender_device) + uuid_bytes(recipient_device) + e_pub


def msg_ad(sender_device: str, recipient_device: str, client_msg_id: str, e_pub: bytes) -> bytes:
    return (LABEL_MSG + SEP + bytes([ENVELOPE_VERSION]) + uuid_bytes(sender_device)
            + uuid_bytes(recipient_device) + uuid_bytes(client_msg_id) + e_pub)


def seal(*, sender_xk_priv: bytes, recipient_xk_pub: bytes, sender_device: str,
         recipient_device: str, client_msg_id: str, plaintext: bytes,
         e_priv: bytes, nonce: bytes) -> dict:
    """Конверт v1 (Noise K: e, es, ss). Возвращает envelope и все промежуточные значения."""
    if len(e_priv) != 32 or len(nonce) != NONCE_LEN:
        raise ValueError("bad e_priv / nonce length")
    e_pub = crypto_scalarmult_base(e_priv)
    es = x25519(e_priv, recipient_xk_pub)
    ss = x25519(sender_xk_priv, recipient_xk_pub)
    info = msg_info(sender_device, recipient_device, e_pub)
    key = hkdf_sha256(b"", es + ss, info, KEY_LEN)
    ad = msg_ad(sender_device, recipient_device, client_msg_id, e_pub)
    padded = sodium_pad(plaintext, PAD_BLOCK)
    ct = crypto_aead_xchacha20poly1305_ietf_encrypt(padded, ad, nonce, key)
    envelope = bytes([ENVELOPE_VERSION]) + e_pub + nonce + ct
    return {"e_pub": e_pub, "es": es, "ss": ss, "info": info, "key": key, "ad": ad,
            "padded": padded, "ciphertext": ct, "envelope": envelope}


def open_envelope(*, recipient_xk_priv: bytes, sender_xk_pub: bytes, sender_device: str,
                  recipient_device: str, client_msg_id: str, envelope: bytes) -> bytes:
    if len(envelope) < HEADER_LEN + TAG_LEN + PAD_BLOCK:
        raise CryptoError("envelope too short")
    if envelope[0] != ENVELOPE_VERSION:
        raise CryptoError("unsupported envelope version")
    e_pub, nonce, ct = envelope[1:33], envelope[33:HEADER_LEN], envelope[HEADER_LEN:]
    es = x25519(recipient_xk_priv, e_pub)
    ss = x25519(recipient_xk_priv, sender_xk_pub)
    key = hkdf_sha256(b"", es + ss, msg_info(sender_device, recipient_device, e_pub), KEY_LEN)
    ad = msg_ad(sender_device, recipient_device, client_msg_id, e_pub)
    padded = crypto_aead_xchacha20poly1305_ietf_decrypt(ct, ad, nonce, key)
    return sodium_unpad(padded, PAD_BLOCK)


def safety_number(ik_a: bytes, ik_b: bytes) -> tuple[bytes, str]:
    lo, hi = sorted((ik_a, ik_b))
    sn = hashlib.sha256(LABEL_SN + SEP + lo + hi).digest()
    groups = [f"{int.from_bytes(sn[i:i + 5], 'big') % 100000:05d}" for i in range(0, 30, 5)]
    return sn, " ".join(groups)


# ───────────────────────────── Детерминированные входы ─────────────────────────────

def seed(label: str, n: int = 32) -> bytes:
    return hashlib.sha256(b"nuva-test-vector-v1:" + label.encode()).digest()[:n]


class Party:
    def __init__(self, name: str, device_id: str, account_id: str):
        self.name = name
        self.device_id = device_id
        self.account_id = account_id
        self.ik_seed = seed(f"{name}/ik")
        self.sk = SigningKey(self.ik_seed)
        self.ik_pub = self.sk.verify_key.encode()
        self.xk_priv = seed(f"{name}/xk")
        self.xk_pub = crypto_scalarmult_base(self.xk_priv)
        self.x25519_sig = self.sign(xk_payload(self.xk_pub))

    def sign(self, payload: bytes) -> bytes:
        return self.sk.sign(payload).signature

    def to_json(self) -> dict:
        return {
            "device_id": self.device_id,
            "account_id": self.account_id,
            "ik_seed": self.ik_seed.hex(),
            "ik_pub": self.ik_pub.hex(),
            "xk_priv": self.xk_priv.hex(),
            "xk_pub": self.xk_pub.hex(),
            "xk_payload": xk_payload(self.xk_pub).hex(),
            "x25519_sig": self.x25519_sig.hex(),
        }


HOST = "api.nuva.test"
ALICE = Party("alice", "0192f3a1-0000-7000-8000-00000000a001", "0192f3a1-0000-7000-8000-0000000000a0")
BOB = Party("bob", "0192f3a1-0000-7000-8000-00000000b001", "0192f3a1-0000-7000-8000-0000000000b0")


def plaintext_json(ts: int, body: str) -> bytes:
    return json.dumps({"v": 1, "t": "text", "ts": ts, "body": body},
                      ensure_ascii=False, separators=(",", ":")).encode("utf-8")


def plaintext_of_len(target: int) -> bytes:
    base = plaintext_json(1793434200000, "")
    if target < len(base):
        raise ValueError("target too small")
    return plaintext_json(1793434200000, "x" * (target - len(base)))


def verify_sig(pub: bytes, payload: bytes, sig: bytes) -> bool:
    try:
        VerifyKey(pub).verify(payload, sig)
        return True
    except BadSignatureError:
        return False


# ───────────────────────────── Генерация ─────────────────────────────

def build_envelope_case(name: str, sender: Party, recipient: Party, client_msg_id: str,
                        plaintext: bytes) -> dict:
    e_priv = seed(f"{name}/e")
    nonce = seed(f"{name}/nonce", NONCE_LEN)
    r = seal(sender_xk_priv=sender.xk_priv, recipient_xk_pub=recipient.xk_pub,
             sender_device=sender.device_id, recipient_device=recipient.device_id,
             client_msg_id=client_msg_id, plaintext=plaintext, e_priv=e_priv, nonce=nonce)
    env = r["envelope"]
    assert len(env) == len(r["padded"]) + 73, "overhead must be 73 bytes"
    assert len(r["padded"]) % PAD_BLOCK == 0
    # Получатель обязан расшифровать.
    opened = open_envelope(recipient_xk_priv=recipient.xk_priv, sender_xk_pub=sender.xk_pub,
                           sender_device=sender.device_id, recipient_device=recipient.device_id,
                           client_msg_id=client_msg_id, envelope=env)
    assert opened == plaintext, "roundtrip failed"
    # Любой бит в шифротексте или любом поле AD ломает AEAD.
    tampered = bytearray(env)
    tampered[-1] ^= 0x01
    for bad in (
        dict(envelope=bytes(tampered), client_msg_id=client_msg_id),
        dict(envelope=env, client_msg_id=str(uuid.UUID(int=uuid.UUID(client_msg_id).int ^ 1))),
    ):
        try:
            open_envelope(recipient_xk_priv=recipient.xk_priv, sender_xk_pub=sender.xk_pub,
                          sender_device=sender.device_id, recipient_device=recipient.device_id,
                          **bad)
        except CryptoError:
            pass
        else:
            raise AssertionError("tampered envelope must not decrypt")
    return {
        "name": name,
        "sender": sender.name,
        "recipient": recipient.name,
        "sender_device_id": sender.device_id,
        "recipient_device_id": recipient.device_id,
        "client_msg_id": client_msg_id,
        "plaintext": plaintext.hex(),
        "plaintext_len": len(plaintext),
        "padded": r["padded"].hex(),
        "e_priv": e_priv.hex(),
        "e_pub": r["e_pub"].hex(),
        "es": r["es"].hex(),
        "ss": r["ss"].hex(),
        "hkdf_info": r["info"].hex(),
        "key": r["key"].hex(),
        "nonce": nonce.hex(),
        "ad": r["ad"].hex(),
        "ciphertext": r["ciphertext"].hex(),
        "envelope": env.hex(),
        "tampered_envelope": bytes(tampered).hex(),
    }


LOW_ORDER_POINTS = [
    "0000000000000000000000000000000000000000000000000000000000000000",
    "0100000000000000000000000000000000000000000000000000000000000000",
    "e0eb7a7c3b41b8ae1656e3faf19fc46ada098deb9c32b1fd866205165f49b800",
    "5f9c95bca3508c24b1d0b1559c83ef5b04445cc4581c8e86d8224eddd09f1157",
    "ecffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff7f",
]


def check_low_order() -> list[str]:
    for hx in LOW_ORDER_POINTS:
        try:
            x25519(ALICE.xk_priv, bytes.fromhex(hx))
        except CryptoError:
            continue
        raise AssertionError(f"low-order point accepted: {hx}")
    return LOW_ORDER_POINTS


def check_padding() -> list[dict]:
    out = []
    for n in (0, 1, 255, 256, 257, 511, 512):
        data = bytes([0x41]) * n
        padded = sodium_pad(data, PAD_BLOCK)
        # ISO/IEC 7816-4: 0x80 и нули; при кратной длине добавляется целый блок.
        expected_len = (n // PAD_BLOCK + 1) * PAD_BLOCK
        assert len(padded) == expected_len and padded[n] == 0x80, f"pad({n})"
        assert sodium_unpad(padded, PAD_BLOCK) == data
        out.append({"len": n, "padded_len": len(padded)})
    return out


def generate() -> dict:
    hkdf = check_rfc5869()
    low_order = check_low_order()
    padding = check_padding()

    for p in (ALICE, BOB):
        assert verify_sig(p.ik_pub, xk_payload(p.xk_pub), p.x25519_sig)

    auth_nonce = seed("auth/nonce")
    a_auth = auth_payload(HOST, ALICE.device_id, auth_nonce)
    a_auth_sig = ALICE.sign(a_auth)
    assert verify_sig(ALICE.ik_pub, a_auth, a_auth_sig)
    assert not verify_sig(BOB.ik_pub, a_auth, a_auth_sig)
    assert not verify_sig(ALICE.ik_pub, auth_payload("evil.example", ALICE.device_id, auth_nonce),
                          a_auth_sig), "HOST must be bound"

    reg_nonce = seed("reg/nonce")
    reg_cases = []
    for party, username in ((ALICE, "alice"), (BOB, "bob_01")):
        payload = reg_payload(HOST, reg_nonce, party.ik_pub, party.xk_pub, username)
        sig = party.sign(payload)
        assert verify_sig(party.ik_pub, payload, sig)
        reg_cases.append({"party": party.name, "host": HOST, "nonce": reg_nonce.hex(),
                          "username": username, "payload": payload.hex(), "sig": sig.hex()})

    envelopes = [
        build_envelope_case("a_to_b_text", ALICE, BOB, "0192f3a1-0000-7000-8000-0000000c0001",
                            plaintext_json(1793434200000, "Привет")),
        build_envelope_case("b_to_a_text", BOB, ALICE, "0192f3a1-0000-7000-8000-0000000c0002",
                            plaintext_json(1793434201000, "Hi! 👋 Как дела?")),
        build_envelope_case("a_to_b_exact_block", ALICE, BOB, "0192f3a1-0000-7000-8000-0000000c0003",
                            plaintext_of_len(256)),
        build_envelope_case("a_to_b_one_below_block", ALICE, BOB,
                            "0192f3a1-0000-7000-8000-0000000c0004", plaintext_of_len(255)),
    ]
    assert len(bytes.fromhex(envelopes[2]["padded"])) == 512, "full block must be appended"
    assert len(bytes.fromhex(envelopes[3]["padded"])) == 256

    sn, digits = safety_number(ALICE.ik_pub, BOB.ik_pub)
    assert safety_number(BOB.ik_pub, ALICE.ik_pub) == (sn, digits), "must be symmetric"

    return {
        "format": FORMAT,
        "format_version": FORMAT_VERSION,
        "spec_version": SPEC_VERSION,
        "encoding": "hex; uuid fields are canonical strings, encoded as 16 bytes big-endian",
        "constants": {
            "label_xk": LABEL_XK.decode(), "label_auth": LABEL_AUTH.decode(),
            "label_reg": LABEL_REG.decode(), "label_msg": LABEL_MSG.decode(),
            "label_sn": LABEL_SN.decode(), "envelope_version": ENVELOPE_VERSION,
            "pad_block": PAD_BLOCK, "overhead": HEADER_LEN + TAG_LEN,
        },
        "hkdf_sha256_rfc5869": hkdf,
        "x25519_low_order_points_must_fail": low_order,
        "padding": padding,
        "parties": {"alice": ALICE.to_json(), "bob": BOB.to_json()},
        "auth": {"party": "alice", "host": HOST, "device_id": ALICE.device_id,
                 "nonce": auth_nonce.hex(), "payload": a_auth.hex(), "sig": a_auth_sig.hex()},
        "register": reg_cases,
        "envelopes": envelopes,
        "safety_number": {"ik_a": ALICE.ik_pub.hex(), "ik_b": BOB.ik_pub.hex(),
                          "sn": sn.hex(), "digits": digits},
    }


def dump(data: dict) -> str:
    return json.dumps(data, ensure_ascii=False, indent=2) + "\n"


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--out", type=Path, default=DEFAULT_OUT)
    ap.add_argument("--check", action="store_true",
                    help="не писать файл, а сверить сгенерированное с --out")
    args = ap.parse_args(argv)

    text = dump(generate())
    if args.check:
        if not args.out.exists():
            print(f"FAIL: {args.out} not found", file=sys.stderr)
            return 1
        if args.out.read_text("utf-8") != text:
            print(f"FAIL: {args.out} differs from reference implementation. "
                  f"Regenerate: python tools/vectors.py", file=sys.stderr)
            return 1
        print(f"OK: self-checks passed, {args.out.name} matches reference")
        return 0
    args.out.write_text(text, "utf-8")
    print(f"OK: self-checks passed, wrote {args.out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
