import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.compose.compiler)
}

val appVersionName = rootProject.extra["nuvaVersionName"] as String
val appVersionCode = rootProject.extra["nuvaVersionCode"] as Int

// Подпись берём только из окружения (CI-секреты). Ключа нет — релиз подписывается debug-ключом,
// это удобно локально; CI сам падает, если секрет не задан (см. build.yml).
val signStore = System.getenv("NUVA_SIGNING_STORE_FILE")?.takeIf { it.isNotBlank() }

// Аварийный рубильник R8: -Pnuva.minify=false, если вдруг сборка с минификацией поведёт себя странно.
val minify = (findProperty("nuva.minify") as String?)?.toBooleanStrictOrNull() ?: true

android {
    namespace = "app.nuva.android"
    compileSdk = libs.versions.androidCompileSdk.get().toInt()

    defaultConfig {
        applicationId = "app.nuva"
        minSdk = libs.versions.androidMinSdk.get().toInt()
        targetSdk = libs.versions.androidCompileSdk.get().toInt()
        versionCode = appVersionCode
        versionName = appVersionName
    }

    signingConfigs {
        if (signStore != null) {
            create("release") {
                storeFile = file(signStore)
                // trim(): перевод строки в конце секрета = «неверный пароль» без единой подсказки.
                val storePw = System.getenv("NUVA_SIGNING_STORE_PASSWORD").orEmpty().trim()
                storePassword = storePw
                keyAlias = System.getenv("NUVA_SIGNING_KEY_ALIAS").orEmpty().trim().ifEmpty { "nuva" }
                keyPassword = System.getenv("NUVA_SIGNING_KEY_PASSWORD").orEmpty().trim().ifEmpty { storePw }
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = minify
            isShrinkResources = minify
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.findByName("release") ?: signingConfigs.getByName("debug")
        }
        debug {
            applicationIdSuffix = ".debug"
            versionNameSuffix = "-debug"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    buildFeatures { compose = true }
    packaging {
        resources.excludes += setOf("/META-INF/{AL2.0,LGPL2.1}", "/META-INF/INDEX.LIST", "/META-INF/io.netty.versions.properties")
    }
}

kotlin {
    compilerOptions { jvmTarget.set(JvmTarget.JVM_17) }
}

dependencies {
    implementation(project(":ui"))
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.splashscreen)
    implementation(libs.coroutines.android)
    implementation(libs.ktor.client.okhttp)
    implementation(libs.sqldelight.android)
}
