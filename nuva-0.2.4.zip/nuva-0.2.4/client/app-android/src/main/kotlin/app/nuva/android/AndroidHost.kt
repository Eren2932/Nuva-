package app.nuva.android

import android.Manifest
import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.app.NotificationManagerCompat
import app.nuva.ui.HostBridge

/** Android-часть HostBridge: служба приёма, разрешение на уведомления, системные экраны настроек. */
class AndroidHost(private val app: Application) : HostBridge {
    private val prefs = app.getSharedPreferences("nuva_host", Context.MODE_PRIVATE)

    /** Ставит MainActivity: запуск системного диалога разрешения. */
    @Volatile
    var permissionLauncher: (() -> Unit)? = null

    @Volatile
    var manualRequest = false

    override val supportsBackground: Boolean get() = true

    override fun backgroundEnabled(): Boolean = prefs.getBoolean(KEY_BG, true)

    override fun setBackgroundEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_BG, enabled).apply()
        if (enabled) NuvaService.start(app) else NuvaService.stop(app)
    }

    private fun hasPostPermission(): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            app.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    override fun notificationsAllowed(): Boolean =
        hasPostPermission() && NotificationManagerCompat.from(app).areNotificationsEnabled()

    /** Вызывается из профиля (по нажатию): если диалога уже не будет — ведём в системные настройки. */
    override fun requestNotifications() {
        val launcher = permissionLauncher
        if (!hasPostPermission() && launcher != null) {
            manualRequest = true
            launcher()
        } else {
            openNotificationSettings()
        }
    }

    /** Один раз за установку просим разрешение сами — после входа в аккаунт. */
    fun askOnce() {
        if (hasPostPermission() || prefs.getBoolean(KEY_ASKED, false)) return
        val launcher = permissionLauncher ?: return
        prefs.edit().putBoolean(KEY_ASKED, true).apply()
        manualRequest = false
        launcher()
    }

    fun openNotificationSettings() = launch(
        Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, app.packageName),
    )

    override fun openBatterySettings() = launch(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS), fallback = ::openAppSettings)

    override fun openAppSettings() = launch(
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.packageName}")),
    )

    private fun launch(intent: Intent, fallback: (() -> Unit)? = null) {
        try {
            app.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            fallback?.invoke()
        }
    }

    private companion object {
        const val KEY_BG = "background_enabled"
        const val KEY_ASKED = "notifications_asked"
    }
}
