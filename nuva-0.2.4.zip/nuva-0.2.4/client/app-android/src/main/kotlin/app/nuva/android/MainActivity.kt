package app.nuva.android

import android.Manifest
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.enableEdgeToEdge
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import app.nuva.ui.NuvaApp
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val graph get() = (application as NuvaApplication).graph
    private val host get() = (application as NuvaApplication).host

    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            // Нажали в профиле, а системного диалога уже не будет (отказали навсегда) — ведём в настройки.
            if (!granted && host.manualRequest) host.openNotificationSettings()
            host.manualRequest = false
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        // Системная заставка снимается на первом кадре Compose, а он рисует тот же знак
        // на том же месте — переход без вспышки.
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
        )
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (!graph.back()) {
                    // Стек пуст — отдаём системе (свернуть приложение).
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                    isEnabled = true
                }
            }
        })
        host.permissionLauncher = {
            if (Build.VERSION.SDK_INT >= 33) notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        handleIntent(intent)
        setContent { NuvaApp(graph) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    /** Тап по уведомлению: открыть нужный чат. */
    private fun handleIntent(intent: Intent?) {
        val peer = intent?.getStringExtra(NotificationCenter.EXTRA_OPEN_PEER) ?: return
        intent.removeExtra(NotificationCenter.EXTRA_OPEN_PEER)
        graph.openChat(peer)
    }

    override fun onStart() {
        super.onStart()
        // «Прочитано» уходит только пока окно на экране.
        graph.setForeground(true)
        if (host.backgroundEnabled()) {
            graph.scope.launch {
                graph.init()
                if (graph.core.account.value != null) {
                    NuvaService.start(application)
                    runOnUiThread { host.askOnce() }
                }
            }
        }
    }

    override fun onStop() {
        graph.setForeground(false)
        super.onStop()
    }
}
