package app.nuva.desktop

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.widthIn
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Window
import androidx.compose.ui.window.application
import androidx.compose.ui.window.rememberWindowState
import app.nuva.ui.AppGraph
import app.nuva.ui.NuvaApp
import app.nuva.ui.theme.NuvaColors
import java.awt.Dimension
import java.awt.event.WindowAdapter
import java.awt.event.WindowEvent
import kotlin.system.exitProcess

fun main() {
    val platform = DesktopPlatform()
    // Два окна = два сокета одного устройства: сервер будет выкидывать то одно, то другое.
    if (!platform.acquireSingleInstanceLock()) exitProcess(0)

    val graph = AppGraph(platform)
    DesktopNotifier(graph).start()
    application {
        Window(
            onCloseRequest = ::exitApplication,
            title = "Nuva",
            state = rememberWindowState(size = DpSize(980.dp, 720.dp)),
            icon = painterResource("nuva.png"),
        ) {
            window.minimumSize = Dimension(380, 560)
            // Окно в фокусе = «приложение на экране»: только тогда сообщения считаются прочитанными, а
            // системные уведомления не нужны. Вернулись в окно — ещё и переподключаемся сразу.
            DisposableEffect(window) {
                graph.setForeground(window.isActive)
                val l = object : WindowAdapter() {
                    override fun windowActivated(e: WindowEvent?) = graph.setForeground(true)
                    override fun windowDeactivated(e: WindowEvent?) = graph.setForeground(false)
                    override fun windowIconified(e: WindowEvent?) = graph.setForeground(false)
                }
                window.addWindowListener(l)
                onDispose { window.removeWindowListener(l) }
            }
            Box(
                Modifier.fillMaxSize().background(NuvaColors.Night)
                    // Esc = «назад», как системная кнопка на телефоне.
                    .onPreviewKeyEvent { e ->
                        if (e.type == KeyEventType.KeyDown && e.key == Key.Escape) graph.back() else false
                    },
                contentAlignment = Alignment.Center,
            ) {
                // На широком мониторе интерфейс — колонка по центру, а не растянутый на всё окно.
                Box(Modifier.widthIn(max = 720.dp).fillMaxHeight()) { NuvaApp(graph) }
            }
        }
    }
}
