package app.nuva.core

import app.cash.sqldelight.driver.jdbc.sqlite.JdbcSqliteDriver
import app.nuva.db.NuvaDatabase
import kotlin.test.Test
import kotlin.test.assertEquals

/** Пользователи 0.2.3 (схема v1) должны обновиться без потери переписки и непрочитанных. */
class MigrationTest {
    private val v1 = listOf(
        """CREATE TABLE chat (
            peer_id TEXT NOT NULL PRIMARY KEY,
            last_text TEXT NOT NULL DEFAULT '',
            last_ts INTEGER NOT NULL DEFAULT 0,
            last_outgoing INTEGER NOT NULL DEFAULT 0,
            last_status INTEGER NOT NULL DEFAULT 0,
            unread INTEGER NOT NULL DEFAULT 0
        )""",
        """CREATE TABLE message (
            local_id INTEGER PRIMARY KEY AUTOINCREMENT,
            peer_id TEXT NOT NULL,
            client_msg_id TEXT NOT NULL,
            outgoing INTEGER NOT NULL,
            body TEXT NOT NULL,
            ts INTEGER NOT NULL,
            server_ts INTEGER,
            status INTEGER NOT NULL
        )""",
    )

    @Test
    fun migratesV1KeepingMessagesAndUnread() {
        val driver = JdbcSqliteDriver(JdbcSqliteDriver.IN_MEMORY)
        for (sql in v1) driver.execute(null, sql, 0)
        driver.execute(null, "INSERT INTO chat(peer_id, last_text, last_ts, unread) VALUES ('p', 'x', 1, 2)", 0)
        for (i in 0 until 4) {
            driver.execute(null, "INSERT INTO message(peer_id, client_msg_id, outgoing, body, ts, status) VALUES ('p', 'in$i', 0, 'b', $i, 10)", 0)
        }
        driver.execute(null, "INSERT INTO message(peer_id, client_msg_id, outgoing, body, ts, status) VALUES ('p', 'out', 1, 'b', 9, 1)", 0)

        NuvaDatabase.Schema.migrate(driver, 1, NuvaDatabase.Schema.version)

        val q = NuvaDatabase(driver).nuvaQueries
        assertEquals(2L, NuvaDatabase.Schema.version)
        // chat.unread = 2 → непрочитанными остаются два самых новых входящих.
        assertEquals(listOf("in2", "in3"), q.unreadIncomingAll("p").executeAsList())
        assertEquals(5, q.messagesFor("p", 100).executeAsList().size)
    }
}
