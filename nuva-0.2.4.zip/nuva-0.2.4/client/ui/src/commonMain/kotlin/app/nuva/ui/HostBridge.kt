package app.nuva.ui

/**
 * Возможности хост-платформы, которых нет в общем коде: уведомления и фоновая работа.
 * Android реализует всё; desktop берёт значения по умолчанию.
 */
interface HostBridge {
    /** Есть ли у платформы фоновая служба приёма сообщений (показываем её настройки в профиле). */
    val supportsBackground: Boolean get() = false

    fun backgroundEnabled(): Boolean = false
    fun setBackgroundEnabled(enabled: Boolean) {}

    /** Разрешены ли системные уведомления (на Android 13+ нужно runtime-разрешение). */
    fun notificationsAllowed(): Boolean = true
    fun requestNotifications() {}

    /** Системный экран «Оптимизация батареи». Без исключения оболочки вроде ColorOS убивают фон. */
    fun openBatterySettings() {}

    /** Экран приложения в настройках (автозапуск и т. п.). */
    fun openAppSettings() {}

    companion object {
        val None: HostBridge = object : HostBridge {}
    }
}
