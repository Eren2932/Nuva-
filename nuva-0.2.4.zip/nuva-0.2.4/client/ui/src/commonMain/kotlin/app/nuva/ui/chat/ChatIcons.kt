package app.nuva.ui.chat

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** Иконки, которых нет в material-icons-core. Сетка 24×24, линия 2. */

private fun DrawScope.lineStyle(): Stroke =
    Stroke(width = 2f * (size.width / 24f), cap = StrokeCap.Round, join = StrokeJoin.Round)

/** Стрелка «ответить» ↩. */
@Composable
fun ReplyIcon(color: Color, size: Dp = 24.dp, modifier: Modifier = Modifier) {
    Canvas(modifier.size(size)) {
        val k = this.size.width / 24f
        val p = Path().apply {
            moveTo(10f * k, 5f * k)
            lineTo(4f * k, 11f * k)
            lineTo(10f * k, 17f * k)
        }
        drawPath(p, color, style = lineStyle())
        val body = Path().apply {
            moveTo(4.5f * k, 11f * k)
            lineTo(14f * k, 11f * k)
            cubicTo(18f * k, 11f * k, 20f * k, 13.5f * k, 20f * k, 18.5f * k)
        }
        drawPath(body, color, style = lineStyle())
    }
}

/** Два листа «копировать». */
@Composable
fun CopyIcon(color: Color, size: Dp = 24.dp, modifier: Modifier = Modifier) {
    Canvas(modifier.size(size)) {
        val k = this.size.width / 24f
        drawRoundRect(color, Offset(8f * k, 8f * k), Size(11f * k, 12f * k), CornerRadius(2.5f * k), style = lineStyle())
        val back = Path().apply {
            moveTo(15f * k, 5.5f * k)
            lineTo(15f * k, 5f * k)
            cubicTo(15f * k, 4f * k, 14.2f * k, 3.5f * k, 13.5f * k, 3.5f * k)
            lineTo(6.5f * k, 3.5f * k)
            cubicTo(5.4f * k, 3.5f * k, 4.5f * k, 4.4f * k, 4.5f * k, 5.5f * k)
            lineTo(4.5f * k, 14.5f * k)
            cubicTo(4.5f * k, 15.6f * k, 5.4f * k, 16f * k, 6f * k, 16f * k)
        }
        drawPath(back, color, style = lineStyle())
    }
}
