package app.nuva.ui.chat

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.coerceAtLeast
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.toSize
import app.nuva.core.chat.ChatMessage
import app.nuva.core.chat.Limits
import app.nuva.core.chat.Messenger
import app.nuva.core.chat.MsgStatus
import app.nuva.core.chat.Peer
import app.nuva.core.chat.ReplyRef
import app.nuva.core.net.SocketState
import app.nuva.ui.AppGraph
import app.nuva.ui.chats.requireMessenger
import app.nuva.ui.components.Avatar
import app.nuva.ui.components.connectionLabel
import app.nuva.ui.components.dayKey
import app.nuva.ui.components.daySeparator
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.launch

private const val PAGE = 80L

/** Сообщения одного автора ближе этого интервала склеиваются в группу (как в Telegram). */
private const val GROUP_MS = 5 * 60_000L

/** Сообщение считается «увиденным», когда на экране не меньше этой доли его высоты. */
private const val VISIBLE_FRACTION = 0.6f

private class PopupState(val localId: Long, val anchor: Offset)

@OptIn(ExperimentalCoroutinesApi::class)
@Composable
fun ChatScreen(graph: AppGraph, peerId: String) {
    val m = requireMessenger(graph) ?: return
    val socket by graph.core.socket.state.collectAsState()
    val foreground by graph.core.foreground.collectAsState()
    val peer by remember(m, peerId) { m.peer(peerId) }.collectAsState(initial = null)

    // Окно сообщений растёт страницами; flatMapLatest не сбрасывает список при подгрузке → без мерцания.
    val limit = remember(peerId) { MutableStateFlow(PAGE) }
    val messages by remember(m, peerId) { limit.flatMapLatest { m.messages(peerId, it) } }
        .collectAsState(initial = null)
    val list = messages.orEmpty()
    val listNow by rememberUpdatedState(list)
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    val haptic = LocalHapticFeedback.current
    val density = LocalDensity.current
    val gradientHost = remember { GradientHost() }

    var showInfo by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf(emptySet<Long>()) }
    var popup by remember { mutableStateOf<PopupState?>(null) }
    var replyTo by remember { mutableStateOf<ReplyDraft?>(null) }
    var deleteTarget by remember { mutableStateOf<List<ChatMessage>?>(null) }
    var jump by remember { mutableStateOf<ReplyRef?>(null) }
    var highlightId by remember { mutableStateOf<Long?>(null) }
    var headerPx by remember { mutableIntStateOf(0) }
    var composerPx by remember { mutableIntStateOf(0) }
    var innerSize by remember { mutableStateOf(Size.Zero) }
    val selectionMode = selected.isNotEmpty()
    val peerTitle = peer?.title.orEmpty()

    // Открытый чат: «прочитано» уходит только для него. Уходим — снимаем отметку.
    DisposableEffect(m, peerId) {
        m.activeChat.value = peerId
        onDispose { if (m.activeChat.value == peerId) m.activeChat.value = null }
    }

    // «Назад» сначала закрывает мини-блок, снимает выделение, отменяет ответ.
    DisposableEffect(graph) {
        graph.backHook = {
            when {
                popup != null -> { popup = null; true }
                selected.isNotEmpty() -> { selected = emptySet(); true }
                replyTo != null -> { replyTo = null; true }
                else -> false
            }
        }
        onDispose { graph.backHook = null }
    }

    // Удалённые сообщения не должны оставаться в выделении или в мини-блоке.
    LaunchedEffect(list) {
        if (messages != null) {
            val alive = list.mapTo(HashSet()) { it.localId }
            if (selected.any { it !in alive }) selected = selected.filterTo(HashSet()) { it in alive }
            popup?.let { if (it.localId !in alive) popup = null }
        }
    }

    val newest = list.firstOrNull()
    LaunchedEffect(newest?.localId) {
        // Своё сообщение — всегда вниз; чужое — только если пользователь и так внизу.
        if (newest != null && (newest.outgoing || listState.firstVisibleItemIndex <= 2)) {
            listState.animateScrollToItem(0)
        }
    }

    // «Прочитано» — только когда приложение на экране и сообщение реально видно. Читаем всё, что не новее
    // самого нового видимого входящего: так делает и Telegram.
    LaunchedEffect(foreground, m, peerId) {
        if (!foreground) return@LaunchedEffect
        snapshotFlow {
            val info = listState.layoutInfo
            val top = info.viewportStartOffset + info.beforeContentPadding
            val bottom = info.viewportEndOffset - info.afterContentPadding
            var maxVisible = -1L
            for (item in info.visibleItemsInfo) {
                val key = item.key as? Long ?: continue
                if (item.size <= 0) continue
                val visible = minOf(item.offset + item.size, bottom) - maxOf(item.offset, top)
                if (visible.toFloat() / item.size >= VISIBLE_FRACTION && key > maxVisible) maxVisible = key
            }
            maxVisible
        }.distinctUntilChanged().collect { id -> if (id >= 0) m.markRead(peerId, id) }
    }

    // Подгрузка истории при приближении к верху.
    LaunchedEffect(listState, list.size) {
        snapshotFlow { listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0 }
            .distinctUntilChanged()
            .collect { last -> if (list.size.toLong() >= limit.value && last >= list.size - 15) limit.value += PAGE }
    }

    // Переход к цитате: догружаем окно до нужной позиции, прокручиваем и подсвечиваем.
    LaunchedEffect(jump) {
        val target = jump ?: return@LaunchedEffect
        val idx = m.positionOf(peerId, target.clientMsgId, target.mine)
        if (idx == null) {
            jump = null
            return@LaunchedEffect
        }
        if (idx >= limit.value) limit.value = idx + PAGE
        snapshotFlow { listNow.size }.first { it > idx }
        listState.animateScrollToItem(idx.toInt(), -(listState.layoutInfo.viewportSize.height / 3))
        listNow.getOrNull(idx.toInt())?.let { highlightId = it.localId }
        delay(900)
        highlightId = null
        jump = null
    }

    fun startReply(msg: ChatMessage) {
        replyTo = ReplyDraft(
            ReplyRef(msg.clientMsgId, msg.outgoing, msg.body.replace('\n', ' ').take(Limits.REPLY_SNIPPET)),
            if (msg.outgoing) "себе" else peerTitle,
        )
    }

    val statusTop = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val headerDp = with(density) { headerPx.toDp() }.coerceAtLeast(statusTop + 56.dp)
    val composerDp = with(density) { composerPx.toDp() }
    val hostWidthDp = if (gradientHost.size.width > 0f) with(density) { gradientHost.size.width.toDp() } else 360.dp
    val maxBubble = minOf(hostWidthDp - 91.dp, 420.dp)

    Box(
        Modifier
            .fillMaxSize()
            .background(ChatColors.Bg)
            .onGloballyPositioned {
                gradientHost.origin = it.positionInRoot()
                gradientHost.size = it.size.toSize()
            },
    ) {
        CompositionLocalProvider(LocalGradientHost provides gradientHost) {
            Box(
                Modifier
                    .fillMaxSize()
                    .imePadding()
                    .onSizeChanged { innerSize = it.toSize() },
            ) {
                // ── Список. Шапки и поля ввода «с контейнером» нет: они лежат поверх списка.
                if (messages != null && list.isEmpty()) EmptyChat(Modifier.align(Alignment.Center))
                LazyColumn(
                    state = listState,
                    reverseLayout = true,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(top = headerDp + 6.dp, bottom = composerDp + 2.dp),
                ) {
                    itemsIndexed(list, key = { _, msg -> msg.localId }) { i, msg ->
                        val newer = list.getOrNull(i - 1)
                        val older = list.getOrNull(i + 1)
                        val newDay = older == null || dayKey(older.ts) != dayKey(msg.ts)
                        val groupEnd = newer == null || newer.outgoing != msg.outgoing ||
                            newer.ts - msg.ts > GROUP_MS || dayKey(newer.ts) != dayKey(msg.ts)
                        val groupStart = newDay || older!!.outgoing != msg.outgoing || msg.ts - older.ts > GROUP_MS
                        val lit = highlightId == msg.localId
                        val highlight by animateFloatAsState(
                            if (lit) 1f else 0f,
                            tween(if (lit) 120 else 900),
                            label = "quoteHighlight",
                        )
                        Column(Modifier.animateItem()) {
                            if (newDay) DayChip(msg.ts)
                            MessageRow(
                                msg = msg,
                                groupStart = groupStart,
                                groupEnd = groupEnd,
                                peerTitle = peerTitle,
                                maxBubble = maxBubble,
                                selected = msg.localId in selected,
                                selectionMode = selectionMode,
                                highlight = highlight,
                                onTap = { anchor ->
                                    if (selectionMode) {
                                        selected = if (msg.localId in selected) selected - msg.localId else selected + msg.localId
                                    } else {
                                        popup = PopupState(msg.localId, anchor)
                                    }
                                },
                                onLongPress = {
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                    popup = null
                                    selected = if (msg.localId in selected) selected - msg.localId else selected + msg.localId
                                },
                                onSwipeReply = { startReply(msg) },
                                onQuoteClick = { ref -> jump = ref },
                                onReactionClick = { emoji -> scope.launch { m.react(peerId, msg, emoji) } },
                                onRetry = { scope.launch { m.retry(peerId, msg.clientMsgId) } },
                            )
                        }
                    }
                }

                // ── Верх: затемнение + плашки без общего контейнера
                Box(
                    Modifier
                        .align(Alignment.TopCenter)
                        .fillMaxWidth()
                        .height(headerDp + 26.dp)
                        .background(Brush.verticalGradient(listOf(ChatColors.Bg.copy(alpha = 0.92f), ChatColors.Bg.copy(alpha = 0f)))),
                )
                Column(
                    Modifier
                        .align(Alignment.TopCenter)
                        .fillMaxWidth()
                        .onSizeChanged { headerPx = it.height },
                ) {
                    if (selectionMode) {
                        SelectionHeader(
                            count = selected.size,
                            onClose = { selected = emptySet() },
                            onCopy = {
                                val chosen = listNow.filter { it.localId in selected }.sortedBy { it.localId }
                                clipboard.setText(AnnotatedString(chosen.joinToString("\n") { it.body }))
                                selected = emptySet()
                            },
                            onDelete = { deleteTarget = listNow.filter { it.localId in selected }.sortedBy { it.localId } },
                        )
                    } else {
                        ChatHeader(
                            peerId = peerId,
                            peer = peer,
                            statusText = connectionLabel(socket)?.lowercase() ?: peer?.let { "@${it.username}" } ?: "",
                            online = socket == SocketState.Online,
                            onBack = { graph.router.back() },
                            onInfo = { showInfo = true },
                            onClear = { scope.launch { m.clearChat(peerId) } },
                        )
                    }
                    peer?.takeIf { it.keyChanged }?.let { p ->
                        KeyChangedBanner(p, onCheck = { showInfo = true }) { scope.launch { m.acceptKeyChange(peerId) } }
                    }
                }

                // ── Низ: затемнение + поле ввода без контейнера
                Column(
                    Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .background(Brush.verticalGradient(listOf(ChatColors.Bg.copy(alpha = 0f), ChatColors.Bg.copy(alpha = 0.92f))))
                        .onSizeChanged { composerPx = it.height }
                        .navigationBarsPadding()
                        .padding(top = 12.dp),
                ) {
                    Composer(
                        reply = replyTo,
                        onCancelReply = { replyTo = null },
                        onSend = { text ->
                            val ref = replyTo?.ref
                            replyTo = null
                            scope.launch { m.sendText(peerId, text, ref) }
                        },
                    )
                }

                // ── Мини-блок по нажатию
                val pm = popup
                val popMsg = pm?.let { p -> list.firstOrNull { it.localId == p.localId } }
                if (pm != null && popMsg != null) {
                    MessageContextPopup(
                        anchor = pm.anchor,
                        hostSize = innerSize,
                        topInsetPx = with(density) { headerDp.toPx() },
                        myReaction = popMsg.myReaction,
                        actions = buildList {
                            add(PopupAction("Ответить", PopupIcon.Reply) { startReply(popMsg) })
                            add(PopupAction("Копировать", PopupIcon.Copy) { clipboard.setText(AnnotatedString(popMsg.body)) })
                            if (popMsg.status == MsgStatus.FAILED) {
                                add(PopupAction("Отправить ещё раз", PopupIcon.Retry) {
                                    scope.launch { m.retry(peerId, popMsg.clientMsgId) }
                                })
                            }
                            add(PopupAction("Удалить", PopupIcon.Delete) { deleteTarget = listOf(popMsg) })
                        },
                        onReact = { emoji -> scope.launch { m.react(peerId, popMsg, emoji) } },
                        onDismiss = { popup = null },
                    )
                }
            }
        }
    }

    // ── Диалоги
    deleteTarget?.let { targets ->
        val canForAll = targets.all { it.outgoing }
        var forAll by remember(targets) { mutableStateOf(false) }
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text(if (targets.size == 1) "Удалить сообщение?" else "Удалить ${targets.size} ${plural(targets.size)}?") },
            text = if (canForAll) ({
                Row(
                    Modifier.fillMaxWidth().clickable { forAll = !forAll },
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Checkbox(forAll, onCheckedChange = { forAll = it })
                    Text("Также удалить у ${peer?.let { "@${it.username}" } ?: "собеседника"}")
                }
            }) else null,
            confirmButton = {
                TextButton(onClick = {
                    scope.launch { if (forAll) m.deleteForAll(peerId, targets) else m.deleteForMe(peerId, targets) }
                    selected = emptySet()
                    deleteTarget = null
                }) { Text("Удалить", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("Отмена") } },
        )
    }

    val p = peer
    if (showInfo && p != null) PeerInfoDialog(p, m, onDismiss = { showInfo = false }) {
        scope.launch { m.acceptKeyChange(peerId) }
        showInfo = false
    }
}

private fun plural(n: Int): String {
    val mod10 = n % 10
    val mod100 = n % 100
    return when {
        mod10 == 1 && mod100 != 11 -> "сообщение"
        mod10 in 2..4 && mod100 !in 12..14 -> "сообщения"
        else -> "сообщений"
    }
}

// ───────────────────────── Шапка ─────────────────────────

@Composable
private fun HeaderPill(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable RowScope.() -> Unit) {
    val shape = RoundedCornerShape(22.dp)
    Row(
        modifier
            .height(44.dp)
            .clip(shape)
            .background(ChatColors.Pill)
            .border(1.dp, ChatColors.PillBorder, shape)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier),
        verticalAlignment = Alignment.CenterVertically,
        content = content,
    )
}

/**
 * Шапка без контейнера: три плашки поверх затемнения. Начинается на 6dp ниже статус-бара, отступы по краям
 * и между плашками 6dp. Слева круг 44dp, по центру плашка с аватаром 40dp, справа плашка 80dp.
 */
@Composable
private fun ChatHeader(
    peerId: String,
    peer: Peer?,
    statusText: String,
    online: Boolean,
    onBack: () -> Unit,
    onInfo: () -> Unit,
    onClear: () -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth().statusBarsPadding().padding(top = 6.dp, start = 6.dp, end = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        HeaderPill(Modifier.size(44.dp), onClick = onBack) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "Назад", Modifier.size(24.dp), tint = Color.White)
            }
        }
        HeaderPill(Modifier.weight(1f), onClick = if (peer != null) onInfo else null) {
            Spacer(Modifier.width(2.dp))
            Avatar(peerId, peer?.title ?: "", 40.dp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f).padding(end = 12.dp), verticalArrangement = Arrangement.Center) {
                Text(
                    peer?.title ?: "",
                    fontSize = 15.sp,
                    lineHeight = 18.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    statusText,
                    fontSize = 12.sp,
                    lineHeight = 15.sp,
                    color = if (online) ChatColors.Accent else ChatColors.Hint,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
        HeaderPill(Modifier.width(80.dp)) {
            Box(Modifier.size(40.dp).clip(CircleShape).clickable(enabled = peer != null, onClick = onInfo), contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.Lock, "Код безопасности", Modifier.size(20.dp), tint = Color.White)
            }
            Box {
                Box(Modifier.size(40.dp).clip(CircleShape).clickable { menu = true }, contentAlignment = Alignment.Center) {
                    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        repeat(3) { Box(Modifier.size(3.5.dp).background(Color.White, CircleShape)) }
                    }
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("Код безопасности") }, onClick = { menu = false; onInfo() })
                    DropdownMenuItem(text = { Text("Очистить историю") }, onClick = { menu = false; onClear() })
                }
            }
        }
    }
}

/** Режим выделения (долгое нажатие): «Выбрано N», копировать, удалить. */
@Composable
private fun SelectionHeader(count: Int, onClose: () -> Unit, onCopy: () -> Unit, onDelete: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().statusBarsPadding().padding(top = 6.dp, start = 6.dp, end = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        HeaderPill(Modifier.size(44.dp), onClick = onClose) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.Close, "Отменить выделение", Modifier.size(22.dp), tint = Color.White)
            }
        }
        HeaderPill(Modifier.weight(1f)) {
            Text("Выбрано $count", Modifier.padding(horizontal = 16.dp), fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
        }
        HeaderPill(Modifier.width(80.dp)) {
            Box(Modifier.size(40.dp).clip(CircleShape).clickable(onClick = onCopy), contentAlignment = Alignment.Center) {
                CopyIcon(Color.White, 22.dp)
            }
            Box(Modifier.size(40.dp).clip(CircleShape).clickable(onClick = onDelete), contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.Delete, "Удалить", Modifier.size(22.dp), tint = Color.White)
            }
        }
    }
}

// ───────────────────────── Мелочи ─────────────────────────

@Composable
private fun DayChip(ts: Long) {
    Box(Modifier.fillMaxWidth().padding(vertical = 10.dp), contentAlignment = Alignment.Center) {
        Surface(color = ChatColors.ChipBg, shape = RoundedCornerShape(14.dp)) {
            Text(
                daySeparator(ts),
                Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color.White,
            )
        }
    }
}

@Composable
private fun EmptyChat(modifier: Modifier) {
    Surface(modifier.padding(32.dp), color = ChatColors.Incoming.copy(alpha = 0.9f), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(horizontal = 24.dp, vertical = 20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Filled.Lock, null, tint = ChatColors.Accent, modifier = Modifier.size(32.dp))
            Spacer(Modifier.height(10.dp))
            Text("Сообщений пока нет", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
            Spacer(Modifier.height(6.dp))
            Text(
                "Сообщения шифруются на этом устройстве. Сервер видит только зашифрованные данные.",
                fontSize = 14.sp,
                color = ChatColors.Hint,
                textAlign = TextAlign.Center,
            )
        }
    }
}

@Composable
private fun KeyChangedBanner(peer: Peer, onCheck: () -> Unit, onAccept: () -> Unit) {
    Surface(
        Modifier.padding(start = 6.dp, end = 6.dp, top = 6.dp),
        color = Color(0xFF3A1B1F),
        shape = RoundedCornerShape(16.dp),
    ) {
        Row(
            Modifier.fillMaxWidth().padding(start = 14.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Filled.Warning, null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(10.dp))
            Text(
                "Ключ @${peer.username} изменился. Сверьте код безопасности.",
                Modifier.weight(1f),
                fontSize = 13.sp,
                color = Color.White,
            )
            TextButton(onClick = onCheck) { Text("Код") }
            TextButton(onClick = onAccept) { Text("Принять") }
        }
    }
}

@Composable
private fun PeerInfoDialog(peer: Peer, m: Messenger, onDismiss: () -> Unit, onAccept: () -> Unit) {
    val code = remember(peer.identityKey) { m.safetyNumber(peer) }
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Avatar(peer.accountId, peer.title, 64.dp) },
        title = { Text(peer.title, textAlign = TextAlign.Center) },
        text = {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                Text("@${peer.username}", color = MaterialTheme.colorScheme.secondary)
                Spacer(Modifier.height(18.dp))
                Text("Код безопасности", style = MaterialTheme.typography.labelLarge)
                Spacer(Modifier.height(8.dp))
                Text(
                    code, fontFamily = FontFamily.Monospace, fontSize = 17.sp, lineHeight = 26.sp,
                    textAlign = TextAlign.Center, letterSpacing = 1.sp,
                )
                Spacer(Modifier.height(10.dp))
                Text(
                    "Сравните код с собеседником при встрече или по звонку. Совпадает — переписку никто не подменяет.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                )
            }
        },
        confirmButton = {
            if (peer.keyChanged) TextButton(onClick = onAccept) { Text("Код совпал — принять") }
            else TextButton(onClick = onDismiss) { Text("Готово") }
        },
        dismissButton = if (peer.keyChanged) ({ TextButton(onClick = onDismiss) { Text("Позже") } }) else null,
    )
}
