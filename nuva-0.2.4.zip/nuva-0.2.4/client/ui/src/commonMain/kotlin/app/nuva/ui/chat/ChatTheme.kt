package app.nuva.ui.chat

import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

/**
 * Палитра экрана чата — снята с референс-ролика (1080×2400, ×3 → 360dp). Остальные экраны остаются
 * в фирменной палитре NuvaColors, чат живёт по своей.
 */
object ChatColors {
    val Bg = Color(0xFF020103)
    val Incoming = Color(0xFF201E22)
    /** Плашки шапки: светлая тонкая обводка. */
    val Pill = Color(0xFF262626)
    val PillBorder = Color(0x1FFFFFFF)
    val Input = Color(0xFF1E1E1E)
    /** Мини-блок по нажатию: и меню, и полоса реакций. */
    val Popup = Color(0xFF282828)
    val Accent = Color(0xFFBA66EB)
    /** Подсветка сообщения после перехода к цитате (гаснет). */
    val HighlightBand = Color(0xFF1E1524)
    /** Выбранное сообщение в режиме выделения. */
    val SelectionBand = Color(0xFF2A1B38)
    val Hint = Color(0xFF8E8E93)
    val ChipBg = Color(0x66000000)

    private val GradTop = Color(0xFF2F86A0)
    private val GradMid = Color(0xFF4E5FA3)
    private val GradBottom = Color(0xFF7246AA)

    /**
     * Градиент исходящих привязан к ЭКРАНУ, а не к пузырю: сверху справа бирюзово-синий, посередине
     * #4E5FA3, снизу слева фиолетовый. Пузырь при прокрутке «едет» по градиенту. Координаты — в системе
     * самого пузыря: [hostOrigin] — левый верх чата относительно пузыря.
     */
    fun outgoingBrush(hostOrigin: Offset, host: Size): Brush = Brush.linearGradient(
        colorStops = arrayOf(0f to GradTop, 0.5f to GradMid, 1f to GradBottom),
        start = Offset(hostOrigin.x + host.width, hostOrigin.y),
        end = Offset(hostOrigin.x, hostOrigin.y + host.height),
    )
}

/** Положение и размер области чата в корне окна: от них зависит общий градиент пузырей. */
@Stable
class GradientHost {
    var origin by mutableStateOf(Offset.Zero)
    var size by mutableStateOf(Size.Zero)
}

val LocalGradientHost = staticCompositionLocalOf { GradientHost() }
