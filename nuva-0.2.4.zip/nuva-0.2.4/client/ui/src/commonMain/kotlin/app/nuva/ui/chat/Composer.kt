package app.nuva.ui.chat

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.isShiftPressed
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.nuva.core.chat.Limits
import app.nuva.core.chat.ReplyRef

/** Что мы цитируем в поле ввода. */
class ReplyDraft(val ref: ReplyRef, val authorName: String)

/**
 * Поле ввода без внешнего контейнера: только плашка #1E1E1E (высота 41dp, отступы 7dp), сверху и снизу —
 * затемнение. При ответе плашка растёт вверх на ~47dp за ~120мс с замедлением в конце, радиус при этом
 * уменьшается с ~20 до ~16dp.
 */
@Composable
internal fun Composer(
    reply: ReplyDraft?,
    onCancelReply: () -> Unit,
    onSend: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    var text by rememberSaveable { mutableStateOf("") }
    val focus = remember { FocusRequester() }
    val canSend = text.isNotBlank()

    // Выбрали «Ответить» — сразу открываем клавиатуру.
    LaunchedEffect(reply?.ref?.clientMsgId, reply?.ref?.mine) {
        if (reply != null) runCatching { focus.requestFocus() }
    }

    val radius by animateDpAsState(
        if (reply != null) 16.dp else 20.5.dp,
        tween(120, easing = FastOutSlowInEasing),
        label = "composerRadius",
    )

    fun send() {
        val t = text.trim()
        if (t.isEmpty()) return
        onSend(t)
        text = ""
    }

    Column(modifier.fillMaxWidth().padding(start = 7.dp, end = 7.dp, bottom = 7.dp, top = 6.dp)) {
        if (text.length > Limits.MAX_TEXT - 300) {
            Text(
                "${text.length}/${Limits.MAX_TEXT}",
                Modifier.fillMaxWidth().padding(end = 10.dp, bottom = 4.dp),
                textAlign = TextAlign.End,
                fontSize = 11.sp,
                color = ChatColors.Hint,
            )
        }
        Box(
            Modifier
                .fillMaxWidth()
                .animateContentSize(tween(120, easing = FastOutSlowInEasing))
                .clip(RoundedCornerShape(radius))
                .background(ChatColors.Input),
        ) {
            Column {
                if (reply != null) ReplyPanel(reply, onCancelReply)
                Row(
                    Modifier.fillMaxWidth().heightIn(min = 41.dp),
                    verticalAlignment = Alignment.Bottom,
                ) {
                    Box(
                        Modifier.weight(1f).padding(start = 16.dp, end = 8.dp, top = 9.5.dp, bottom = 9.5.dp),
                        contentAlignment = Alignment.CenterStart,
                    ) {
                        if (text.isEmpty()) {
                            Text("Сообщение", fontSize = 16.sp, lineHeight = 22.sp, color = ChatColors.Hint)
                        }
                        BasicTextField(
                            value = text,
                            onValueChange = { text = it.take(Limits.MAX_TEXT) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .focusRequester(focus)
                                .onPreviewKeyEvent { e ->
                                    // Desktop: Enter отправляет, Shift+Enter — перенос строки.
                                    if ((e.key == Key.Enter || e.key == Key.NumPadEnter) && !e.isShiftPressed) {
                                        if (e.type == KeyEventType.KeyDown) send()
                                        true
                                    } else false
                                },
                            textStyle = TextStyle(color = Color.White, fontSize = 16.sp, lineHeight = 22.sp),
                            cursorBrush = SolidColor(ChatColors.Accent),
                            maxLines = 6,
                            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                        )
                    }
                    AnimatedVisibility(
                        visible = canSend,
                        enter = scaleIn(tween(120)) + fadeIn(tween(120)),
                        exit = scaleOut(tween(90)) + fadeOut(tween(90)),
                    ) {
                        Box(
                            Modifier
                                .padding(end = 2.5.dp, bottom = 2.5.dp)
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(ChatColors.Accent)
                                .clickable { send() },
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Send, "Отправить", Modifier.size(19.dp), tint = Color.White)
                        }
                    }
                }
            }
        }
    }
}

/** Панель «В ответ …»: иконка ответа, автор акцентным цветом, кусок текста, крестик. Высота 47dp. */
@Composable
private fun ReplyPanel(reply: ReplyDraft, onCancel: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().height(47.dp).padding(start = 13.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        ReplyIcon(ChatColors.Accent, 22.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
            Text(
                "В ответ ${reply.authorName}",
                fontSize = 14.sp,
                lineHeight = 18.sp,
                fontWeight = FontWeight.SemiBold,
                color = ChatColors.Accent,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                reply.ref.text.replace('\n', ' ').ifEmpty { "Сообщение" },
                fontSize = 14.sp,
                lineHeight = 18.sp,
                color = Color.White.copy(alpha = 0.7f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Box(
            Modifier
                .size(40.dp)
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onCancel() },
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Filled.Close, "Отменить ответ", Modifier.size(20.dp), tint = ChatColors.Hint)
        }
    }
}
