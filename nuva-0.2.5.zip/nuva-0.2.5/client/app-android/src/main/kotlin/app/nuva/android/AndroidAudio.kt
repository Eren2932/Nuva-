package app.nuva.android

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import app.nuva.core.voice.Nvoi
import app.nuva.core.voice.Pcm
import app.nuva.ui.voice.VoiceAudio
import app.nuva.ui.voice.VoicePlayer
import app.nuva.ui.voice.VoiceRecorder

/** Голосовые на Android: AudioRecord (VOICE_COMMUNICATION — системные AEC/NS) и AudioTrack. */
class AndroidAudio(private val app: Context, private val host: AndroidHost) : VoiceAudio {
    override fun micAllowed(): Boolean =
        app.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    override fun requestMic(onResult: (Boolean) -> Unit) = host.requestMic(onResult)

    override fun recorder(): VoiceRecorder = Recorder()

    override fun player(): VoicePlayer = Player(app)

    /** Растущий буфер отсчётов; пишет поток захвата, читает главный (длительность) и stop(). */
    private class Pcm16 {
        private var data = ShortArray(16_000 * 4)
        @Volatile var size = 0
            private set

        @Synchronized fun append(src: ShortArray, n: Int) {
            if (size + n > data.size) data = data.copyOf(maxOf(data.size * 2, size + n))
            System.arraycopy(src, 0, data, size, n)
            size += n
        }

        @Synchronized fun snapshot(): ShortArray = data.copyOf(size)
    }

    private class Recorder : VoiceRecorder {
        private var record: AudioRecord? = null
        private var thread: Thread? = null
        @Volatile private var running = false
        @Volatile private var lvl = 0f
        @Volatile override var paused = false
        private var rate = Nvoi.SAMPLE_RATE
        private val buf = Pcm16()

        override val level: Float get() = lvl
        override val durationMs: Long get() = buf.size * 1000L / rate

        @SuppressLint("MissingPermission") // проверяется в micAllowed() до вызова
        override fun start(): Boolean {
            // 16 кГц поддерживают почти все устройства; гарантирована только 44.1 — она запасная.
            for (r in intArrayOf(Nvoi.SAMPLE_RATE, 48_000, 44_100)) {
                val min = AudioRecord.getMinBufferSize(r, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
                if (min <= 0) continue
                val rec = try {
                    AudioRecord(
                        MediaRecorder.AudioSource.VOICE_COMMUNICATION, r,
                        AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                        maxOf(min, r / 5 * 2), // ≥ 200 мс: поток успевает даже при подлагивании
                    )
                } catch (e: Exception) {
                    null
                } ?: continue
                if (rec.state != AudioRecord.STATE_INITIALIZED) {
                    rec.release()
                    continue
                }
                try {
                    rec.startRecording()
                } catch (e: Exception) {
                    rec.release()
                    continue
                }
                if (rec.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
                    rec.release()
                    continue
                }
                record = rec
                rate = r
                running = true
                thread = Thread({ loop(rec, r) }, "nuva-rec").apply {
                    priority = Thread.MAX_PRIORITY
                    start()
                }
                return true
            }
            return false
        }

        private fun loop(rec: AudioRecord, r: Int) {
            val chunk = ShortArray(r / 50) // 20 мс
            while (running) {
                val n = rec.read(chunk, 0, chunk.size)
                if (n < 0) break
                if (n == 0) continue
                if (paused) {
                    lvl = 0f
                    continue
                }
                lvl = Pcm.level(chunk, n)
                buf.append(chunk, n)
            }
        }

        override fun stop(): ShortArray {
            halt()
            return Pcm.resample(buf.snapshot(), rate, Nvoi.SAMPLE_RATE)
        }

        override fun cancel() = halt()

        @Synchronized private fun halt() {
            if (!running && record == null) return
            running = false
            thread?.join(500)
            thread = null
            record?.let {
                runCatching { it.stop() }
                it.release()
            }
            record = null
        }
    }

    private class Player(context: Context) : VoicePlayer {
        private val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        private val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
            .build()
        private val focus = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
            .setAudioAttributes(attrs)
            .setOnAudioFocusChangeListener { change ->
                // Звонок/другой плеер забрал звук насовсем — останавливаемся (UI увидит isPlaying=false).
                if (change == AudioManager.AUDIOFOCUS_LOSS || change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) stop()
            }
            .build()
        @Volatile private var track: AudioTrack? = null
        private var thread: Thread? = null
        @Volatile private var running = false
        @Volatile private var base = 0

        override val position: Int
            get() {
                val t = track ?: return base
                return base + (runCatching { t.playbackHeadPosition }.getOrDefault(0))
            }

        override val isPlaying: Boolean get() = running

        override fun play(pcm: ShortArray, sampleRate: Int, from: Int) {
            stop()
            val min = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val bytes = maxOf(min, sampleRate / 5 * 2)
            val t = try {
                AudioTrack.Builder()
                    .setAudioAttributes(attrs)
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .build(),
                    )
                    .setBufferSizeInBytes(bytes)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()
            } catch (e: Exception) {
                return
            }
            am.requestAudioFocus(focus)
            base = from
            track = t
            running = true
            t.play()
            val total = pcm.size - from
            thread = Thread({
                var o = from
                while (running && o < pcm.size) {
                    val n = t.write(pcm, o, minOf(2048, pcm.size - o))
                    if (n <= 0) break
                    o += n
                }
                // Тишина на весь буфер: короткий хвост гарантированно доходит до динамика.
                if (running) t.write(ShortArray(bytes / 2), 0, bytes / 2)
                val deadline = System.currentTimeMillis() + total * 1000L / sampleRate + 1000
                while (running && runCatching { t.playbackHeadPosition }.getOrDefault(total) < total &&
                    System.currentTimeMillis() < deadline
                ) {
                    Thread.sleep(10)
                }
                running = false
            }, "nuva-play").apply { start() }
        }

        override fun stop() {
            running = false
            val t = track
            track = null
            if (t != null) {
                // pause+flush будит write(), поток выходит; release — только после него.
                runCatching { t.pause(); t.flush() }
                thread?.join(300)
                runCatching { t.stop() }
                t.release()
                am.abandonAudioFocusRequest(focus)
            }
            thread = null
        }
    }
}
