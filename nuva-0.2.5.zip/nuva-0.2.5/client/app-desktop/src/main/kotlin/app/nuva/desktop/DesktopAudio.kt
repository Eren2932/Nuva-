package app.nuva.desktop

import app.nuva.core.voice.Nvoi
import app.nuva.core.voice.Pcm
import app.nuva.ui.HostBridge
import app.nuva.ui.voice.VoiceAudio
import app.nuva.ui.voice.VoicePlayer
import app.nuva.ui.voice.VoiceRecorder
import javax.sound.sampled.AudioFormat
import javax.sound.sampled.AudioSystem
import javax.sound.sampled.DataLine
import javax.sound.sampled.SourceDataLine
import javax.sound.sampled.TargetDataLine

/** Desktop-часть HostBridge: пока только звук для голосовых. */
object DesktopHost : HostBridge {
    override val audio: VoiceAudio = DesktopAudio
}

/** Голосовые на JVM: javax.sound (16-бит моно, little-endian). Разрешений ОС не просит. */
object DesktopAudio : VoiceAudio {
    override fun recorder(): VoiceRecorder = Recorder()
    override fun player(): VoicePlayer = Player()

    private fun format(rate: Int) = AudioFormat(rate.toFloat(), 16, 1, true, false)

    private class Recorder : VoiceRecorder {
        private var line: TargetDataLine? = null
        private var thread: Thread? = null
        @Volatile private var running = false
        @Volatile private var lvl = 0f
        @Volatile override var paused = false
        @Volatile private var count = 0
        private var rate = Nvoi.SAMPLE_RATE
        private var data = ShortArray(16_000 * 4)
        private val lock = Any()

        override val level: Float get() = lvl
        override val durationMs: Long get() = count * 1000L / rate

        override fun start(): Boolean {
            for (r in intArrayOf(Nvoi.SAMPLE_RATE, 48_000, 44_100)) {
                val fmt = format(r)
                val info = DataLine.Info(TargetDataLine::class.java, fmt)
                if (!AudioSystem.isLineSupported(info)) continue
                val l = try {
                    (AudioSystem.getLine(info) as TargetDataLine).also { it.open(fmt, r / 5 * 2) }
                } catch (e: Exception) {
                    null
                } ?: continue
                l.start()
                line = l
                rate = r
                running = true
                thread = Thread({ loop(l, r) }, "nuva-rec").apply {
                    isDaemon = true
                    start()
                }
                return true
            }
            return false
        }

        private fun loop(l: TargetDataLine, r: Int) {
            val bytes = ByteArray(r / 50 * 2) // 20 мс
            val chunk = ShortArray(bytes.size / 2)
            while (running) {
                val n = l.read(bytes, 0, bytes.size) / 2
                if (n <= 0) continue
                if (paused) {
                    lvl = 0f
                    continue
                }
                for (i in 0 until n) {
                    chunk[i] = ((bytes[2 * i].toInt() and 0xFF) or (bytes[2 * i + 1].toInt() shl 8)).toShort()
                }
                lvl = Pcm.level(chunk, n)
                synchronized(lock) {
                    if (count + n > data.size) data = data.copyOf(maxOf(data.size * 2, count + n))
                    System.arraycopy(chunk, 0, data, count, n)
                    count += n
                }
            }
        }

        override fun stop(): ShortArray {
            halt()
            val pcm = synchronized(lock) { data.copyOf(count) }
            return Pcm.resample(pcm, rate, Nvoi.SAMPLE_RATE)
        }

        override fun cancel() = halt()

        @Synchronized private fun halt() {
            if (!running && line == null) return
            running = false
            line?.let {
                runCatching { it.stop() } // read() возвращается
                runCatching { it.close() }
            }
            thread?.join(500)
            thread = null
            line = null
        }
    }

    private class Player : VoicePlayer {
        @Volatile private var line: SourceDataLine? = null
        private var thread: Thread? = null
        @Volatile private var running = false
        @Volatile private var base = 0

        override val position: Int
            get() {
                val l = line ?: return base
                return base + l.longFramePosition.toInt()
            }

        override val isPlaying: Boolean get() = running

        override fun play(pcm: ShortArray, sampleRate: Int, from: Int) {
            stop()
            val fmt = format(sampleRate)
            val l = try {
                AudioSystem.getSourceDataLine(fmt).also { it.open(fmt, sampleRate / 5 * 2) }
            } catch (e: Exception) {
                return
            }
            l.start()
            base = from
            line = l
            running = true
            val total = pcm.size - from
            thread = Thread({
                val buf = ByteArray(4096)
                var o = from
                while (running && o < pcm.size) {
                    val n = minOf(buf.size / 2, pcm.size - o)
                    for (i in 0 until n) {
                        val v = pcm[o + i].toInt()
                        buf[2 * i] = v.toByte()
                        buf[2 * i + 1] = (v shr 8).toByte()
                    }
                    l.write(buf, 0, n * 2)
                    o += n
                }
                // drain() на остановленной линии может висеть вечно — ждём позицию с дедлайном.
                val deadline = System.currentTimeMillis() + total * 1000L / sampleRate + 1000
                while (running && l.longFramePosition < total && System.currentTimeMillis() < deadline) Thread.sleep(10)
                running = false
            }, "nuva-play").apply {
                isDaemon = true
                start()
            }
        }

        override fun stop() {
            running = false
            val l = line ?: return
            line = null
            runCatching { l.stop(); l.flush() } // write() возвращается
            thread?.join(300)
            thread = null
            runCatching { l.close() }
        }
    }
}
