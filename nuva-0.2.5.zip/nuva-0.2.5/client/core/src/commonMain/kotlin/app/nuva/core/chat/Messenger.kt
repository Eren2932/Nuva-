package app.nuva.core.chat

import app.cash.sqldelight.coroutines.asFlow
import app.cash.sqldelight.coroutines.mapToList
import app.cash.sqldelight.coroutines.mapToOneOrNull
import app.nuva.core.crypto.CryptoException
import app.nuva.core.crypto.NuvaCrypto
import app.nuva.core.net.NotConnectedException
import app.nuva.core.net.NuvaSocket
import app.nuva.core.net.isAuthed
import app.nuva.core.proto.ErrorCodes
import app.nuva.core.proto.Frames
import app.nuva.core.proto.RemoteAccount
import app.nuva.core.proto.ServerFrame
import app.nuva.core.store.Account
import app.nuva.core.util.B64
import app.nuva.core.util.Uuids
import app.nuva.core.voice.Nvoi
import app.nuva.db.Ctl
import app.nuva.db.Device
import app.nuva.db.Message
import app.nuva.db.NuvaDatabase
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.datetime.Clock
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.longOrNull

/**
 * Переписка 1:1 поверх store-and-forward сервера.
 *
 * Гарантии: исходящие — в локальной очереди (status=PENDING) до msg.sent, повтор идемпотентен
 * по client_msg_id; входящие — ack только ПОСЛЕ записи в БД (at-least-once + дедуп по
 * (peer, client_msg_id)).
 *
 * Служебные зашифрованные сообщения (тип в поле "t" открытого текста конверта; сервер их не отличает):
 *   text  — {body, ts, reply?:{id, own, text}}
 *   rcpt  — {ids}              доставлено на устройство
 *   read  — {ids}              реально прочитано (сообщение было на экране при открытом приложении)
 *   react — {id, own, emoji}   реакция; пустой emoji = снять
 *   del   — {ids}              «удалить у всех» (только свои сообщения отправителя)
 *   vchunk — {vid, i, n, d}    кусок голосового (NVOI, ≤ 32 КиБ); куски идут ДО заголовка
 *   voice — {ts, vid, dur, n, wave, reply?}  заголовок голосового = само сообщение (client_msg_id)
 *   played — {ids}             голосовое прослушано получателем
 * "own" всегда с позиции отправителя служебного сообщения. Старые клиенты неизвестные типы молча пропускают.
 * rcpt/read/react/del/played лежат в постоянной очереди ctl и уходят, пока сервер не примет конверт.
 */
public class Messenger(
    private val account: Account,
    private val db: NuvaDatabase,
    private val socket: NuvaSocket,
    private val io: CoroutineDispatcher,
    private val scope: CoroutineScope,
    private val foreground: StateFlow<Boolean>,
) {
    private val q get() = db.nuvaQueries
    private val json = Json { ignoreUnknownKeys = true }

    /** Открытый сейчас чат. «Прочитано» уходит только для него и только при [foreground]. */
    public val activeChat: MutableStateFlow<String?> = MutableStateFlow(null)

    private val _incoming = MutableSharedFlow<IncomingNotice>(extraBufferCapacity = 64)

    /** Новые входящие, пришедшие пока приложение не на экране: из них делаются системные уведомления. */
    public val incoming: SharedFlow<IncomingNotice> = _incoming.asSharedFlow()

    private val outboxKick = Channel<Unit>(Channel.CONFLATED)
    private val ctlKick = Channel<Unit>(Channel.CONFLATED)
    private val acks = Channel<Long>(Channel.UNLIMITED)

    public fun start() {
        scope.launch { processDeliveries() }
        scope.launch { ackLoop() }
        scope.launch { ctlLoop() }
        scope.launch { outboxLoop() }
        scope.launch {
            socket.state.collect {
                if (it.isAuthed) {
                    outboxKick.trySend(Unit)
                    ctlKick.trySend(Unit)
                }
            }
        }
    }

    // ─────────────── Наблюдаемые данные для UI ───────────────

    public fun chats(): Flow<List<ChatSummary>> =
        q.chatList { peerId, lastText, lastTs, lastOutgoing, lastStatus, unread, username, firstName, lastName ->
            ChatSummary(peerId, username, firstName, lastName, lastText, lastTs, lastOutgoing == 1L,
                MsgStatus.of(lastStatus), (unread ?: 0L).toInt())
        }.asFlow().mapToList(io)

    public fun messages(peerId: String, limit: Long): Flow<List<ChatMessage>> {
        val msgs = q.messagesFor(peerId, limit).asFlow().mapToList(io)
        val reacts = q.reactionsFor(peerId).asFlow().mapToList(io)
        return combine(msgs, reacts) { ml, rl ->
            val mine = HashMap<Pair<Long, String>, String>()
            val theirs = HashMap<Pair<Long, String>, String>()
            for (r in rl) (if (r.by_me == 1L) mine else theirs)[r.msg_out to r.client_msg_id] = r.emoji
            ml.map { m ->
                val key = m.outgoing to m.client_msg_id
                ChatMessage(
                    localId = m.local_id,
                    clientMsgId = m.client_msg_id,
                    outgoing = m.outgoing == 1L,
                    body = m.body,
                    ts = m.ts,
                    status = MsgStatus.of(m.status),
                    reply = m.reply_id?.let { ReplyRef(it, m.reply_out == 1L, m.reply_text) },
                    isRead = m.is_read == 1L,
                    myReaction = mine[key],
                    theirReaction = theirs[key],
                    voice = if (m.kind == KIND_VOICE && m.vid != null) VoiceInfo(
                        vid = m.vid,
                        durationMs = m.duration_ms ?: 0L,
                        wave = m.wave?.map { it.toInt() and 0xFF }.orEmpty(),
                        parts = (m.parts ?: 0L).toInt(),
                        haveParts = m.have_parts.toInt(),
                        sentParts = (m.sent_parts ?: 0L).toInt(),
                        listened = m.listened == 1L,
                    ) else null,
                )
            }
        }
    }

    /** Сколько сообщений новее указанного = индекс в списке «новые сверху». null — такого сообщения нет. */
    public suspend fun positionOf(peerId: String, clientMsgId: String, outgoing: Boolean): Long? = withContext(io) {
        val out = if (outgoing) 1L else 0L
        if (q.countMessage(peerId, out, clientMsgId).executeAsOne() == 0L) null
        else q.newerCount(peerId, peerId, out, clientMsgId).executeAsOne()
    }

    public fun peer(peerId: String): Flow<Peer?> =
        q.contactById(peerId) { accountId, username, firstName, lastName, identityKey, keyChanged, _ ->
            Peer(accountId, username, firstName, lastName, identityKey, keyChanged == 1L)
        }.asFlow().mapToOneOrNull(io)

    // ─────────────── Поиск и контакты ───────────────

    public suspend fun lookup(username: String): LookupResult {
        val name = username.trim().removePrefix("@").lowercase()
        if (!Limits.USERNAME.matches(name)) return LookupResult.NotFound
        if (!socket.state.value.isAuthed) return LookupResult.Offline
        val r = try {
            socket.request { Frames.lookupUsername(it, name) }
        } catch (e: NotConnectedException) {
            return LookupResult.Offline
        }
        return when (r) {
            is ServerFrame.UserInfo -> verified(r.account)?.let { LookupResult.Found(it) } ?: LookupResult.NotFound
            is ServerFrame.Error -> if (r.code == ErrorCodes.RATE_LIMITED) LookupResult.RateLimited else LookupResult.NotFound
            else -> LookupResult.NotFound
        }
    }

    /** «Написать»: закрепляем ключи собеседника (TOFU) и создаём чат. */
    public suspend fun openChat(remote: RemoteAccount): String {
        savePeer(remote, accept = false)
        withContext(io) { q.ensureChat(remote.accountId) }
        return remote.accountId
    }

    /** Пользователь сверил код безопасности / согласился с новым ключом собеседника. */
    public suspend fun acceptKeyChange(peerId: String): Boolean {
        val remote = fetchAccount(peerId) ?: return false
        savePeer(remote, accept = true)
        return true
    }

    public fun safetyNumber(peer: Peer): String = NuvaCrypto.safetyNumber(account.identity.ikPub, peer.identityKey)

    // ─────────────── Прочтение ───────────────

    /**
     * UI сообщает: входящие вплоть до [upToLocalId] сейчас реально на экране. Принимается, только если
     * приложение на переднем плане и именно этот чат открыт, — иначе «прочитано» не отправляется.
     */
    public suspend fun markRead(peerId: String, upToLocalId: Long) {
        if (!foreground.value || activeChat.value != peerId) return
        markReadInternal(peerId, upToLocalId)
    }

    /** Явное действие пользователя (кнопка «Прочитано» в уведомлении, ответ из уведомления). */
    public suspend fun markAllRead(peerId: String) {
        markReadInternal(peerId, null)
    }

    private suspend fun markReadInternal(peerId: String, upTo: Long?) {
        val queued = withContext(io) {
            db.transactionWithResult {
                val ids = if (upTo == null) q.unreadIncomingAll(peerId).executeAsList()
                else q.unreadIncomingUpTo(peerId, upTo).executeAsList()
                if (ids.isNotEmpty()) {
                    if (upTo == null) q.markIncomingReadAll(peerId) else q.markIncomingReadUpTo(peerId, upTo)
                    for (chunk in ids.chunked(CTL_CHUNK)) q.enqueueCtl(peerId, CTL_READ, idsPayload(chunk))
                }
                ids.isNotEmpty()
            }
        }
        if (queued) ctlKick.trySend(Unit)
    }

    // ─────────────── Реакции, удаление ───────────────

    /** Поставить реакцию; повтор той же — снимает. Для неотправленных сообщений не делает ничего. */
    public suspend fun react(peerId: String, msg: ChatMessage, emoji: String) {
        if (msg.outgoing && (msg.status == MsgStatus.PENDING || msg.status == MsgStatus.FAILED)) return
        val out = if (msg.outgoing) 1L else 0L
        val e = emoji.take(16)
        withContext(io) {
            db.transaction {
                val cur = q.reactionOf(peerId, out, msg.clientMsgId, 1L).executeAsOneOrNull()?.emoji
                val next = if (cur == e) "" else e
                if (next.isEmpty()) q.deleteReaction(peerId, out, msg.clientMsgId, 1L)
                else q.upsertReaction(peerId, out, msg.clientMsgId, 1L, next)
                q.enqueueCtl(peerId, CTL_REACT, JsonObject(linkedMapOf(
                    "id" to JsonPrimitive(msg.clientMsgId),
                    "own" to JsonPrimitive(msg.outgoing),
                    "emoji" to JsonPrimitive(next),
                )).toString())
            }
        }
        ctlKick.trySend(Unit)
    }

    /** «Удалить у меня»: только локально. */
    public suspend fun deleteForMe(peerId: String, msgs: List<ChatMessage>) {
        if (msgs.isEmpty()) return
        withContext(io) {
            db.transaction {
                for (m in msgs) removeMessage(peerId, m)
                refreshChatLast(peerId)
            }
        }
    }

    /** «Удалить у всех»: свои сообщения исчезают и у собеседника; чужие удаляются только у меня. */
    public suspend fun deleteForAll(peerId: String, msgs: List<ChatMessage>) {
        if (msgs.isEmpty()) return
        val remote = msgs.filter { it.outgoing && it.status != MsgStatus.PENDING && it.status != MsgStatus.FAILED }
            .map { it.clientMsgId }
        withContext(io) {
            db.transaction {
                for (m in msgs) removeMessage(peerId, m)
                for (chunk in remote.chunked(CTL_CHUNK)) q.enqueueCtl(peerId, CTL_DEL, idsPayload(chunk))
                refreshChatLast(peerId)
            }
        }
        if (remote.isNotEmpty()) ctlKick.trySend(Unit)
    }

    /** Очистить переписку на этом устройстве (у собеседника остаётся). */
    public suspend fun clearChat(peerId: String) {
        withContext(io) {
            db.transaction {
                q.deleteAllMessages(peerId)
                q.deleteAllReactions(peerId)
                q.deleteAllVoice(peerId)
                q.clearChatLast(peerId)
            }
        }
    }

    /** Внутри транзакции. */
    private fun removeMessage(peerId: String, m: ChatMessage) {
        val out = if (m.outgoing) 1L else 0L
        q.deleteMessage(peerId, out, m.clientMsgId)
        q.deleteReactionsOf(peerId, out, m.clientMsgId)
        deleteVoiceOf(peerId, out, m.clientMsgId)
    }

    /** Внутри транзакции: голосовое вместе со всеми кусками. Для текстовых ничего не делает. */
    private fun deleteVoiceOf(peerId: String, out: Long, cmid: String) {
        q.deleteVoiceParts(peerId, out, peerId, out, cmid)
        q.deleteVoice(peerId, out, cmid)
    }

    // ─────────────── Отправка ───────────────

    public suspend fun sendText(peerId: String, text: String, reply: ReplyRef? = null) {
        val body = text.trim().take(Limits.MAX_TEXT)
        if (body.isEmpty()) return
        val cmid = newMsgId()
        val ts = now()
        val snippet = reply?.text?.replace('\n', ' ')?.take(Limits.REPLY_SNIPPET).orEmpty()
        withContext(io) {
            db.transaction {
                q.ensureChat(peerId)
                q.insertMessage(
                    peerId, cmid, 1L, body, ts, null, MsgStatus.PENDING.code,
                    reply?.clientMsgId, if (reply?.mine == true) 1L else 0L, snippet, 1L, KIND_TEXT,
                )
                refreshChatLast(peerId)
            }
        }
        outboxKick.trySend(Unit)
    }

    /**
     * Голосовое: [pcm] — 16-битный моно PCM с частотой [sampleRate]. Кодируется в NVOI, режется на куски
     * и целиком ложится в БД до отправки — после этого запись уже не потеряется (обрыв, смерть процесса).
     * false — запись короче [Limits.VOICE_MIN_MS], ничего не отправлено.
     */
    public suspend fun sendVoice(peerId: String, pcm: ShortArray, sampleRate: Int, reply: ReplyRef? = null): Boolean {
        val maxSamples = sampleRate * Nvoi.MAX_SECONDS
        val clip = if (pcm.size > maxSamples) pcm.copyOf(maxSamples) else pcm
        val durationMs = clip.size.toLong() * 1000L / sampleRate
        if (durationMs < Limits.VOICE_MIN_MS) return false
        val cmid = newMsgId()
        val vid = newMsgId()
        val ts = now()
        val snippet = reply?.text?.replace('\n', ' ')?.take(Limits.REPLY_SNIPPET).orEmpty()
        withContext(io) {
            val norm = Nvoi.normalize(clip)
            val data = Nvoi.encode(norm, sampleRate)
            val wave = Nvoi.waveform(norm)
            val parts = (data.size + Limits.VOICE_PART_BYTES - 1) / Limits.VOICE_PART_BYTES
            db.transaction {
                q.ensureChat(peerId)
                q.insertMessage(
                    peerId, cmid, 1L, Limits.VOICE_LABEL, ts, null, MsgStatus.PENDING.code,
                    reply?.clientMsgId, if (reply?.mine == true) 1L else 0L, snippet, 1L, KIND_VOICE,
                )
                q.insertVoice(peerId, 1L, cmid, vid, durationMs, wave, parts.toLong())
                for (i in 0 until parts) {
                    val from = i * Limits.VOICE_PART_BYTES
                    val to = minOf(data.size, from + Limits.VOICE_PART_BYTES)
                    q.insertVoicePart(peerId, 1L, vid, i.toLong(), data.copyOfRange(from, to))
                }
                refreshChatLast(peerId)
            }
        }
        outboxKick.trySend(Unit)
        return true
    }

    /** Байты NVOI голосового; null — ещё не все куски дошли (или сообщения нет). */
    public suspend fun voiceData(peerId: String, msg: ChatMessage): ByteArray? = withContext(io) {
        val out = if (msg.outgoing) 1L else 0L
        val v = q.voiceByKey(peerId, out, msg.clientMsgId).executeAsOneOrNull() ?: return@withContext null
        val chunks = ArrayList<ByteArray>(v.parts.toInt())
        for (i in 0 until v.parts) {
            chunks += q.voicePart(peerId, out, v.vid, i).executeAsOneOrNull() ?: return@withContext null
        }
        val all = ByteArray(chunks.sumOf { it.size })
        var o = 0
        for (c in chunks) {
            c.copyInto(all, o)
            o += c.size
        }
        all
    }

    /** Входящее голосовое начали слушать: локальная отметка + «прослушано» собеседнику. */
    public suspend fun markListened(peerId: String, msg: ChatMessage) {
        val v = msg.voice ?: return
        if (msg.outgoing || v.listened) return
        withContext(io) {
            db.transaction {
                q.setVoiceListened(peerId, 0L, listOf(msg.clientMsgId))
                q.enqueueCtl(peerId, CTL_PLAYED, idsPayload(listOf(msg.clientMsgId)))
            }
        }
        ctlKick.trySend(Unit)
    }

    public suspend fun retry(peerId: String, clientMsgId: String) {
        withContext(io) {
            db.transaction {
                q.retryFailed(peerId, clientMsgId)
                // Голосовое после сбоя шлём заново целиком: набор устройств получателя мог смениться.
                q.setVoiceSentParts(0L, peerId, clientMsgId)
                refreshChatLast(peerId)
            }
        }
        outboxKick.trySend(Unit)
    }

    private suspend fun outboxLoop() {
        for (kick in outboxKick) {
            if (socket.state.value.isAuthed) drainOutbox()
        }
    }

    private suspend fun drainOutbox() {
        val done = HashSet<Long>()
        while (true) {
            val batch = withContext(io) { q.pendingOutgoing().executeAsList() }.filter { it.local_id !in done }
            if (batch.isEmpty()) return
            for (m in batch) {
                done += m.local_id
                val reply = m.reply_id?.let { ReplyRef(it, m.reply_out == 1L, m.reply_text) }
                val r = if (m.kind == KIND_VOICE) deliverVoice(m, reply)
                else deliverEncrypted(m.peer_id, m.client_msg_id, textPlaintext(m.ts, m.body, reply))
                when (r) {
                    is SendResult.Sent -> withContext(io) {
                        db.transaction {
                            q.setSent(r.serverTs, m.peer_id, m.client_msg_id)
                            refreshChatLast(m.peer_id)
                        }
                    }
                    SendResult.NotFound, is SendResult.Rejected -> withContext(io) {
                        db.transaction {
                            q.setFailed(m.peer_id, m.client_msg_id)
                            refreshChatLast(m.peer_id)
                        }
                    }
                    SendResult.RateLimited -> {
                        scope.launch { delay(10_000); outboxKick.trySend(Unit) }
                        return
                    }
                    SendResult.Offline -> return // повторим при следующем входе (state → authed)
                }
            }
        }
    }

    /**
     * Голосовое: сначала куски (каждый — отдельный конверт со своим id), затем заголовок с client_msg_id
     * сообщения. Прогресс (sent_parts) сохраняется после каждого куска: обрыв связи → досылка с места
     * остановки. Если за время отправки сменился набор устройств получателя — новые устройства не видели
     * первых кусков, поэтому начинаем сначала (получатель дедуплицирует куски по (vid, idx)).
     */
    private suspend fun deliverVoice(m: Message, reply: ReplyRef?): SendResult {
        val v = withContext(io) { q.voiceByKey(m.peer_id, 1L, m.client_msg_id).executeAsOneOrNull() }
            ?: return SendResult.Rejected("voice_missing")
        val parts = v.parts.toInt()
        var devices = deviceSet(m.peer_id)
        var restarts = 0
        var i = v.sent_parts.toInt().coerceIn(0, parts)
        while (i < parts) {
            val data = withContext(io) { q.voicePart(m.peer_id, 1L, v.vid, i.toLong()).executeAsOneOrNull() }
                ?: return SendResult.Rejected("voice_part_missing")
            val r = deliverEncrypted(m.peer_id, newMsgId(), voiceChunkPlaintext(v.vid, i, parts, data))
            if (r !is SendResult.Sent) return r
            val now = deviceSet(m.peer_id)
            if (now != devices && restarts < 2) {
                restarts++
                devices = now
                i = 0
            } else {
                i++
            }
            val sent = i.toLong()
            withContext(io) { q.setVoiceSentParts(sent, m.peer_id, m.client_msg_id) }
        }
        return deliverEncrypted(m.peer_id, m.client_msg_id, voicePlaintext(m.ts, v.vid, v.duration_ms, parts, v.wave, reply))
    }

    private suspend fun deviceSet(peerId: String): Set<String> =
        withContext(io) { q.devicesFor(peerId).executeAsList().mapTo(HashSet()) { it.device_id } }

    private sealed interface SendResult {
        class Sent(val serverTs: Long) : SendResult
        data object NotFound : SendResult
        data object RateLimited : SendResult
        data object Offline : SendResult
        class Rejected(val code: String) : SendResult
    }

    /** Шифрует под каждое активное устройство получателя; при devices_mismatch обновляет список и повторяет. */
    private suspend fun deliverEncrypted(peerId: String, cmid: String, plaintext: ByteArray): SendResult {
        var devices = withContext(io) { q.devicesFor(peerId).executeAsList() }
        if (devices.isEmpty()) devices = refreshPeer(peerId) ?: return SendResult.Offline
        repeat(2) {
            if (devices.isEmpty()) return SendResult.NotFound
            val envelopes = devices.map { d ->
                d.device_id to NuvaCrypto.seal(
                    account.identity.xkPriv, d.x25519_key, account.deviceId, d.device_id, cmid, plaintext,
                )
            }
            val r = try {
                socket.request { id -> Frames.msgSend(id, peerId, cmid, envelopes) }
            } catch (e: NotConnectedException) {
                return SendResult.Offline
            }
            when (r) {
                is ServerFrame.MsgSent -> return SendResult.Sent(r.serverTs)
                is ServerFrame.Error -> when (r.code) {
                    ErrorCodes.DEVICES_MISMATCH -> devices = refreshPeer(peerId) ?: return SendResult.Offline
                    ErrorCodes.NOT_FOUND -> return SendResult.NotFound
                    ErrorCodes.RATE_LIMITED -> return SendResult.RateLimited
                    else -> return SendResult.Rejected(r.code)
                }
                else -> return SendResult.Rejected("unexpected")
            }
        }
        return SendResult.Rejected(ErrorCodes.DEVICES_MISMATCH)
    }

    // ─────────────── Приём ───────────────

    private suspend fun processDeliveries() {
        for (d in socket.deliveries) {
            try {
                handleDeliver(d)
            } catch (e: CancellationException) {
                throw e
            } catch (e: NotConnectedException) {
                // без ack: сервер выдаст конверт повторно при следующем входе
            } catch (e: Exception) {
                acks.send(d.serverId) // «ядовитый» конверт не должен блокировать очередь вечно
            }
        }
    }

    private suspend fun handleDeliver(d: ServerFrame.Deliver) {
        val from = d.fromAccount
        val fromDevice = d.fromDevice
        if (from == null || fromDevice == null || fromDevice == account.deviceId) {
            acks.send(d.serverId)
            return
        }
        val plain = openFrom(from, fromDevice, d) ?: run {
            acks.send(d.serverId)
            return
        }
        val obj = try {
            json.parseToJsonElement(plain.decodeToString()).jsonObject
        } catch (e: Exception) {
            null
        }
        when ((obj?.get("t") as? JsonPrimitive)?.contentOrNull) {
            "text" -> {
                val body = (obj!!["body"] as? JsonPrimitive)?.contentOrNull.orEmpty().take(Limits.MAX_TEXT * 4)
                val sentTs = (obj["ts"] as? JsonPrimitive)?.longOrNull
                val ts = if (sentTs == null || sentTs <= 0 || sentTs > now() + DAY_MS) d.serverTs else sentTs
                if (body.isNotEmpty()) storeIncoming(from, d.clientMsgId, body, ts, d.serverTs, parseReply(obj))
            }
            "rcpt" -> {
                val ids = idList(obj!!)
                if (ids.isNotEmpty()) withContext(io) {
                    db.transaction {
                        q.markDelivered(from, ids)
                        refreshChatLast(from)
                    }
                }
            }
            "read" -> {
                val ids = idList(obj!!)
                if (ids.isNotEmpty()) withContext(io) {
                    db.transaction {
                        q.markReadByPeer(from, ids)
                        refreshChatLast(from)
                    }
                }
            }
            "react" -> {
                val id = (obj!!["id"] as? JsonPrimitive)?.contentOrNull
                if (!id.isNullOrEmpty() && id.length <= 64) {
                    // "own" с позиции реагирующего: его сообщение = для меня входящее (msg_out = 0).
                    val msgOut = if ((obj["own"] as? JsonPrimitive)?.booleanOrNull == true) 0L else 1L
                    val emoji = (obj["emoji"] as? JsonPrimitive)?.contentOrNull.orEmpty().take(16)
                    withContext(io) {
                        db.transaction {
                            if (q.countMessage(from, msgOut, id).executeAsOne() > 0L) {
                                if (emoji.isEmpty()) q.deleteReaction(from, msgOut, id, 0L)
                                else q.upsertReaction(from, msgOut, id, 0L, emoji)
                            }
                        }
                    }
                }
            }
            "vchunk" -> {
                val o = obj!!
                val vid = (o["vid"] as? JsonPrimitive)?.contentOrNull
                val i = (o["i"] as? JsonPrimitive)?.longOrNull
                val n = (o["n"] as? JsonPrimitive)?.longOrNull
                val data = (o["d"] as? JsonPrimitive)?.contentOrNull?.let { runCatching { B64.decode(it) }.getOrNull() }
                if (!vid.isNullOrEmpty() && vid.length <= 64 && n != null && n in 1..Limits.VOICE_MAX_PARTS.toLong() &&
                    i != null && i in 0 until n && data != null && data.isNotEmpty() && data.size <= Limits.VOICE_PART_BYTES
                ) {
                    withContext(io) { q.insertVoicePart(from, 0L, vid, i, data) }
                }
            }
            "voice" -> {
                val o = obj!!
                val vid = (o["vid"] as? JsonPrimitive)?.contentOrNull
                val n = (o["n"] as? JsonPrimitive)?.longOrNull
                val dur = (o["dur"] as? JsonPrimitive)?.longOrNull
                if (!vid.isNullOrEmpty() && vid.length <= 64 && n != null && n in 1..Limits.VOICE_MAX_PARTS.toLong() &&
                    dur != null && dur in 1..Nvoi.MAX_SECONDS * 1000L
                ) {
                    val wave = (o["wave"] as? JsonPrimitive)?.contentOrNull
                        ?.let { runCatching { B64.decode(it) }.getOrNull() }
                        ?.takeIf { it.size <= 256 } ?: ByteArray(0)
                    val sentTs = (o["ts"] as? JsonPrimitive)?.longOrNull
                    val ts = if (sentTs == null || sentTs <= 0 || sentTs > now() + DAY_MS) d.serverTs else sentTs
                    storeIncoming(from, d.clientMsgId, Limits.VOICE_LABEL, ts, d.serverTs, parseReply(o),
                        IncomingVoice(vid, dur, wave, n))
                }
            }
            "played" -> {
                val ids = idList(obj!!)
                if (ids.isNotEmpty()) withContext(io) { q.setVoiceListened(from, 1L, ids) }
            }
            "del" -> {
                // Собеседник может удалить только свои сообщения: ищем среди входящих от него.
                val ids = idList(obj!!)
                if (ids.isNotEmpty()) withContext(io) {
                    db.transaction {
                        for (id in ids) {
                            q.deleteMessage(from, 0L, id)
                            q.deleteReactionsOf(from, 0L, id)
                            deleteVoiceOf(from, 0L, id)
                        }
                        refreshChatLast(from)
                    }
                }
            }
            else -> Unit // неизвестный тип из будущей версии — молча пропускаем
        }
        acks.send(d.serverId)
    }

    private fun parseReply(obj: JsonObject): ReplyRef? = (obj["reply"] as? JsonObject)?.let { r ->
        val rid = (r["id"] as? JsonPrimitive)?.contentOrNull
        if (rid.isNullOrEmpty() || rid.length > 64) null
        else ReplyRef(
            clientMsgId = rid,
            // "own" — с позиции отправителя: цитируется его сообщение = для меня оно «чужое».
            mine = (r["own"] as? JsonPrimitive)?.booleanOrNull != true,
            text = (r["text"] as? JsonPrimitive)?.contentOrNull.orEmpty().take(Limits.REPLY_SNIPPET * 2),
        )
    }

    private class IncomingVoice(val vid: String, val durationMs: Long, val wave: ByteArray, val parts: Long)

    /** Ключи отправителя: из кэша; если устройство незнакомо или ключ сменился — свежий lookup. */
    private suspend fun openFrom(from: String, fromDevice: String, d: ServerFrame.Deliver): ByteArray? {
        suspend fun device(): Device? = withContext(io) { q.deviceById(fromDevice).executeAsOneOrNull() }
            ?.takeIf { it.account_id == from }

        fun tryOpen(dev: Device): ByteArray? = try {
            NuvaCrypto.open(account.identity.xkPriv, dev.x25519_key, fromDevice, account.deviceId, d.clientMsgId, d.envelope)
        } catch (e: CryptoException) {
            null
        }

        device()?.let { dev -> tryOpen(dev)?.let { return it } }
        refreshPeer(from) ?: throw NotConnectedException()
        return device()?.let { tryOpen(it) }
    }

    private suspend fun storeIncoming(
        from: String, cmid: String, body: String, ts: Long, serverTs: Long, reply: ReplyRef?,
        voice: IncomingVoice? = null,
    ) {
        val inserted = withContext(io) {
            db.transactionWithResult {
                q.ensureChat(from)
                if (q.countMessage(from, 0L, cmid).executeAsOne() == 0L) {
                    q.insertMessage(
                        from, cmid, 0L, body, ts, serverTs, MsgStatus.INCOMING.code,
                        reply?.clientMsgId, if (reply?.mine == true) 1L else 0L, reply?.text.orEmpty(), 0L,
                        if (voice != null) KIND_VOICE else KIND_TEXT,
                    )
                    if (voice != null) {
                        q.insertVoice(from, 0L, cmid, voice.vid, voice.durationMs, voice.wave, voice.parts)
                    }
                    // Квитанция «доставлено» кладётся в очередь в той же транзакции, что и сообщение.
                    q.enqueueCtl(from, CTL_RCPT, idsPayload(listOf(cmid)))
                    refreshChatLast(from)
                    true
                } else {
                    false
                }
            }
        }
        if (!inserted) return
        ctlKick.trySend(Unit)
        // Приложение на экране — сообщение и так видно (бейдж, чат). Уведомление нужно только в фоне.
        if (!foreground.value) {
            val c = withContext(io) { q.contactById(from).executeAsOneOrNull() }
            val title = if (c == null) "Nuva" else displayName(c.first_name, c.last_name, c.username)
            _incoming.tryEmit(IncomingNotice(from, title, if (voice != null) "🎤 $body" else body, ts))
        }
    }

    private suspend fun ackLoop() {
        val buf = ArrayList<Long>()
        while (true) {
            buf += acks.receive()
            withTimeoutOrNull(300) { while (buf.size < 100) buf += acks.receive() }
            socket.sendNoReply(Frames.msgAck(buf.toList())) // нет связи — сервер передоставит, дедуп спасёт
            buf.clear()
        }
    }

    // ─────────────── Очередь служебных сообщений ───────────────

    private suspend fun ctlLoop() {
        for (kick in ctlKick) {
            delay(250) // пачка квитанций за раз уходит одним конвертом
            if (socket.state.value.isAuthed) drainCtl()
        }
    }

    private class CtlOut(val peer: String, val plain: ByteArray, val rowIds: List<Long>)

    private suspend fun drainCtl() {
        while (socket.state.value.isAuthed) {
            val rows = withContext(io) { q.pendingCtl().executeAsList() }
            if (rows.isEmpty()) return
            val junk = ArrayList<Long>()
            val outs = buildCtlOuts(rows, junk)
            if (junk.isNotEmpty()) withContext(io) { q.deleteCtl(junk) }
            if (outs.isEmpty()) continue
            for (o in outs) {
                when (deliverEncrypted(o.peer, newMsgId(), o.plain)) {
                    // Принято, собеседника уже нет или сервер отверг конверт — строка своё отработала.
                    is SendResult.Sent, SendResult.NotFound, is SendResult.Rejected ->
                        withContext(io) { q.deleteCtl(o.rowIds) }
                    SendResult.RateLimited -> {
                        scope.launch { delay(10_000); ctlKick.trySend(Unit) }
                        return
                    }
                    SendResult.Offline -> return
                }
            }
        }
    }

    /** rcpt/read/del/played одного собеседника склеиваются в один конверт (пачками по [CTL_CHUNK]); react — по одному. */
    private fun buildCtlOuts(rows: List<Ctl>, junk: MutableList<Long>): List<CtlOut> {
        val outs = ArrayList<CtlOut>()
        val merged = LinkedHashMap<Pair<String, String>, Pair<LinkedHashSet<String>, ArrayList<Long>>>()
        for (r in rows) {
            val o = try {
                json.parseToJsonElement(r.payload).jsonObject
            } catch (e: Exception) {
                junk += r.id
                continue
            }
            when (r.kind) {
                CTL_RCPT, CTL_READ, CTL_DEL, CTL_PLAYED -> {
                    val slot = merged.getOrPut(r.peer_id to r.kind) { LinkedHashSet<String>() to ArrayList<Long>() }
                    slot.first += idList(o)
                    slot.second += r.id
                }
                CTL_REACT -> {
                    val id = (o["id"] as? JsonPrimitive)?.contentOrNull
                    if (id == null) {
                        junk += r.id
                    } else {
                        val plain = JsonObject(linkedMapOf(
                            "v" to JsonPrimitive(1), "t" to JsonPrimitive("react"), "ts" to JsonPrimitive(now()),
                            "id" to JsonPrimitive(id),
                            "own" to (o["own"] ?: JsonPrimitive(false)),
                            "emoji" to (o["emoji"] ?: JsonPrimitive("")),
                        )).toString().encodeToByteArray()
                        outs += CtlOut(r.peer_id, plain, listOf(r.id))
                    }
                }
                else -> junk += r.id
            }
        }
        for ((key, slot) in merged) {
            val (peer, kind) = key
            val ids = slot.first.toList()
            if (ids.isEmpty()) {
                junk += slot.second
                continue
            }
            val chunks = ids.chunked(CTL_CHUNK)
            chunks.forEachIndexed { i, chunk ->
                // Строки удаляем вместе с последним конвертом: до этого они остаются в очереди.
                val rowIds = if (i == chunks.lastIndex) slot.second else emptyList()
                outs += CtlOut(peer, idsPlaintext(kind, chunk), rowIds)
            }
        }
        return outs
    }

    // ─────────────── Синхронизация ключей собеседника ───────────────

    /** null — нет связи; пустой список — аккаунта больше нет. */
    private suspend fun refreshPeer(peerId: String): List<Device>? {
        val remote = try {
            fetchAccountOrThrow(peerId)
        } catch (e: NotConnectedException) {
            return null
        }
        if (remote == null) {
            withContext(io) { q.deleteDevices(peerId) }
            return emptyList()
        }
        savePeer(remote, accept = false)
        return withContext(io) { q.devicesFor(peerId).executeAsList() }
    }

    private suspend fun fetchAccount(peerId: String): RemoteAccount? = try {
        fetchAccountOrThrow(peerId)
    } catch (e: NotConnectedException) {
        null
    }

    private suspend fun fetchAccountOrThrow(peerId: String): RemoteAccount? =
        when (val r = socket.request { Frames.lookupAccount(it, peerId) }) {
            is ServerFrame.UserInfo -> verified(r.account)
            is ServerFrame.Error -> if (r.code == ErrorCodes.NOT_FOUND) null else throw NotConnectedException(r.code)
            else -> throw NotConnectedException("unexpected")
        }

    /** Оставляем только устройства с валидной подписью X25519-ключа их identity-ключом. */
    private fun verified(a: RemoteAccount): RemoteAccount? {
        val ok = a.devices.filter { d ->
            d.identityKey.size == 32 && d.x25519Key.size == 32 &&
                NuvaCrypto.verify(d.identityKey, NuvaCrypto.xkPayload(d.x25519Key), d.x25519Sig)
        }
        if (ok.isEmpty() || !Uuids.isValid(a.accountId) || ok.any { !Uuids.isValid(it.deviceId) }) return null
        return RemoteAccount(a.accountId, a.username, a.firstName, a.lastName, ok)
    }

    private suspend fun savePeer(remote: RemoteAccount, accept: Boolean) {
        val primary = remote.devices.first().identityKey
        withContext(io) {
            db.transaction {
                val existing = q.contactById(remote.accountId).executeAsOneOrNull()
                val changed = !accept && existing != null &&
                    (existing.key_changed == 1L || !existing.identity_key.contentEquals(primary))
                val pinned = if (existing == null || accept) primary else existing.identity_key
                q.upsertContact(remote.accountId, remote.username, remote.firstName, remote.lastName,
                    pinned, if (changed) 1L else 0L, now())
                q.deleteDevices(remote.accountId)
                for (d in remote.devices) q.insertDevice(d.deviceId, remote.accountId, d.identityKey, d.x25519Key)
            }
        }
    }

    // ─────────────── helpers ───────────────

    /** Вызывать внутри транзакции. Сообщений не осталось — текст в списке чатов очищается. */
    private fun refreshChatLast(peerId: String) {
        val m = q.lastMessage(peerId).executeAsOneOrNull()
        if (m == null) {
            q.clearChatLast(peerId)
            return
        }
        q.setChatLast(m.body, m.ts, m.outgoing, m.status, peerId)
    }

    private fun textPlaintext(ts: Long, body: String, reply: ReplyRef?): ByteArray {
        val m = linkedMapOf<String, kotlinx.serialization.json.JsonElement>(
            "v" to JsonPrimitive(1), "t" to JsonPrimitive("text"), "ts" to JsonPrimitive(ts), "body" to JsonPrimitive(body),
        )
        if (reply != null) {
            m["reply"] = JsonObject(linkedMapOf(
                "id" to JsonPrimitive(reply.clientMsgId),
                "own" to JsonPrimitive(reply.mine), // с позиции отправителя = меня
                "text" to JsonPrimitive(reply.text),
            ))
        }
        return JsonObject(m).toString().encodeToByteArray()
    }

    private fun voiceChunkPlaintext(vid: String, i: Int, n: Int, data: ByteArray): ByteArray = JsonObject(linkedMapOf(
        "v" to JsonPrimitive(1), "t" to JsonPrimitive("vchunk"), "vid" to JsonPrimitive(vid),
        "i" to JsonPrimitive(i), "n" to JsonPrimitive(n), "d" to JsonPrimitive(B64.encode(data)),
    )).toString().encodeToByteArray()

    private fun voicePlaintext(
        ts: Long, vid: String, durationMs: Long, parts: Int, wave: ByteArray, reply: ReplyRef?,
    ): ByteArray {
        val m = linkedMapOf<String, kotlinx.serialization.json.JsonElement>(
            "v" to JsonPrimitive(1), "t" to JsonPrimitive("voice"), "ts" to JsonPrimitive(ts),
            "vid" to JsonPrimitive(vid), "dur" to JsonPrimitive(durationMs), "n" to JsonPrimitive(parts),
            "wave" to JsonPrimitive(B64.encode(wave)),
        )
        if (reply != null) {
            m["reply"] = JsonObject(linkedMapOf(
                "id" to JsonPrimitive(reply.clientMsgId),
                "own" to JsonPrimitive(reply.mine),
                "text" to JsonPrimitive(reply.text),
            ))
        }
        return JsonObject(m).toString().encodeToByteArray()
    }

    private fun idsPlaintext(kind: String, ids: List<String>): ByteArray = JsonObject(linkedMapOf(
        "v" to JsonPrimitive(1), "t" to JsonPrimitive(kind), "ts" to JsonPrimitive(now()),
        "ids" to JsonArray(ids.map { JsonPrimitive(it) }),
    )).toString().encodeToByteArray()

    private fun idsPayload(ids: List<String>): String =
        JsonObject(linkedMapOf("ids" to JsonArray(ids.map { JsonPrimitive(it) }))).toString()

    private fun idList(o: JsonObject): List<String> = (o["ids"] as? JsonArray).orEmpty()
        .mapNotNull { (it as? JsonPrimitive)?.contentOrNull }.filter { it.length <= 64 }.take(500)

    private fun newMsgId(): String = Uuids.v7(now(), NuvaCrypto.random(10))

    private fun now(): Long = Clock.System.now().toEpochMilliseconds()

    private companion object {
        const val DAY_MS = 86_400_000L
        const val CTL_CHUNK = 200
        const val CTL_RCPT = "rcpt"
        const val CTL_READ = "read"
        const val CTL_REACT = "react"
        const val CTL_DEL = "del"
        const val CTL_PLAYED = "played"
        const val KIND_TEXT = 0L
        const val KIND_VOICE = 1L
    }
}
