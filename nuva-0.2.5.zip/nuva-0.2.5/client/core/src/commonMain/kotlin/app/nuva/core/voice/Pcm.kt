package app.nuva.core.voice

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/** Утилиты 16-битного моно PCM: индикатор громкости и ресэмплинг к частоте NVOI. */
public object Pcm {
    private const val ZERO_CROSSINGS = 16   // полуширина ядра в нулях sinc
    private const val OVERSAMPLE = 256      // точек таблицы ядра на один входной отсчёт
    private const val PASS = 0.9            // срез = 0.9 от Найквиста меньшей частоты

    /**
     * Громкость фрагмента для индикатора записи, 0..1: пик в dBFS, окно −50…0 dB.
     * Линейная шкала «мёртвая» на тихой речи, логарифм даёт живую пульсацию.
     */
    public fun level(buf: ShortArray, n: Int = buf.size): Float {
        var peak = 0
        for (i in 0 until min(n, buf.size)) {
            val a = abs(buf[i].toInt())
            if (a > peak) peak = a
        }
        if (peak == 0) return 0f
        val db = 20.0 * log10(peak / 32768.0)
        return ((db + 50.0) / 50.0).coerceIn(0.0, 1.0).toFloat()
    }

    /**
     * Ресэмплинг [from] → [to] Гц оконным sinc (Блэкман, 16 нулей). Срез 0.9·Найквиста целевой частоты:
     * 48→16 кГц — полоса до 6 кГц ровная (0 dB), выше 9 кГц подавление ≥ 75 dB. Веса нормируются,
     * так что постоянная составляющая и края записи не «проседают».
     */
    public fun resample(pcm: ShortArray, from: Int, to: Int): ShortArray {
        require(from > 0 && to > 0) { "bad rate" }
        if (from == to || pcm.isEmpty()) return pcm
        val c = min(1.0, to.toDouble() / from) * PASS
        val half = ceil(ZERO_CROSSINGS / c).toInt()
        val tab = DoubleArray(half * OVERSAMPLE + 1) { i ->
            val t = i.toDouble() / OVERSAMPLE
            val u = c * t
            val sinc = if (u == 0.0) 1.0 else sin(PI * u) / (PI * u)
            val w = t / half
            val win = if (w < 1.0) 0.42 + 0.5 * cos(PI * w) + 0.08 * cos(2 * PI * w) else 0.0
            c * sinc * win
        }
        val outN = (pcm.size.toLong() * to / from).toInt()
        val out = ShortArray(outN)
        val step = from.toDouble() / to
        val last = tab.size - 1
        for (i in 0 until outN) {
            val pos = i * step
            val lo = max(0, ceil(pos - half).toInt())
            val hi = min(pcm.size - 1, floor(pos + half).toInt())
            var acc = 0.0
            var ws = 0.0
            for (k in lo..hi) {
                val d = abs(k - pos) * OVERSAMPLE
                val j = d.toInt()
                if (j >= last) continue
                val h = tab[j] + (tab[j + 1] - tab[j]) * (d - j)
                acc += pcm[k] * h
                ws += h
            }
            val v = if (ws != 0.0) acc / ws else 0.0
            out[i] = v.roundToInt().coerceIn(-32768, 32767).toShort()
        }
        return out
    }
}
