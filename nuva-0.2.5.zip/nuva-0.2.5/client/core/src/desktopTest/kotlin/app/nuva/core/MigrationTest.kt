package app.nuva.core

import app.cash.sqldelight.driver.jdbc.sqlite.JdbcSqliteDriver
import app.nuva.db.NuvaDatabase
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

/** Пользователи 0.2.3 (схема v1) и 0.2.4 (v2) должны обновиться без потери переписки и непрочитанных. */
class MigrationTest {
    private val v1 = listOf(
        """CREATE TABLE chat (
            peer_id TEXT NOT NULL PRIMARY KEY,
            last_text TEXT NOT NULL DEFAULT '',
            last_ts INTEGER NOT NULL DEFAULT 0,
            last_outgoing INTEGER NOT NULL DEFAULT 0,
            last_status INTEGER NOT NULL DEFAULT 0,
            unread INTEGER NOT NULL DEFAULT 0
        )""",
        """CREATE TABLE message (
            local_id INTEGER PRIMARY KEY AUTOINCREMENT,
            peer_id TEXT NOT NULL,
            client_msg_id TEXT NOT NULL,
            outgoing INTEGER NOT NULL,
            body TEXT NOT NULL,
            ts INTEGER NOT NULL,
            server_ts INTEGER,
            status INTEGER NOT NULL
        )""",
    )

    @Test
    fun migratesV1KeepingMessagesAndUnread() {
        val driver = JdbcSqliteDriver(JdbcSqliteDriver.IN_MEMORY)
        for (sql in v1) driver.execute(null, sql, 0)
        driver.execute(null, "INSERT INTO chat(peer_id, last_text, last_ts, unread) VALUES ('p', 'x', 1, 2)", 0)
        for (i in 0 until 4) {
            driver.execute(null, "INSERT INTO message(peer_id, client_msg_id, outgoing, body, ts, status) VALUES ('p', 'in$i', 0, 'b', $i, 10)", 0)
        }
        driver.execute(null, "INSERT INTO message(peer_id, client_msg_id, outgoing, body, ts, status) VALUES ('p', 'out', 1, 'b', 9, 1)", 0)

        NuvaDatabase.Schema.migrate(driver, 1, NuvaDatabase.Schema.version)

        val q = NuvaDatabase(driver).nuvaQueries
        assertEquals(3L, NuvaDatabase.Schema.version)
        // chat.unread = 2 → непрочитанными остаются два самых новых входящих.
        assertEquals(listOf("in2", "in3"), q.unreadIncomingAll("p").executeAsList())
        val rows = q.messagesFor("p", 100).executeAsList()
        assertEquals(5, rows.size)
        // Старые сообщения после миграции — текстовые, без голосовых данных.
        assertTrue(rows.all { it.kind == 0L && it.vid == null && it.have_parts == 0L })
    }

    @Test
    fun voiceRowsJoinWithPartsCount() {
        val driver = JdbcSqliteDriver(JdbcSqliteDriver.IN_MEMORY)
        NuvaDatabase.Schema.create(driver)
        val q = NuvaDatabase(driver).nuvaQueries
        q.ensureChat("p")
        q.insertMessage("p", "m1", 0L, "Голосовое сообщение", 1L, 1L, 10L, null, 0L, "", 0L, 1L)
        q.insertVoice("p", 0L, "m1", "v1", 3000L, ByteArray(64), 3L)
        // Кусок другого направления с тем же vid не должен засчитываться.
        q.insertVoicePart("p", 1L, "v1", 0L, byteArrayOf(9))
        q.insertVoicePart("p", 0L, "v1", 0L, byteArrayOf(1))
        q.insertVoicePart("p", 0L, "v1", 2L, byteArrayOf(3))
        q.insertVoicePart("p", 0L, "v1", 2L, byteArrayOf(3)) // повторная доставка — игнор
        var row = q.messagesFor("p", 10).executeAsList().single()
        assertEquals("v1", row.vid)
        assertEquals(3L, row.parts)
        assertEquals(2L, row.have_parts)
        q.insertVoicePart("p", 0L, "v1", 1L, byteArrayOf(2))
        row = q.messagesFor("p", 10).executeAsList().single()
        assertEquals(3L, row.have_parts)

        q.deleteVoiceParts("p", 0L, "p", 0L, "m1")
        q.deleteVoice("p", 0L, "m1")
        assertEquals(0L, q.voicePartCount("p", 0L, "v1").executeAsOne())
        assertEquals(1L, q.voicePartCount("p", 1L, "v1").executeAsOne())
    }
}
