package app.nuva.ui.chat

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.nuva.core.chat.ChatMessage
import app.nuva.core.chat.MsgStatus
import app.nuva.core.chat.ReplyRef
import app.nuva.ui.components.StatusTicks
import app.nuva.ui.components.timeHm
import app.nuva.ui.voice.VoicePlayback
import kotlinx.coroutines.launch
import kotlin.math.exp
import kotlin.math.roundToInt

// ───────────────────────── Геометрия пузыря (снята с ролика) ─────────────────────────

private const val BIG_RADIUS_DP = 16f      // внешние углы
private const val SMALL_RADIUS_DP = 6f     // углы внутри группы
private const val TAIL_W_DP = 6f
private const val TAIL_H_DP = 7f

/**
 * Пузырь: большие углы 16dp, на стороне автора внутри группы — 6dp. У последнего в группе сторона автора
 * заканчивается хвостиком 6×7dp (он выступает за габариты пузыря на 6dp, поэтому рисуем без clip).
 */
private fun bubblePath(w: Float, h: Float, out: Boolean, groupStart: Boolean, groupEnd: Boolean, dp: Float): Path {
    val big = BIG_RADIUS_DP * dp
    val small = SMALL_RADIUS_DP * dp
    val edgeTop = if (groupStart) big else small
    val edgeBottom = if (groupEnd) 0f else small // у хвоста угол прямой: хвост пристыкован к нему
    val tl: Float
    val tr: Float
    val br: Float
    val bl: Float
    if (out) {
        tl = big; tr = edgeTop; br = edgeBottom; bl = big
    } else {
        tl = edgeTop; tr = big; br = big; bl = edgeBottom
    }
    val body = Path().apply {
        addRoundRect(
            RoundRect(
                left = 0f, top = 0f, right = w, bottom = h,
                topLeftCornerRadius = CornerRadius(tl),
                topRightCornerRadius = CornerRadius(tr),
                bottomRightCornerRadius = CornerRadius(br),
                bottomLeftCornerRadius = CornerRadius(bl),
            ),
        )
    }
    if (!groupEnd) return body
    val tw = TAIL_W_DP * dp
    val th = TAIL_H_DP * dp
    val tail = Path().apply {
        if (out) {
            moveTo(w, h - th)
            cubicTo(w, h - th * 0.4f, w + tw * 0.3f, h, w + tw, h)
            lineTo(w, h)
        } else {
            moveTo(0f, h - th)
            cubicTo(0f, h - th * 0.4f, -tw * 0.3f, h, -tw, h)
            lineTo(0f, h)
        }
        close()
    }
    return Path.combine(PathOperation.Union, body, tail)
}

/** Фон пузыря. Исходящие закрашиваются общим градиентом экрана; входящие — #201E22. */
@Composable
private fun Modifier.bubbleBackground(out: Boolean, groupStart: Boolean, groupEnd: Boolean): Modifier {
    val host = LocalGradientHost.current
    var pos by remember { mutableStateOf(Offset.Zero) }
    return this
        .onGloballyPositioned { pos = it.positionInRoot() }
        .drawWithCache {
            val path = bubblePath(size.width, size.height, out, groupStart, groupEnd, density)
            onDrawBehind {
                if (out && host.size.width > 0f) {
                    // Начало координат чата относительно этого пузыря.
                    val brush = ChatColors.outgoingBrush(
                        hostOrigin = Offset(host.origin.x - pos.x, host.origin.y - pos.y),
                        host = host.size,
                    )
                    drawPath(path, brush)
                } else {
                    drawPath(path, if (out) ChatColors.Accent else ChatColors.Incoming)
                }
            }
        }
}

// ───────────────────────── Строка сообщения ─────────────────────────

private const val SWIPE_ARROW_FROM_DP = 30f   // с этого сдвига проявляется стрелка
private const val SWIPE_TRIGGER_DP = 60f      // порог: круг, отскок, вибрация
private const val SWIPE_MAX_DP = 85f          // дальше — не тянется

/** Сдвиг пузыря по пальцу: до порога 1:1, дальше туго и не более [SWIPE_MAX_DP]. */
private fun swipeOffsetDp(rawDp: Float): Float =
    if (rawDp <= SWIPE_TRIGGER_DP) rawDp
    else SWIPE_TRIGGER_DP + (SWIPE_MAX_DP - SWIPE_TRIGGER_DP) * (1f - exp(-(rawDp - SWIPE_TRIGGER_DP) / 40f))

/**
 * Одна строка списка. Фон-полоса на всю ширину — подсветка цитаты/выделение. Свайп влево — ответ:
 * стрелка проявляется с 30dp, на 60dp появляется круг 30dp, стрелка подпрыгивает, срабатывает вибрация;
 * после отпускания пузырь возвращается за ~130мс. Тап — мини-блок, долгий тап — выделение.
 */
@Composable
internal fun MessageRow(
    msg: ChatMessage,
    groupStart: Boolean,
    groupEnd: Boolean,
    peerTitle: String,
    maxBubble: Dp,
    selected: Boolean,
    selectionMode: Boolean,
    /** Огибающая подсветки 0..1; читается при отрисовке, поэтому анимация не перекомпоновывает строку. */
    highlight: () -> Float,
    playback: VoicePlayback,
    onTap: (anchorInHost: Offset) -> Unit,
    onLongPress: () -> Unit,
    onSwipeReply: () -> Unit,
    onQuoteClick: (ReplyRef) -> Unit,
    onReactionClick: (String) -> Unit,
    onRetry: () -> Unit,
) {
    val out = msg.outgoing
    val density = LocalDensity.current
    val dp = density.density
    val host = LocalGradientHost.current
    val haptic = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()

    var offPx by remember { mutableFloatStateOf(0f) }
    var armed by remember { mutableStateOf(false) }
    var bubbleCoords by remember { mutableStateOf<LayoutCoordinates?>(null) }

    Box(
        Modifier
            .fillMaxWidth()
            .drawBehind {
                if (selected) {
                    drawRect(ChatColors.SelectionBand)
                } else {
                    // Подсветка после перехода к цитате: полоса цвета бренда, максимум 0.2 —
                    // заметно, но без «засвета» (в 0.2.4 полоса доходила до непрозрачной).
                    val h = highlight()
                    if (h > 0.001f) drawRect(ChatColors.Highlight.copy(alpha = 0.2f * h))
                }
            }
            .then(
                if (selectionMode) Modifier.pointerInput(msg.localId) {
                    detectTapGestures(onTap = { onTap(Offset.Zero) })
                } else Modifier,
            )
            .pointerInput(msg.localId, selectionMode) {
                if (selectionMode) return@pointerInput
                var raw = 0f
                detectHorizontalDragGestures(
                    onDragStart = { raw = 0f; armed = false },
                    onDragEnd = {
                        val fire = armed
                        armed = false
                        val from = offPx
                        scope.launch {
                            Animatable(from).animateTo(0f, tween(130, easing = FastOutSlowInEasing)) { offPx = value }
                        }
                        if (fire) onSwipeReply()
                    },
                    onDragCancel = {
                        armed = false
                        val from = offPx
                        scope.launch {
                            Animatable(from).animateTo(0f, tween(130, easing = FastOutSlowInEasing)) { offPx = value }
                        }
                    },
                    onHorizontalDrag = { change, dragAmount ->
                        change.consume()
                        raw = (raw - dragAmount).coerceAtLeast(0f)
                        val rawDp = raw / dp
                        offPx = swipeOffsetDp(rawDp) * dp
                        val nowArmed = rawDp >= SWIPE_TRIGGER_DP
                        if (nowArmed && !armed) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        armed = nowArmed
                    },
                )
            },
    ) {
        SwipeReplyIndicator(offDp = offPx / dp, armed = armed, modifier = Modifier.align(Alignment.CenterEnd))

        Row(
            Modifier
                .fillMaxWidth()
                .padding(top = if (groupStart) 6.dp else 2.dp, start = 11.5.dp, end = 11.5.dp)
                .offset { IntOffset(-offPx.roundToInt(), 0) },
            horizontalArrangement = if (out) Arrangement.End else Arrangement.Start,
        ) {
            Column(horizontalAlignment = if (out) Alignment.End else Alignment.Start) {
                Box(
                    Modifier
                        .widthIn(max = maxBubble)
                        .graphicsLayer {
                            // Пузырь чуть «вдыхает» вместе с подсветкой (до +3%), от своей стороны экрана.
                            val s = 1f + 0.03f * highlight()
                            scaleX = s
                            scaleY = s
                            transformOrigin = TransformOrigin(if (out) 1f else 0f, 0.5f)
                        }
                        .onGloballyPositioned { bubbleCoords = it }
                        .bubbleBackground(out, groupStart, groupEnd)
                        .pointerInput(msg.localId, selectionMode) {
                            detectTapGestures(
                                onTap = { local ->
                                    if (selectionMode) onTap(Offset.Zero)
                                    else {
                                        val root = bubbleCoords?.localToRoot(local) ?: local
                                        onTap(Offset(root.x - host.origin.x, root.y - host.origin.y))
                                    }
                                },
                                onLongPress = { onLongPress() },
                            )
                        }
                        .padding(start = 10.dp, end = 8.dp, top = 5.dp, bottom = 5.dp),
                ) {
                    BubbleContent(msg, peerTitle, playback, maxBubble - 18.dp, onQuoteClick, onReactionClick)
                }
                if (msg.status == MsgStatus.FAILED) {
                    Text(
                        "Не отправлено · повторить",
                        Modifier.clickable(onClick = onRetry).padding(top = 2.dp, bottom = 2.dp),
                        fontSize = 12.sp,
                        color = Color(0xFFFF6B6B),
                    )
                }
            }
        }
    }
}

@Composable
private fun BubbleContent(
    msg: ChatMessage,
    peerTitle: String,
    playback: VoicePlayback,
    maxContent: Dp,
    onQuoteClick: (ReplyRef) -> Unit,
    onReactionClick: (String) -> Unit,
) {
    val out = msg.outgoing
    // Место под время и галочки в последней строке: время 12sp + зазор + галочки 18dp.
    val reserve = if (out) "\u2003\u2003\u2003\u2002" else "\u2003\u2003\u2002"
    Column(Modifier.width(IntrinsicSize.Max)) {
        msg.reply?.let { QuoteBlock(it, peerTitle, out) { onQuoteClick(it) } }
        if (msg.voice != null) {
            VoiceContent(msg, playback, maxContent)
            Reactions(msg, onReactionClick)
            return@Column
        }
        Box {
            Text(
                msg.body + reserve,
                fontSize = 16.sp,
                lineHeight = 22.sp,
                color = Color.White,
            )
            Row(
                Modifier.align(Alignment.BottomEnd),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    timeHm(msg.ts),
                    fontSize = 12.sp,
                    color = Color.White.copy(alpha = if (out) 0.7f else 0.5f),
                )
                if (out) {
                    Spacer(Modifier.width(3.dp))
                    StatusTicks(msg.status, Color.White.copy(alpha = 0.85f))
                }
            }
        }
        Reactions(msg, onReactionClick)
    }
}

/** Цитата: заливка белым 0.1, слева полоска 3dp «зеброй». */
@Composable
private fun QuoteBlock(reply: ReplyRef, peerTitle: String, out: Boolean, onClick: () -> Unit) {
    val name = if (reply.mine) "Вы" else peerTitle
    val tint = if (out) Color.White else ChatColors.Accent
    // Без ripple: белая волна по цитате и давала «засвет» при нажатии. Отклик — чуть плотнее заливка.
    val press = remember { MutableInteractionSource() }
    val pressed by press.collectIsPressedAsState()
    val fill by animateFloatAsState(if (pressed) 0.18f else 0.1f, tween(90), label = "quotePress")
    Row(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 4.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(Color.White.copy(alpha = fill))
            .clickable(interactionSource = press, indication = null, onClick = onClick)
            .height(IntrinsicSize.Min),
    ) {
        Zebra(Modifier.width(3.dp).fillMaxHeight(), tint)
        Column(Modifier.padding(start = 8.dp, end = 8.dp, top = 3.dp, bottom = 3.dp)) {
            Text(name, fontSize = 14.sp, lineHeight = 18.sp, fontWeight = FontWeight.SemiBold, color = tint, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                reply.text.ifEmpty { "Сообщение" },
                fontSize = 14.sp,
                lineHeight = 18.sp,
                color = Color.White.copy(alpha = 0.9f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

@Composable
private fun Zebra(modifier: Modifier, color: Color) {
    Canvas(modifier) {
        val seg = 7.dp.toPx()
        var y = 0f
        var odd = false
        while (y < size.height) {
            drawRect(
                color = if (odd) color.copy(alpha = 0.35f) else color,
                topLeft = Offset(0f, y),
                size = Size(size.width, minOf(seg, size.height - y)),
            )
            y += seg
            odd = !odd
        }
    }
}

/** Реакции: моя и собеседника; одинаковые склеиваются со счётчиком. */
@Composable
private fun Reactions(msg: ChatMessage, onClick: (String) -> Unit) {
    val mine = msg.myReaction
    val theirs = msg.theirReaction
    if (mine == null && theirs == null) return
    val items = buildList {
        if (mine != null && mine == theirs) add(Triple(mine, 2, true))
        else {
            if (mine != null) add(Triple(mine, 1, true))
            if (theirs != null) add(Triple(theirs, 1, false))
        }
    }
    Row(Modifier.padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        for ((emoji, count, isMine) in items) {
            Row(
                Modifier
                    .height(22.dp)
                    .clip(CircleShape)
                    .background(if (isMine) Color.White.copy(alpha = 0.28f) else Color.White.copy(alpha = 0.14f))
                    .clickable { onClick(emoji) }
                    .padding(horizontal = 7.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(emoji, fontSize = 13.sp)
                if (count > 1) {
                    Spacer(Modifier.width(3.dp))
                    Text(count.toString(), fontSize = 12.sp, color = Color.White, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

/**
 * Стрелка ответа за краем пузыря. Её положение неподвижно: центр в 22dp от правого края. Проявляется
 * с 30dp сдвига; на пороге появляется круг 30dp, и стрелка «подпрыгивает».
 */
@Composable
private fun SwipeReplyIndicator(offDp: Float, armed: Boolean, modifier: Modifier) {
    val alpha = ((offDp - SWIPE_ARROW_FROM_DP) / (SWIPE_TRIGGER_DP - SWIPE_ARROW_FROM_DP)).coerceIn(0f, 1f)
    val pop by animateFloatAsState(
        targetValue = if (armed) 1f else 0f,
        animationSpec = spring(dampingRatio = 0.45f, stiffness = Spring.StiffnessMedium),
        label = "swipePop",
    )
    if (alpha <= 0f && pop <= 0.01f) return
    Box(
        modifier.padding(end = 7.dp).size(30.dp),
        contentAlignment = Alignment.Center,
    ) {
        Box(
            Modifier
                .size(30.dp)
                .scale(pop)
                .background(Color.White.copy(alpha = 0.16f), CircleShape),
        )
        ReplyIcon(
            Color.White.copy(alpha = alpha),
            size = 18.dp,
            modifier = Modifier.graphicsLayer {
                val s = 0.8f + 0.35f * pop
                scaleX = s
                scaleY = s
            },
        )
    }
}
