package app.nuva.ui.chat

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.isShiftPressed
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.nuva.core.chat.Limits
import app.nuva.core.chat.ReplyRef
import app.nuva.core.voice.Nvoi
import app.nuva.ui.voice.VoiceAudio
import app.nuva.ui.voice.VoiceRecorder
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Что мы цитируем в поле ввода. */
class ReplyDraft(val ref: ReplyRef, val authorName: String)

// ── Геометрия записи (референс): круг 67dp поверх кнопки 36dp, замок 40dp над кругом.
private val BTN = 36.dp
private val BTN_INSET = 2.5.dp          // кнопка от правого/нижнего края плашки
private val FIELD_MARGIN = 7.dp         // плашка от краёв экрана
private val BIG = 67.dp
private val LOCK_W = 40.dp
private val LOCK_H = 76.dp
private val CANCEL_DRAG = 120.dp        // влево — отмена
private val LOCK_DRAG = 90.dp           // вверх — фиксация
private const val TAP_MS = 300L         // короче — это тап, а не запись: показываем подсказку

private enum class RecPhase { Idle, Holding, Locked }

@Stable
private class RecUi {
    var phase by mutableStateOf(RecPhase.Idle)
    /** Смещение пальца от точки нажатия, px, ≤ 0. Работает только одна ось — как в референсе. */
    var dx by mutableFloatStateOf(0f)
    var dy by mutableFloatStateOf(0f)
    /** Сглаженная громкость 0..1. */
    var level by mutableFloatStateOf(0f)
    var ms by mutableLongStateOf(0L)
    var paused by mutableStateOf(false)
    var recorder: VoiceRecorder? = null
}

private fun recTimer(ms: Long): String {
    val s = ms / 1000
    return "${s / 60}:${(s % 60).toString().padStart(2, '0')},${(ms / 100) % 10}"
}

/**
 * Поле ввода без внешнего контейнера: плашка 41dp, отступы 7dp, сверху и снизу — затемнение.
 *
 * Ответ: панель «В ответ …» выезжает НАД строкой ввода (expandVertically от нижнего края, 200мс,
 * FastOutSlowIn), строка ввода при этом стоит на месте. В 0.2.4 был animateContentSize: панель
 * появлялась сразу во всю высоту, а плашка догоняла её — строку ввода на кадр-другой выталкивало вниз.
 *
 * Голосовое (если [audio] не null и поле пустое): удерживать микрофон — запись, влево — отмена,
 * вверх — фиксация, отпустить — отправить.
 */
@Composable
internal fun Composer(
    reply: ReplyDraft?,
    onCancelReply: () -> Unit,
    onSend: (String) -> Unit,
    audio: VoiceAudio?,
    onVoiceStart: () -> Unit,
    onVoice: (ShortArray) -> Unit,
    modifier: Modifier = Modifier,
) {
    var text by rememberSaveable { mutableStateOf("") }
    val focus = remember { FocusRequester() }
    val canSend = text.isNotBlank()
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    val rec = remember { RecUi() }
    val recording = rec.phase != RecPhase.Idle
    var tip by remember { mutableStateOf<String?>(null) }
    val onVoiceNow by rememberUpdatedState(onVoice)
    val onVoiceStartNow by rememberUpdatedState(onVoiceStart)

    // Последний непустой ответ: нужен, чтобы панель доиграла анимацию закрытия со своим текстом.
    val lastReply = remember { arrayOfNulls<ReplyDraft>(1) }
    if (reply != null) lastReply[0] = reply

    LaunchedEffect(reply?.ref?.clientMsgId, reply?.ref?.mine) {
        if (reply != null) runCatching { focus.requestFocus() }
    }
    LaunchedEffect(tip) {
        if (tip != null) {
            delay(1600)
            tip = null
        }
    }

    val radius by animateDpAsState(
        if (reply != null) 16.dp else 20.5.dp,
        tween(200, easing = FastOutSlowInEasing),
        label = "composerRadius",
    )

    fun send() {
        val t = text.trim()
        if (t.isEmpty()) return
        onSend(t)
        text = ""
    }

    fun recStart(): Boolean {
        val a = audio ?: return false
        val r = a.recorder()
        if (!r.start()) {
            tip = "Микрофон недоступен"
            return false
        }
        onVoiceStartNow()
        rec.recorder = r
        rec.dx = 0f
        rec.dy = 0f
        rec.level = 0f
        rec.ms = 0L
        rec.paused = false
        rec.phase = RecPhase.Holding
        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        return true
    }

    fun recFinish(sendIt: Boolean) {
        val r = rec.recorder ?: return
        rec.recorder = null
        rec.phase = RecPhase.Idle
        rec.dx = 0f
        rec.dy = 0f
        if (!sendIt) {
            r.cancel()
            return
        }
        // stop() дожидается потока захвата и, если нужно, ресэмплит — не на главном потоке.
        scope.launch {
            val pcm = withContext(Dispatchers.Default) { r.stop() }
            onVoiceNow(pcm)
        }
    }

    // Кадровый тикер записи: таймер, громкость (быстрая атака, медленный спад), лимит длины.
    LaunchedEffect(recording) {
        if (!recording) return@LaunchedEffect
        while (true) {
            withFrameNanos { }
            val r = rec.recorder ?: break
            rec.ms = r.durationMs
            val target = if (rec.paused) 0f else r.level
            rec.level += (target - rec.level) * (if (target > rec.level) 0.5f else 0.15f)
            if (rec.ms >= Nvoi.MAX_SECONDS * 1000L) {
                recFinish(true)
                break
            }
        }
    }
    // Ушли с экрана посреди записи — запись выбрасываем, микрофон освобождаем.
    DisposableEffect(Unit) { onDispose { rec.recorder?.cancel(); rec.recorder = null } }

    val density = LocalDensity.current
    val cancelPx = with(density) { CANCEL_DRAG.toPx() }
    val lockPx = with(density) { LOCK_DRAG.toPx() }

    val micGesture = Modifier.pointerInput(audio) {
        val a = audio ?: return@pointerInput
        awaitEachGesture {
            val down = awaitFirstDown()
            down.consume()
            if (!a.micAllowed()) {
                a.requestMic { ok -> if (ok) tip = "Удерживайте, чтобы записать" }
                waitForUpOrCancellation()
                return@awaitEachGesture
            }
            if (!recStart()) {
                waitForUpOrCancellation()
                return@awaitEachGesture
            }
            var outcome = RecPhase.Idle // Idle — отпустили; Holding — отмена; Locked — зафиксировали
            var upAt = down.uptimeMillis
            try {
                while (true) {
                    val ev = awaitPointerEvent()
                    val ch = ev.changes.firstOrNull { it.id == down.id }
                    if (ch == null) {
                        outcome = RecPhase.Holding
                        break
                    }
                    upAt = ch.uptimeMillis
                    ch.consume()
                    if (!ch.pressed) break
                    val d = ch.position - down.position
                    val left = (-d.x).coerceAtLeast(0f)
                    val up = (-d.y).coerceAtLeast(0f)
                    if (left >= up) {
                        rec.dx = -left
                        rec.dy = 0f
                    } else {
                        rec.dy = -up
                        rec.dx = 0f
                    }
                    if (left >= cancelPx) {
                        outcome = RecPhase.Holding
                        break
                    }
                    if (up >= lockPx) {
                        outcome = RecPhase.Locked
                        break
                    }
                }
            } catch (e: CancellationException) {
                if (rec.phase == RecPhase.Holding) recFinish(false)
                throw e
            }
            when (outcome) {
                RecPhase.Holding -> {
                    recFinish(false)
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                }
                RecPhase.Locked -> {
                    rec.dx = 0f
                    rec.dy = 0f
                    rec.phase = RecPhase.Locked
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    waitForUpOrCancellation()
                }
                RecPhase.Idle -> {
                    val recorded = rec.recorder?.durationMs ?: 0L
                    when {
                        upAt - down.uptimeMillis < TAP_MS -> {
                            recFinish(false)
                            tip = "Удерживайте, чтобы записать"
                        }
                        recorded < Limits.VOICE_MIN_MS -> recFinish(false)
                        else -> recFinish(true)
                    }
                }
            }
        }
    }

    Box(modifier.fillMaxWidth()) {
        Column(Modifier.fillMaxWidth().padding(start = FIELD_MARGIN, end = FIELD_MARGIN, bottom = FIELD_MARGIN, top = 6.dp)) {
            if (text.length > Limits.MAX_TEXT - 300) {
                Text(
                    "${text.length}/${Limits.MAX_TEXT}",
                    Modifier.fillMaxWidth().padding(end = 10.dp, bottom = 4.dp),
                    textAlign = TextAlign.End,
                    fontSize = 11.sp,
                    color = ChatColors.Hint,
                )
            }
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(radius))
                    .background(ChatColors.Input),
            ) {
                AnimatedVisibility(
                    visible = reply != null,
                    enter = expandVertically(tween(200, easing = FastOutSlowInEasing), expandFrom = Alignment.Bottom) +
                        fadeIn(tween(150, delayMillis = 50)),
                    exit = shrinkVertically(tween(170, easing = FastOutSlowInEasing), shrinkTowards = Alignment.Bottom) +
                        fadeOut(tween(110)),
                ) {
                    lastReply[0]?.let { ReplyPanel(it, onCancelReply) }
                }
                Box {
                    Row(
                        Modifier.fillMaxWidth().heightIn(min = 41.dp),
                        verticalAlignment = Alignment.Bottom,
                    ) {
                        Box(
                            Modifier
                                .weight(1f)
                                .padding(start = 16.dp, end = 8.dp, top = 9.5.dp, bottom = 9.5.dp)
                                .graphicsLayer { alpha = if (recording) 0f else 1f },
                            contentAlignment = Alignment.CenterStart,
                        ) {
                            if (text.isEmpty()) {
                                Text("Сообщение", fontSize = 16.sp, lineHeight = 22.sp, color = ChatColors.Hint)
                            }
                            BasicTextField(
                                value = text,
                                onValueChange = { text = it.take(Limits.MAX_TEXT) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .focusRequester(focus)
                                    .onPreviewKeyEvent { e ->
                                        // Desktop: Enter отправляет, Shift+Enter — перенос строки.
                                        if ((e.key == Key.Enter || e.key == Key.NumPadEnter) && !e.isShiftPressed) {
                                            if (e.type == KeyEventType.KeyDown) send()
                                            true
                                        } else false
                                    },
                                textStyle = TextStyle(color = Color.White, fontSize = 16.sp, lineHeight = 22.sp),
                                cursorBrush = SolidColor(ChatColors.Accent),
                                maxLines = 6,
                                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                            )
                        }
                        if (audio == null) {
                            AnimatedVisibility(
                                visible = canSend,
                                enter = scaleIn(tween(120)) + fadeIn(tween(120)),
                                exit = scaleOut(tween(90)) + fadeOut(tween(90)),
                            ) { SendButton(1f, Modifier.clickable { send() }) }
                        } else {
                            // Одна кнопка: микрофон ⇄ отправка, иконки перетекают масштабом.
                            val s by animateFloatAsState(if (canSend) 1f else 0f, tween(150), label = "micSend")
                            SendButton(s, if (canSend) Modifier.clickable { send() } else micGesture)
                        }
                    }
                    androidx.compose.animation.AnimatedVisibility(
                        visible = recording,
                        modifier = Modifier.matchParentSize(),
                        enter = fadeIn(tween(140)) + slideInHorizontally(tween(200, easing = FastOutSlowInEasing)) { it / 6 },
                        exit = fadeOut(tween(140)) + slideOutHorizontally(tween(180)) { it / 6 },
                    ) {
                        RecordingRow(rec, cancelPx, onCancel = { recFinish(false) })
                    }
                }
            }
        }

        // ── Поверх плашки, без обрезки: большой круг, замок/пауза, подсказка.
        RecordOverlay(
            rec = rec,
            lockPx = lockPx,
            onSend = { recFinish((rec.recorder?.durationMs ?: 0L) >= Limits.VOICE_MIN_MS) },
            onPause = {
                val r = rec.recorder ?: return@RecordOverlay
                rec.paused = !rec.paused
                r.paused = rec.paused
            },
        )
        AnimatedVisibility(
            visible = tip != null,
            modifier = Modifier.align(Alignment.BottomEnd).offset(x = -FIELD_MARGIN, y = -(41.dp + FIELD_MARGIN + 8.dp)),
            enter = fadeIn(tween(150)) + scaleIn(tween(150), initialScale = 0.9f),
            exit = fadeOut(tween(200)),
        ) {
            Text(
                tip.orEmpty(),
                Modifier
                    .background(ChatColors.Popup, RoundedCornerShape(10.dp))
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                fontSize = 13.sp,
                color = Color.White,
            )
        }
    }
}

/** Кнопка 36dp: [send] 1 — самолётик, 0 — микрофон. */
@Composable
private fun SendButton(send: Float, modifier: Modifier) {
    Box(
        Modifier
            .padding(end = BTN_INSET, bottom = BTN_INSET)
            .size(BTN)
            .clip(CircleShape)
            .background(ChatColors.Accent)
            .then(modifier),
        contentAlignment = Alignment.Center,
    ) {
        if (send > 0.01f) {
            Icon(
                Icons.AutoMirrored.Filled.Send, "Отправить",
                Modifier.size(19.dp).graphicsLayer { alpha = send; scaleX = 0.5f + 0.5f * send; scaleY = 0.5f + 0.5f * send },
                tint = Color.White,
            )
        }
        if (send < 0.99f) {
            val m = 1f - send
            MicIcon(Color.White, 22.dp, Modifier.graphicsLayer { alpha = m; scaleX = 0.5f + 0.5f * m; scaleY = 0.5f + 0.5f * m })
        }
    }
}

/**
 * Строка записи на месте поля: ● 0:02,3   ‹ Влево — отмена. После фиксации подсказка уезжает вниз
 * и гаснет, сверху проявляется «ОТМЕНА» (220мс, как в референсе).
 */
@Composable
private fun RecordingRow(rec: RecUi, cancelPx: Float, onCancel: () -> Unit) {
    val lockT by animateFloatAsState(if (rec.phase == RecPhase.Locked) 1f else 0f, tween(220), label = "lockT")
    val inf = rememberInfiniteTransition(label = "rec")
    val blink by inf.animateFloat(1f, 0.2f, infiniteRepeatable(tween(600), RepeatMode.Reverse), label = "dot")
    val nudge by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "nudge")
    val shift = with(LocalDensity.current) { 14.dp.toPx() }
    val nudgePx = with(LocalDensity.current) { 4.dp.toPx() }
    Row(
        Modifier.fillMaxSize().background(ChatColors.Input).padding(start = 16.dp, end = BIG - 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(10.dp)
                .graphicsLayer { alpha = if (rec.paused) 0.35f else blink }
                .background(ChatColors.RecordDot, CircleShape),
        )
        Spacer(Modifier.width(10.dp))
        Text(
            recTimer(rec.ms),
            style = TextStyle(fontSize = 16.sp, lineHeight = 22.sp, fontFeatureSettings = "tnum"),
            color = Color.White,
        )
        Box(Modifier.weight(1f).fillMaxHeight(), contentAlignment = Alignment.Center) {
            if (lockT < 0.99f) {
                Text(
                    "‹  Влево — отмена",
                    Modifier.graphicsLayer {
                        val pull = (-rec.dx / cancelPx).coerceIn(0f, 1f)
                        translationX = rec.dx * 0.85f - nudge * nudgePx * (1f - pull)
                        translationY = lockT * shift
                        alpha = (1f - lockT) * (1f - 0.8f * pull)
                    },
                    fontSize = 14.sp,
                    color = ChatColors.Hint,
                    maxLines = 1,
                )
            }
            if (lockT > 0.01f) {
                Text(
                    "ОТМЕНА",
                    Modifier
                        .graphicsLayer {
                            translationY = -(1f - lockT) * shift
                            alpha = lockT
                        }
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                            enabled = rec.phase == RecPhase.Locked,
                            onClick = onCancel,
                        )
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = ChatColors.AccentText,
                    letterSpacing = 0.4.sp,
                )
            }
        }
    }
}

/**
 * Большой круг 67dp (центр совпадает с центром кнопки 36dp, поэтому он «вырастает» из неё) и замок над ним.
 * Круг идёт за пальцем; вокруг — ореол, дышащий громкостью. После фиксации: в круге самолётик,
 * замок сжимается в кнопку паузы 40dp.
 */
@Composable
private fun androidx.compose.foundation.layout.BoxScope.RecordOverlay(
    rec: RecUi,
    lockPx: Float,
    onSend: () -> Unit,
    onPause: () -> Unit,
) {
    val active = rec.phase != RecPhase.Idle
    val enter by animateFloatAsState(
        if (active) 1f else 0f,
        if (active) spring(dampingRatio = 0.62f, stiffness = Spring.StiffnessMediumLow) else tween(160),
        label = "bigEnter",
    )
    if (enter <= 0.001f && !active) return
    val lockT by animateFloatAsState(if (rec.phase == RecPhase.Locked) 1f else 0f, tween(220), label = "lockT2")
    val up = (-rec.dy / lockPx).coerceIn(0f, 1f)

    // Центр кнопки — в (W − 7 − 2.5 − 18, H − 7 − 2.5 − 18) = (W − 27.5, H − 27.5) dp.
    val btnCenter = FIELD_MARGIN + BTN_INSET + BTN / 2
    val bigOffset = BIG / 2 - btnCenter
    Box(
        Modifier
            .align(Alignment.BottomEnd)
            .offset(x = bigOffset, y = bigOffset)
            .size(BIG)
            .graphicsLayer {
                translationX = rec.dx
                translationY = rec.dy
            },
        contentAlignment = Alignment.Center,
    ) {
        // Ореол громкости.
        Box(
            Modifier
                .size(BIG)
                .graphicsLayer {
                    val s = enter * (1f + 0.55f * rec.level)
                    scaleX = s
                    scaleY = s
                    alpha = 0.22f * enter
                }
                .background(ChatColors.Accent, CircleShape),
        )
        Box(
            Modifier
                .size(BIG)
                .graphicsLayer {
                    val s = BTN.value / BIG.value + (1f - BTN.value / BIG.value) * enter
                    scaleX = s
                    scaleY = s
                }
                .clip(CircleShape)
                .background(ChatColors.Accent)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    enabled = rec.phase == RecPhase.Locked,
                    onClick = onSend,
                ),
            contentAlignment = Alignment.Center,
        ) {
            if (lockT < 0.99f) {
                MicIcon(Color.White, 30.dp, Modifier.graphicsLayer { alpha = 1f - lockT; scaleX = 1f - 0.4f * lockT; scaleY = 1f - 0.4f * lockT })
            }
            if (lockT > 0.01f) {
                Icon(
                    Icons.AutoMirrored.Filled.Send, "Отправить",
                    Modifier.size(28.dp).graphicsLayer { alpha = lockT; scaleX = 0.6f + 0.4f * lockT; scaleY = 0.6f + 0.4f * lockT },
                    tint = Color.White,
                )
            }
        }
    }

    // Замок: низ на 12dp выше круга. Тянем вверх — поднимается на 10dp и сжимается; фиксация — кнопка паузы.
    val lockBottom = btnCenter + BIG / 2 + 12.dp
    val h = LOCK_H - (LOCK_H - LOCK_W) * maxOf(up, lockT)
    val lockOffsetX = -(btnCenter - LOCK_W / 2)
    Box(
        Modifier
            .align(Alignment.BottomEnd)
            .offset(x = lockOffsetX, y = -lockBottom)
            .graphicsLayer {
                alpha = enter.coerceIn(0f, 1f)
                translationY = (1f - enter) * 24.dp.toPx() - up * (1f - lockT) * 10.dp.toPx()
            }
            .size(LOCK_W, h)
            .clip(RoundedCornerShape(LOCK_W / 2))
            .background(ChatColors.Popup)
            .border(1.dp, ChatColors.PillBorder, RoundedCornerShape(LOCK_W / 2))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                enabled = rec.phase == RecPhase.Locked,
                onClick = onPause,
            ),
        contentAlignment = Alignment.TopCenter,
    ) {
        if (lockT < 0.99f) {
            Column(
                Modifier.fillMaxWidth().padding(top = 8.dp).graphicsLayer { alpha = 1f - lockT },
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Top,
            ) {
                LockIcon(Color.White, 22.dp, open = 1f - up)
                ChevronUpIcon(ChatColors.Hint, 20.dp, Modifier.graphicsLayer { alpha = 1f - up })
            }
        }
        if (lockT > 0.01f) {
            Box(Modifier.size(LOCK_W).graphicsLayer { alpha = lockT }, contentAlignment = Alignment.Center) {
                if (rec.paused) MicIcon(ChatColors.RecordDot, 20.dp) else PauseIcon(Color.White, 18.dp)
            }
        }
    }
}

/** Панель «В ответ …»: иконка ответа, автор акцентным цветом, кусок текста, крестик. Высота 47dp. */
@Composable
private fun ReplyPanel(reply: ReplyDraft, onCancel: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().height(47.dp).padding(start = 13.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        ReplyIcon(ChatColors.Accent, 22.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
            Text(
                "В ответ ${reply.authorName}",
                fontSize = 14.sp,
                lineHeight = 18.sp,
                fontWeight = FontWeight.SemiBold,
                color = ChatColors.Accent,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                reply.ref.text.replace('\n', ' ').ifEmpty { "Сообщение" },
                fontSize = 14.sp,
                lineHeight = 18.sp,
                color = Color.White.copy(alpha = 0.7f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Box(
            Modifier
                .size(40.dp)
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onCancel() },
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Filled.Close, "Отменить ответ", Modifier.size(20.dp), tint = ChatColors.Hint)
        }
    }
}
