package app.nuva.ui.chat

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.nuva.core.chat.ChatMessage
import app.nuva.core.chat.MsgStatus
import app.nuva.ui.components.StatusTicks
import app.nuva.ui.components.timeHm
import app.nuva.ui.voice.VoicePlayback
import kotlin.math.max
import kotlin.math.min

// Геометрия плеера (снята с референса): кнопка 44dp, волна 24dp, столбик 2.5dp + зазор 1.5dp.
private val PLAY_SIZE = 44.dp
private val WAVE_H = 24.dp
private const val BAR_W_DP = 2.5f
private const val BAR_GAP_DP = 1.5f
private const val BAR_MIN_DP = 2.5f

/** Ширина волны: 1 с → 96dp, растёт до 30 с → 196dp. Дальше не растёт — как в референсе. */
internal fun waveWidth(durationMs: Long, max: Dp): Dp {
    val t = (durationMs.coerceIn(1_000L, 30_000L) - 1_000L) / 29_000f
    return minOf((96f + 100f * t).dp, max)
}

private fun mmss(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "${(s / 60).toString().padStart(2, '0')}:${(s % 60).toString().padStart(2, '0')}"
}

/**
 * Содержимое пузыря голосового: [кнопка] [волна / длительность •] … время ✓.
 * Исходящие: белая кнопка с иконкой цвета пузыря, сыгранная часть волны белая. Входящие: акцентная кнопка.
 */
@Composable
internal fun VoiceContent(msg: ChatMessage, playback: VoicePlayback, maxWidth: Dp) {
    val v = msg.voice ?: return
    val out = msg.outgoing
    val playing = playback.isPlaying(msg)
    val current = playback.isCurrent(msg)
    val progress = playback.progressOf(msg)

    val btnBg = if (out) Color.White else ChatColors.Accent
    val btnFg = if (out) Color(0xFF5B4F9B) else Color.White
    val played = if (out) Color.White else ChatColors.AccentText
    val rest = if (out) Color.White.copy(alpha = 0.38f) else ChatColors.Hint.copy(alpha = 0.45f)
    val meta = Color.White.copy(alpha = if (out) 0.7f else 0.5f)

    val uploading = out && msg.status == MsgStatus.PENDING && v.sentParts < v.parts
    val downloading = !out && !v.ready
    val ring = when {
        uploading -> v.uploadProgress
        downloading -> if (v.parts <= 0) 0f else v.haveParts.toFloat() / v.parts
        else -> null
    }

    val waveW = waveWidth(v.durationMs, maxWidth - PLAY_SIZE - 10.dp)
    Row(Modifier.padding(top = 3.dp, bottom = 1.dp), verticalAlignment = Alignment.CenterVertically) {
        PlayButton(
            playing = playing,
            ring = ring,
            downloading = downloading,
            bg = btnBg,
            fg = btnFg,
            onClick = { if (v.ready) playback.toggle(msg) },
        )
        Spacer(Modifier.width(10.dp))
        Column(Modifier.width(maxOf(waveW, 118.dp))) {
            Waveform(
                wave = v.wave,
                progress = progress,
                played = played,
                rest = rest,
                modifier = Modifier
                    .width(waveW)
                    .height(WAVE_H)
                    .pointerInput(msg.clientMsgId, v.ready) {
                        if (!v.ready) return@pointerInput
                        detectTapGestures { p -> playback.seek(msg, p.x / size.width) }
                    }
                    .pointerInput(msg.clientMsgId, current) {
                        // Протяжка — только у играющего/начатого: иначе мешала бы свайпу «ответить».
                        if (!current) return@pointerInput
                        detectHorizontalDragGestures { change, _ ->
                            change.consume()
                            playback.seek(msg, change.position.x / size.width)
                        }
                    },
            )
            Spacer(Modifier.height(3.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                val shown = if (current && progress > 0f) playback.positionMs else v.durationMs
                Text(
                    mmss(shown),
                    style = TextStyle(fontSize = 12.5.sp, lineHeight = 16.sp, fontFeatureSettings = "tnum"),
                    color = meta,
                )
                if (!v.listened) {
                    Spacer(Modifier.width(4.dp))
                    Box(Modifier.size(5.dp).background(if (out) Color.White else ChatColors.Accent, CircleShape))
                }
                Spacer(Modifier.weight(1f))
                Text(timeHm(msg.ts), fontSize = 12.sp, color = meta)
                if (out) {
                    Spacer(Modifier.width(3.dp))
                    StatusTicks(msg.status, Color.White.copy(alpha = 0.85f))
                }
            }
        }
    }
}

@Composable
private fun PlayButton(
    playing: Boolean,
    ring: Float?,
    downloading: Boolean,
    bg: Color,
    fg: Color,
    onClick: () -> Unit,
) {
    val t by animateFloatAsState(if (playing) 1f else 0f, tween(160), label = "playMorph")
    val spin = rememberInfiniteTransition(label = "ringSpin")
    val angle by spin.animateFloat(0f, 360f, infiniteRepeatable(tween(1400, easing = LinearEasing)), label = "ringAngle")
    val ringShown by animateFloatAsState(if (ring != null) 1f else 0f, tween(200), label = "ringShown")
    val ringValue by animateFloatAsState(ring ?: 1f, tween(250), label = "ringValue")
    Box(
        Modifier
            .size(PLAY_SIZE)
            .clip(CircleShape)
            .background(bg)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                enabled = !downloading,
                onClick = onClick,
            ),
        contentAlignment = Alignment.Center,
    ) {
        when {
            downloading -> DownloadIcon(fg, 22.dp)
            else -> {
                PlayIcon(fg, 24.dp, Modifier.graphicsLayer { alpha = 1f - t; scaleX = 1f - 0.4f * t; scaleY = 1f - 0.4f * t })
                PauseIcon(fg, 24.dp, Modifier.graphicsLayer { alpha = t; scaleX = 0.6f + 0.4f * t; scaleY = 0.6f + 0.4f * t })
            }
        }
        if (ringShown > 0.01f) {
            Canvas(Modifier.size(PLAY_SIZE)) {
                val w = 2.dp.toPx()
                val inset = 3.dp.toPx() + w / 2
                val sweep = max(18f, 360f * ringValue)
                drawArc(
                    color = fg.copy(alpha = ringShown),
                    startAngle = angle - 90f,
                    sweepAngle = min(sweep, 359f),
                    useCenter = false,
                    topLeft = Offset(inset, inset),
                    size = Size(size.width - inset * 2, size.height - inset * 2),
                    style = Stroke(w, cap = StrokeCap.Round),
                )
            }
        }
    }
}

/**
 * Волна: 64 значения 0..255 → N столбиков по ширине (максимум в окне — пики не теряются при сжатии).
 * Сначала вся волна «несыгранным» цветом, поверх — сыгранная часть, обрезанная по прогрессу:
 * граница идёт плавно, даже посреди столбика.
 */
@Composable
private fun Waveform(wave: List<Int>, progress: Float, played: Color, rest: Color, modifier: Modifier) {
    Canvas(modifier) {
        val barW = BAR_W_DP.dp.toPx()
        val step = barW + BAR_GAP_DP.dp.toPx()
        val n = max(1, ((size.width + BAR_GAP_DP.dp.toPx()) / step).toInt())
        val minH = BAR_MIN_DP.dp.toPx()
        val r = CornerRadius(barW / 2, barW / 2)
        val src = wave.ifEmpty { listOf(0) }
        val heights = FloatArray(n) { i ->
            val a = i * src.size / n
            val b = max(a + 1, (i + 1) * src.size / n)
            var m = 0
            for (j in a until min(b, src.size)) m = max(m, src[j])
            max(minH, size.height * (m / 255f))
        }
        fun bars(color: Color) {
            for (i in 0 until n) {
                val h = heights[i]
                drawRoundRect(color, Offset(i * step, (size.height - h) / 2), Size(barW, h), r)
            }
        }
        bars(rest)
        if (progress > 0f) clipRect(right = size.width * progress.coerceIn(0f, 1f)) { bars(played) }
    }
}
