package app.nuva.ui.voice

/**
 * Аудио платформы для голосовых. Реализации — в app-android (AudioRecord/AudioTrack) и app-desktop
 * (javax.sound). UI работает только через этот контракт, поэтому общий код не знает про потоки и API ОС.
 */
interface VoiceAudio {
    /** Есть ли доступ к микрофону прямо сейчас. */
    fun micAllowed(): Boolean = true

    /** Запросить доступ. [onResult] вызывается на главном потоке. */
    fun requestMic(onResult: (Boolean) -> Unit) = onResult(true)

    fun recorder(): VoiceRecorder
    fun player(): VoicePlayer
}

/**
 * Захват микрофона: 16-битный моно PCM. Методы зовутся с главного потока; захват идёт в своём потоке.
 * [stop] возвращает запись уже в частоте NVOI (16 кГц) — ресэмплинг внутри реализации.
 */
interface VoiceRecorder {
    /** false — микрофон занят/недоступен. */
    fun start(): Boolean

    /** Громкость последних ~20 мс, 0..1 (см. Pcm.level). Читается каждый кадр. */
    val level: Float

    /** Длительность записанного без учёта пауз, мс. */
    val durationMs: Long

    /** Пауза: поток продолжает читать микрофон (без щелчков при возобновлении), но отсчёты не копятся. */
    var paused: Boolean

    fun stop(): ShortArray
    fun cancel()
}

/** Проигрыватель PCM. Один на экран чата: новый play() останавливает предыдущий. */
interface VoicePlayer {
    /** Играть [pcm] с отсчёта [from]. */
    fun play(pcm: ShortArray, sampleRate: Int, from: Int)

    /** Позиция в отсчётах от начала pcm (с учётом [from]). */
    val position: Int

    /** false — остановлен или доиграл до конца. */
    val isPlaying: Boolean

    fun stop()
}
