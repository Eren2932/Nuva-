package app.nuva.ui.voice

import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import app.nuva.core.chat.ChatMessage
import app.nuva.core.voice.Nvoi
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Воспроизведение голосовых в открытом чате. Одновременно играет одно сообщение. Позиция каждого
 * сообщения запоминается (пауза → продолжить с того же места). Прогресс обновляется раз в кадр
 * из позиции проигрывателя — без таймеров и рассинхрона со звуком.
 *
 * @param load байты NVOI (null — ещё не докачано)
 * @param onListened входящее начали слушать
 * @param next следующее голосовое для автопроигрывания (входящее непрослушанное ниже по ленте)
 */
@Stable
class VoicePlayback(
    private val audio: VoiceAudio?,
    private val scope: CoroutineScope,
    private val load: suspend (ChatMessage) -> ByteArray?,
    private val onListened: (ChatMessage) -> Unit,
    private val next: (ChatMessage) -> ChatMessage?,
) {
    val available: Boolean get() = audio != null

    /** Ключ играющего (или загружаемого) сообщения. */
    var currentKey by mutableStateOf<String?>(null)
        private set
    var playing by mutableStateOf(false)
        private set
    /** Текущая позиция играющего, мс. */
    var positionMs by mutableStateOf(0L)
        private set

    private val progress = mutableStateMapOf<String, Float>()
    private val cache = LinkedHashMap<String, Pair<ShortArray, Int>>(4, 0.75f, true)
    private var player: VoicePlayer? = null
    private var job: Job? = null

    fun isCurrent(msg: ChatMessage): Boolean = currentKey == key(msg)
    fun isPlaying(msg: ChatMessage): Boolean = playing && isCurrent(msg)
    fun progressOf(msg: ChatMessage): Float = progress[key(msg)] ?: 0f

    fun toggle(msg: ChatMessage) {
        if (isPlaying(msg)) pause() else start(msg, progressOf(msg).let { if (it >= 0.995f) 0f else it })
    }

    /** Перемотка на долю [f]. Если сообщение играет — продолжает с новой точки. */
    fun seek(msg: ChatMessage, f: Float) {
        val v = f.coerceIn(0f, 1f)
        progress[key(msg)] = v
        if (isPlaying(msg)) start(msg, v)
    }

    fun pause() {
        job?.cancel()
        job = null
        player?.stop()
        playing = false
    }

    fun release() {
        pause()
        currentKey = null
        cache.clear()
        player = null
    }

    private fun start(msg: ChatMessage, from: Float) {
        val a = audio ?: return
        val v = msg.voice ?: return
        if (!v.ready) return
        job?.cancel()
        player?.stop()
        val k = key(msg)
        currentKey = k
        playing = true
        job = scope.launch {
            val clip = cache[k] ?: withContext(Dispatchers.Default) {
                val data = load(msg) ?: return@withContext null
                val rate = Nvoi.header(data)?.sampleRate ?: return@withContext null
                val pcm = Nvoi.decode(data) ?: return@withContext null
                pcm to rate
            }?.also {
                cache[k] = it
                while (cache.size > 4) cache.remove(cache.keys.first())
            }
            if (clip == null || clip.first.isEmpty()) {
                playing = false
                return@launch
            }
            val (pcm, rate) = clip
            val p = player ?: a.player().also { player = it }
            val at = (from * pcm.size).toInt().coerceIn(0, pcm.size - 1)
            p.play(pcm, rate, at)
            if (!msg.outgoing && !v.listened) onListened(msg)
            while (isActive) {
                withFrameNanos { }
                val pos = p.position.coerceIn(0, pcm.size)
                progress[k] = pos.toFloat() / pcm.size
                positionMs = pos * 1000L / rate
                if (!p.isPlaying) break
            }
            if (!isActive) return@launch
            p.stop() // освобождаем аудиовыход сразу, а не при следующем play()
            // Доиграли: сброс в начало, как в референсе, и автопереход к следующему непрослушанному.
            progress[k] = 0f
            playing = false
            currentKey = null
            next(msg)?.let { start(it, 0f) }
        }
    }

    private fun key(msg: ChatMessage): String = (if (msg.outgoing) "o:" else "i:") + msg.clientMsgId
}
