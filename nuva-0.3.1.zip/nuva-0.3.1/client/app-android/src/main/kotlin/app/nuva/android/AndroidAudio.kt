package app.nuva.android

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.audiofx.NoiseSuppressor
import android.os.Process
import app.nuva.core.voice.VoiceCapture
import app.nuva.core.voice.VoiceClip
import app.nuva.core.voice.VoiceRecording
import app.nuva.ui.voice.VoiceAudio
import app.nuva.ui.voice.VoicePlayer
import app.nuva.ui.voice.VoiceRecorder
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Голосовые на Android.
 *
 * Запись: источник MIC (не VOICE_COMMUNICATION: тот включает телефонный AEC/AGC и «грязнит» речь), микрофон
 * открывается в фоновом потоке, кадры сразу уходят в кодировщик Opus.
 * Воспроизведение: AudioTrack, аудиофокус и запись в буфер — тоже в фоне; главный поток не блокируется никогда.
 */
class AndroidAudio(private val app: Context, private val host: AndroidHost) : VoiceAudio {
    override fun micAllowed(): Boolean =
        app.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    override fun requestMic(onResult: (Boolean) -> Unit) = host.requestMic(onResult)

    override fun recorder(): VoiceRecorder = Recorder()

    override fun player(): VoicePlayer = Player(app)

    private class Recorder : VoiceRecorder {
        @Volatile private var capture: VoiceCapture? = null
        @Volatile private var stopRequested = false
        @Volatile private var cancelled = false
        @Volatile private var pausedFlag = false
        @Volatile override var failed = false
            private set
        private val finished = CompletableDeferred<Unit>()

        override val level: Float get() = capture?.level ?: 0f
        override val durationMs: Long get() = capture?.durationMs ?: 0L
        override var paused: Boolean
            get() = pausedFlag
            set(v) {
                pausedFlag = v
                capture?.paused = v
            }

        override fun start() {
            Thread({ run() }, "nuva-rec").start()
        }

        @SuppressLint("MissingPermission")
        private fun run() {
            var rec: AudioRecord? = null
            var ns: NoiseSuppressor? = null
            try {
                Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
                var rate = 0
                for (r in RATES) {
                    val min = AudioRecord.getMinBufferSize(r, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
                    if (min <= 0) continue
                    // ≥ 200 мс буфера: сборка мусора/планировщик не роняют отсчёты.
                    val bytes = maxOf(min * 2, r / 5 * 2)
                    val candidate = AudioRecord(
                        MediaRecorder.AudioSource.MIC, r, AudioFormat.CHANNEL_IN_MONO,
                        AudioFormat.ENCODING_PCM_16BIT, bytes,
                    )
                    if (candidate.state == AudioRecord.STATE_INITIALIZED) {
                        rec = candidate
                        rate = r
                        break
                    }
                    candidate.release()
                }
                if (rec == null || cancelled) {
                    if (rec == null) failed = true
                    return
                }
                // Шумодав платформы (если есть) — для голосовых сообщений он полезен; AGC не включаем: «качает» громкость.
                ns = runCatching {
                    if (NoiseSuppressor.isAvailable()) NoiseSuppressor.create(rec.audioSessionId)?.also { it.enabled = true } else null
                }.getOrNull()
                val cap = VoiceCapture(rate)
                cap.paused = pausedFlag
                capture = cap
                rec.startRecording()
                if (rec.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
                    failed = true
                    return
                }
                val buf = ShortArray(rate / 50) // 20 мс
                while (!stopRequested) {
                    val n = rec.read(buf, 0, buf.size)
                    if (n < 0) {
                        failed = true
                        break
                    }
                    cap.feed(buf, n)
                }
            } catch (e: Exception) {
                failed = true
            } finally {
                runCatching { ns?.release() }
                runCatching { rec?.stop() }
                runCatching { rec?.release() }
                finished.complete(Unit)
            }
        }

        override suspend fun finish(): VoiceRecording? {
            stopRequested = true
            finished.await()
            val cap = capture ?: return null
            if (failed && cap.durationMs <= 0) return null
            return cap.finish()
        }

        override fun cancel() {
            cancelled = true
            stopRequested = true
            capture?.cancel()
        }
    }

    private class Player(context: Context) : VoicePlayer {
        private val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        private val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
            .build()
        private val focus = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
            .setAudioAttributes(attrs)
            .setOnAudioFocusChangeListener { change ->
                if (change == AudioManager.AUDIOFOCUS_LOSS || change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) stop()
            }
            .build()

        /** Поколение воспроизведения: любой поток, увидев чужое поколение, прекращает работу и чистит за собой. */
        private val gen = AtomicInteger(0)
        private val focusUsers = AtomicInteger(0)
        @Volatile private var track: AudioTrack? = null
        @Volatile private var running = false
        @Volatile private var base = 0

        override val position: Int
            get() {
                val t = track ?: return base
                return base + runCatching { t.playbackHeadPosition }.getOrDefault(0)
            }

        override val isPlaying: Boolean get() = running

        override fun play(clip: VoiceClip, from: Int) {
            val g = gen.incrementAndGet()
            val old = track
            track = null
            base = from
            running = true
            if (old != null) quiet(old)
            Thread({ run(g, clip, from) }, "nuva-play").start()
        }

        override fun stop() {
            gen.incrementAndGet()
            running = false
            val t = track
            track = null
            if (t != null) quiet(t)
        }

        /** pause+flush будят заблокированный write(); делаем это не на вызывающем потоке. */
        private fun quiet(t: AudioTrack) {
            STOPPER.execute { runCatching { t.pause() }; runCatching { t.flush() } }
        }

        private fun run(g: Int, clip: VoiceClip, from: Int) {
            var t: AudioTrack? = null
            var focused = false
            try {
                Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
                val rate = clip.sampleRate
                val min = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
                val bytes = maxOf(min * 2, rate / 4 * 2)
                t = AudioTrack.Builder()
                    .setAudioAttributes(attrs)
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(rate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build(),
                    )
                    .setBufferSizeInBytes(bytes)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()
                if (gen.get() != g) return
                if (focusUsers.getAndIncrement() == 0) am.requestAudioFocus(focus)
                focused = true
                if (gen.get() != g) return
                track = t
                t.play()
                var o = from
                val total = clip.totalSamples
                while (gen.get() == g && o < total) {
                    val avail = clip.available(o)
                    if (avail <= 0) {
                        Thread.sleep(4) // декодер ещё не дошёл (медленный телефон / перемотка вперёд)
                        continue
                    }
                    val w = t.write(clip.pcm, o, minOf(avail, 2048, total - o))
                    if (w <= 0) break
                    o += w
                }
                if (gen.get() == g) {
                    // Дать доиграть буфер: позиция должна дойти до конца, иначе последние 200 мс обрежутся.
                    val deadline = System.currentTimeMillis() + 1500
                    while (gen.get() == g && System.currentTimeMillis() < deadline &&
                        base + t.playbackHeadPosition < total
                    ) Thread.sleep(10)
                }
            } catch (e: Exception) {
                // сбой аудиоподсистемы: просто завершаемся, UI увидит isPlaying=false
            } finally {
                if (track === t) track = null
                runCatching { t?.stop() }
                runCatching { t?.release() }
                if (focused && focusUsers.decrementAndGet() == 0) runCatching { am.abandonAudioFocusRequest(focus) }
                if (gen.get() == g) running = false
            }
        }
    }

    private companion object {
        /** 16 кГц нативно (без ресэмплинга) → 48/44.1 кГц, если микрофон не отдаёт 16. */
        val RATES = intArrayOf(16_000, 48_000, 44_100)
        val STOPPER = Executors.newSingleThreadExecutor { r -> Thread(r, "nuva-audio-stop").apply { isDaemon = true } }
    }
}
