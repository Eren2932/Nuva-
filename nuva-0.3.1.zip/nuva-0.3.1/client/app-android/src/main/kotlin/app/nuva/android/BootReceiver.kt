package app.nuva.android

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import kotlinx.coroutines.launch

/** После перезагрузки телефона и обновления приложения поднимаем службу приёма, если есть аккаунт. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        if (action != Intent.ACTION_BOOT_COMPLETED && action != Intent.ACTION_MY_PACKAGE_REPLACED) return
        val app = context.applicationContext as NuvaApplication
        if (!app.host.backgroundEnabled()) return
        val pending = goAsync()
        app.graph.scope.launch {
            try {
                app.graph.init()
                if (app.graph.core.account.value != null) NuvaService.start(app)
            } finally {
                pending.finish()
            }
        }
    }
}
