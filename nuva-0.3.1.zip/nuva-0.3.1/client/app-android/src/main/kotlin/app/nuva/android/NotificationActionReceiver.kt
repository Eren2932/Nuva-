package app.nuva.android

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.RemoteInput
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

/** «Ответить» и «Прочитано» из шторки уведомлений. Сами уведомления гаснут по базе (см. NotificationCenter). */
class NotificationActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val peer = intent.getStringExtra(EXTRA_PEER) ?: return
        val action = intent.action ?: return
        val reply = if (action == ACTION_REPLY) {
            RemoteInput.getResultsFromIntent(intent)?.getCharSequence(NotificationCenter.KEY_TEXT)?.toString().orEmpty()
        } else ""
        val graph = (context.applicationContext as NuvaApplication).graph
        val pending = goAsync()
        graph.scope.launch {
            try {
                graph.init()
                val m = withTimeoutOrNull(10_000) { graph.core.messenger.filterNotNull().first() } ?: return@launch
                if (action == ACTION_REPLY && reply.isNotBlank()) m.sendText(peer, reply)
                // Ответ из шторки — осознанное действие: чат считается прочитанным.
                m.markAllRead(peer)
            } finally {
                pending.finish()
            }
        }
    }

    companion object {
        const val ACTION_REPLY = "app.nuva.action.REPLY"
        const val ACTION_READ = "app.nuva.action.MARK_READ"
        const val EXTRA_PEER = "app.nuva.extra.PEER"
    }
}
