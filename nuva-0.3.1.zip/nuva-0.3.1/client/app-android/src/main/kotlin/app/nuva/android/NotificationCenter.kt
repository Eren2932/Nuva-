package app.nuva.android

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.Person
import androidx.core.app.RemoteInput
import app.nuva.core.chat.IncomingNotice
import app.nuva.ui.AppGraph
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.launch

/**
 * Системные уведомления о новых сообщениях. Группируются по чатам (MessagingStyle), ответить и пометить
 * прочитанным можно прямо из уведомления, тап открывает нужный чат. Единственный источник правды —
 * база: уведомление гаснет, как только в чате не осталось непрочитанных (прочитал в приложении,
 * нажал «Прочитано», ответил из шторки).
 */
class NotificationCenter(private val ctx: Context, private val graph: AppGraph) {
    private class Line(val text: String, val ts: Long)

    private val lock = Any()
    private val history = HashMap<String, ArrayList<Line>>()
    private val titles = HashMap<String, String>()
    private val shown = LinkedHashSet<String>()
    private val shownAt = HashMap<String, Long>()

    @Volatile
    private var lastUnread: Set<String> = emptySet()

    fun start() {
        ensureChannels(ctx)
        graph.scope.launch {
            graph.core.messenger.filterNotNull().collectLatest { m ->
                coroutineScope {
                    launch { m.incoming.collect { post(it) } }
                    launch { m.chats().collect { chats -> reconcile(chats.filter { it.unread > 0 }.mapTo(HashSet()) { it.peerId }) } }
                }
            }
        }
    }

    private fun post(n: IncomingNotice) {
        val (lines, title) = synchronized(lock) {
            val l = history.getOrPut(n.peerId) { ArrayList() }
            l += Line(n.text, n.ts)
            while (l.size > MAX_LINES) l.removeAt(0)
            titles[n.peerId] = n.title
            shown += n.peerId
            shownAt[n.peerId] = System.currentTimeMillis()
            l.toList() to n.title
        }

        val me = Person.Builder().setName("Вы").build()
        val them = Person.Builder().setName(title).build()
        val style = NotificationCompat.MessagingStyle(me)
        for (line in lines) style.addMessage(line.text, line.ts, them)

        val remoteInput = RemoteInput.Builder(KEY_TEXT).setLabel("Ответить").build()
        val replyIntent = Intent(ctx, NotificationActionReceiver::class.java)
            .setAction(NotificationActionReceiver.ACTION_REPLY)
            .putExtra(NotificationActionReceiver.EXTRA_PEER, n.peerId)
        val replyPi = PendingIntent.getBroadcast(
            ctx, notifId(n.peerId) * 2, replyIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0),
        )
        val replyAction = NotificationCompat.Action.Builder(R.drawable.ic_stat_nuva, "Ответить", replyPi)
            .addRemoteInput(remoteInput)
            .setSemanticAction(NotificationCompat.Action.SEMANTIC_ACTION_REPLY)
            .setAllowGeneratedReplies(false)
            .build()

        val readIntent = Intent(ctx, NotificationActionReceiver::class.java)
            .setAction(NotificationActionReceiver.ACTION_READ)
            .putExtra(NotificationActionReceiver.EXTRA_PEER, n.peerId)
        val readPi = PendingIntent.getBroadcast(
            ctx, notifId(n.peerId) * 2 + 1, readIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val readAction = NotificationCompat.Action.Builder(R.drawable.ic_stat_nuva, "Прочитано", readPi)
            .setSemanticAction(NotificationCompat.Action.SEMANTIC_ACTION_MARK_AS_READ)
            .setShowsUserInterface(false)
            .build()

        val publicVersion = NotificationCompat.Builder(ctx, CH_MESSAGES)
            .setSmallIcon(R.drawable.ic_stat_nuva)
            .setContentTitle("Nuva")
            .setContentText("Новое сообщение")
            .build()

        val notification = NotificationCompat.Builder(ctx, CH_MESSAGES)
            .setSmallIcon(R.drawable.ic_stat_nuva)
            .setColor(ACCENT)
            .setStyle(style)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            .setPublicVersion(publicVersion)
            .setWhen(n.ts)
            .setShowWhen(true)
            .setAutoCancel(true)
            .setGroup(GROUP)
            .setContentIntent(openChatIntent(n.peerId))
            .addAction(replyAction)
            .addAction(readAction)
            .build()

        notify(notifId(n.peerId), notification)
        postSummary()
    }

    /** Сводка нужна, чтобы чаты складывались в одну пачку; с одним чатом система её не показывает. */
    private fun postSummary() {
        val count = synchronized(lock) { shown.size }
        val summary = NotificationCompat.Builder(ctx, CH_MESSAGES)
            .setSmallIcon(R.drawable.ic_stat_nuva)
            .setColor(ACCENT)
            .setContentTitle("Nuva")
            .setContentText(if (count == 1) "Новое сообщение" else "Новые сообщения: $count чата")
            .setGroup(GROUP)
            .setGroupSummary(true)
            .setAutoCancel(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openChatIntent(null))
            .build()
        notify(SUMMARY_ID, summary)
    }

    /** Гасим уведомления чатов, где непрочитанных больше нет. */
    private fun reconcile(unreadPeers: Set<String>) {
        lastUnread = unreadPeers
        var tooFresh = false
        val gone = synchronized(lock) {
            val now = System.currentTimeMillis()
            val g = ArrayList<String>()
            for (p in shown) {
                if (p in unreadPeers) continue
                // Только что показанное не гасим по «устаревшему» снимку базы: перепроверим чуть позже.
                if (now - (shownAt[p] ?: 0L) < FRESH_MS) tooFresh = true else g += p
            }
            for (p in g) {
                shown -= p
                shownAt.remove(p)
                history.remove(p)
                titles.remove(p)
            }
            g
        }
        if (tooFresh) graph.scope.launch {
            delay(FRESH_MS + 100)
            reconcile(lastUnread)
        }
        if (gone.isEmpty()) return
        val nm = NotificationManagerCompat.from(ctx)
        for (p in gone) nm.cancel(notifId(p))
        if (synchronized(lock) { shown.isEmpty() }) nm.cancel(SUMMARY_ID)
    }

    @SuppressLint("MissingPermission")
    private fun notify(id: Int, notification: android.app.Notification) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        try {
            NotificationManagerCompat.from(ctx).notify(id, notification)
        } catch (_: SecurityException) {
            // Разрешение отозвали между проверкой и вызовом — молча пропускаем.
        }
    }

    private fun openChatIntent(peerId: String?): PendingIntent {
        val intent = Intent(ctx, MainActivity::class.java)
            .setAction(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        if (peerId != null) intent.putExtra(EXTRA_OPEN_PEER, peerId)
        return PendingIntent.getActivity(
            ctx, if (peerId == null) 1 else notifId(peerId) * 2 + 2, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }

    companion object {
        const val CH_MESSAGES = "messages"
        const val CH_SYNC = "sync"
        const val GROUP = "app.nuva.messages"
        const val KEY_TEXT = "reply_text"
        const val EXTRA_OPEN_PEER = "app.nuva.extra.OPEN_PEER"
        private const val SUMMARY_ID = 20053
        private const val MAX_LINES = 7
        private const val FRESH_MS = 1_500L
        private const val ACCENT = 0xFF6559A3.toInt() // фирменный #6559A3 (как в 0.2.3)

        private fun notifId(peerId: String): Int = (peerId.hashCode() and 0x3FFFFFFF) + 100

        fun ensureChannels(ctx: Context) {
            if (Build.VERSION.SDK_INT < 26) return
            val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
            nm.createNotificationChannel(
                NotificationChannel(CH_MESSAGES, "Сообщения", NotificationManager.IMPORTANCE_HIGH).apply {
                    description = "Новые сообщения в чатах"
                    enableVibration(true)
                    lockscreenVisibility = android.app.Notification.VISIBILITY_PRIVATE
                },
            )
            nm.createNotificationChannel(
                NotificationChannel(CH_SYNC, "Приём сообщений", NotificationManager.IMPORTANCE_MIN).apply {
                    description = "Тихая иконка, пока Nuva держит соединение в фоне"
                    setShowBadge(false)
                },
            )
        }
    }
}
