package app.nuva.android

import android.app.Application
import android.net.ConnectivityManager
import android.net.Network
import app.nuva.ui.AppGraph
import kotlinx.coroutines.launch

/** Один AppGraph на процесс: переживает пересоздание Activity, регистрация не обрывается. */
class NuvaApplication : Application() {
    lateinit var graph: AppGraph
        private set
    lateinit var host: AndroidHost
        private set

    override fun onCreate() {
        super.onCreate()
        host = AndroidHost(this)
        graph = AppGraph(AndroidPlatform(this), host)
        NotificationCenter(this, graph).start()
        // Аккаунт появился (вход/регистрация) или пропал (выход): включаем или гасим службу приёма.
        graph.scope.launch {
            var hadAccount = false
            graph.core.account.collect { acc ->
                if (acc != null) {
                    hadAccount = true
                    if (host.backgroundEnabled()) NuvaService.start(this@NuvaApplication)
                } else if (hadAccount) {
                    // Начальное null (ещё грузится) игнорируем; настоящий выход — гасим службу.
                    NuvaService.stop(this@NuvaApplication)
                }
            }
        }
        // Сеть вернулась — переподключаемся сразу, не дожидаясь backoff-таймера сокета.
        getSystemService(ConnectivityManager::class.java)?.registerDefaultNetworkCallback(
            object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) = graph.onForeground()
            },
        )
    }
}
