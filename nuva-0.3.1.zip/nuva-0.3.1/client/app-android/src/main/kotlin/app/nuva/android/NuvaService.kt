package app.nuva.android

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.launch

/**
 * Служба приёма сообщений. Без Firebase единственный способ получать сообщения при закрытом приложении —
 * держать процесс живым с постоянным (тихим) значком. Сам сокет и повторные подключения живут в ядре.
 */
class NuvaService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        NotificationCenter.ensureChannels(this)
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(ID, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(ID, buildNotification())
            }
        } catch (e: Exception) {
            // Система не дала стать foreground-службой (например, запуск из фона на Android 12+).
            stopSelf()
            return START_NOT_STICKY
        }
        val graph = (application as NuvaApplication).graph
        graph.scope.launch {
            graph.init()
            // Аккаунта нет (не зарегистрировались или вышли) — держать нечего.
            if (graph.core.account.value == null) stopSelf()
        }
        return START_STICKY
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        return NotificationCompat.Builder(this, NotificationCenter.CH_SYNC)
            .setSmallIcon(R.drawable.ic_stat_nuva)
            .setContentTitle("Nuva")
            .setContentText("Приём сообщений включён")
            .setOngoing(true)
            .setSilent(true)
            .setShowWhen(false)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setContentIntent(open)
            .build()
    }

    companion object {
        private const val ID = 20054

        fun start(ctx: Context) {
            try {
                ContextCompat.startForegroundService(ctx, Intent(ctx, NuvaService::class.java))
            } catch (e: Exception) {
                // Запуск из фона запрещён — повторим, когда приложение снова окажется на экране.
            }
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, NuvaService::class.java))
        }
    }
}
