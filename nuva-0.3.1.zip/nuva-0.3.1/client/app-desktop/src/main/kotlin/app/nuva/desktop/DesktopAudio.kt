package app.nuva.desktop

import app.nuva.core.voice.VoiceCapture
import app.nuva.core.voice.VoiceClip
import app.nuva.core.voice.VoiceRecording
import app.nuva.ui.HostBridge
import app.nuva.ui.voice.VoiceAudio
import app.nuva.ui.voice.VoicePlayer
import app.nuva.ui.voice.VoiceRecorder
import java.util.concurrent.atomic.AtomicInteger
import javax.sound.sampled.AudioFormat
import javax.sound.sampled.AudioSystem
import javax.sound.sampled.SourceDataLine
import javax.sound.sampled.TargetDataLine
import kotlinx.coroutines.CompletableDeferred

/** Desktop-часть HostBridge: звук для голосовых и выбор файла для аватарки. */
object DesktopHost : HostBridge {
    override val audio: VoiceAudio = DesktopAudio
}

/** Голосовые на JVM: javax.sound (16-бит моно, little-endian). Разрешений ОС не просит. */
object DesktopAudio : VoiceAudio {
    override fun recorder(): VoiceRecorder = Recorder()
    override fun player(): VoicePlayer = Player()

    private fun format(rate: Int) = AudioFormat(rate.toFloat(), 16, 1, true, false)

    private class Recorder : VoiceRecorder {
        @Volatile private var capture: VoiceCapture? = null
        @Volatile private var stopRequested = false
        @Volatile private var cancelled = false
        @Volatile private var pausedFlag = false
        @Volatile override var failed = false
            private set
        private val finished = CompletableDeferred<Unit>()

        override val level: Float get() = capture?.level ?: 0f
        override val durationMs: Long get() = capture?.durationMs ?: 0L
        override var paused: Boolean
            get() = pausedFlag
            set(v) {
                pausedFlag = v
                capture?.paused = v
            }

        override fun start() {
            Thread({ run() }, "nuva-rec").apply {
                isDaemon = true
                priority = Thread.MAX_PRIORITY
                start()
            }
        }

        private fun run() {
            var line: TargetDataLine? = null
            try {
                var rate = 0
                for (r in RATES) {
                    val l = runCatching {
                        AudioSystem.getTargetDataLine(format(r)).also { it.open(format(r), r / 5 * 2) }
                    }.getOrNull() ?: continue
                    line = l
                    rate = r
                    break
                }
                if (line == null || cancelled) {
                    if (line == null) failed = true
                    return
                }
                val cap = VoiceCapture(rate)
                cap.paused = pausedFlag
                capture = cap
                line.start()
                val bytes = ByteArray(rate / 50 * 2) // 20 мс
                val pcm = ShortArray(bytes.size / 2)
                while (!stopRequested) {
                    val n = line.read(bytes, 0, bytes.size)
                    if (n <= 0) {
                        if (!line.isOpen) failed = true
                        if (!line.isOpen) break
                        continue
                    }
                    val samples = n / 2
                    for (i in 0 until samples) {
                        pcm[i] = ((bytes[2 * i].toInt() and 0xFF) or (bytes[2 * i + 1].toInt() shl 8)).toShort()
                    }
                    cap.feed(pcm, samples)
                }
            } catch (e: Exception) {
                failed = true
            } finally {
                runCatching { line?.stop() }
                runCatching { line?.close() }
                finished.complete(Unit)
            }
        }

        override suspend fun finish(): VoiceRecording? {
            stopRequested = true
            finished.await()
            val cap = capture ?: return null
            if (failed && cap.durationMs <= 0) return null
            return cap.finish()
        }

        override fun cancel() {
            cancelled = true
            stopRequested = true
            capture?.cancel()
        }
    }

    private class Player : VoicePlayer {
        private val gen = AtomicInteger(0)
        @Volatile private var line: SourceDataLine? = null
        @Volatile private var running = false
        @Volatile private var base = 0

        override val position: Int
            get() {
                val l = line ?: return base
                return base + l.longFramePosition.toInt()
            }

        override val isPlaying: Boolean get() = running

        override fun play(clip: VoiceClip, from: Int) {
            val g = gen.incrementAndGet()
            val old = line
            line = null
            base = from
            running = true
            if (old != null) quiet(old)
            Thread({ run(g, clip, from) }, "nuva-play").apply {
                isDaemon = true
                start()
            }
        }

        override fun stop() {
            gen.incrementAndGet()
            running = false
            val l = line ?: return
            line = null
            quiet(l)
        }

        private fun quiet(l: SourceDataLine) {
            Thread({ runCatching { l.stop(); l.flush() } }, "nuva-play-stop").apply {
                isDaemon = true
                start()
            }
        }

        private fun run(g: Int, clip: VoiceClip, from: Int) {
            var l: SourceDataLine? = null
            try {
                val rate = clip.sampleRate
                val fmt = format(rate)
                l = AudioSystem.getSourceDataLine(fmt).also { it.open(fmt, rate / 4 * 2) }
                if (gen.get() != g) return
                line = l
                l.start()
                val total = clip.totalSamples
                val buf = ByteArray(4096)
                var o = from
                while (gen.get() == g && o < total) {
                    val avail = clip.available(o)
                    if (avail <= 0) {
                        Thread.sleep(4)
                        continue
                    }
                    val n = minOf(buf.size / 2, avail, total - o)
                    for (i in 0 until n) {
                        val v = clip.pcm[o + i].toInt()
                        buf[2 * i] = v.toByte()
                        buf[2 * i + 1] = (v shr 8).toByte()
                    }
                    l.write(buf, 0, n * 2)
                    o += n
                }
                // drain() на остановленной линии может висеть вечно — ждём позицию с дедлайном.
                val deadline = System.currentTimeMillis() + (total - from) * 1000L / rate + 1000
                while (gen.get() == g && l.longFramePosition < total - from && System.currentTimeMillis() < deadline) {
                    Thread.sleep(10)
                }
            } catch (e: Exception) {
                // нет устройства вывода / сбой — завершаемся, UI увидит isPlaying=false
            } finally {
                if (line === l) line = null
                runCatching { l?.stop() }
                runCatching { l?.close() }
                if (gen.get() == g) running = false
            }
        }
    }

    private val RATES = intArrayOf(16_000, 48_000, 44_100)
}
