package app.nuva.desktop

import app.nuva.core.chat.IncomingNotice
import app.nuva.ui.AppGraph
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.launch
import java.awt.SystemTray
import java.awt.TrayIcon
import javax.imageio.ImageIO

/** Системные уведомления на десктопе: через значок в трее. Если трея нет (headless, часть Wayland) — молчим. */
class DesktopNotifier(private val graph: AppGraph) {
    private var tray: TrayIcon? = null

    fun start() {
        val supported = try {
            SystemTray.isSupported()
        } catch (e: Throwable) {
            false
        }
        if (!supported) return
        graph.scope.launch {
            graph.core.messenger.filterNotNull().collectLatest { m ->
                m.incoming.collect { show(it) }
            }
        }
    }

    @Synchronized
    private fun show(n: IncomingNotice) {
        try {
            val icon = tray ?: createIcon() ?: return
            icon.displayMessage(n.title, n.text, TrayIcon.MessageType.NONE)
        } catch (e: Exception) {
            // Уведомление не критично для работы мессенджера.
        }
    }

    private fun createIcon(): TrayIcon? {
        val url = DesktopNotifier::class.java.getResource("/nuva.png") ?: return null
        val icon = TrayIcon(ImageIO.read(url), "Nuva").apply { isImageAutoSize = true }
        SystemTray.getSystemTray().add(icon)
        tray = icon
        return icon
    }
}
