package app.nuva.core.voice

import io.github.jaredmdobson.concentus.OpusApplication
import io.github.jaredmdobson.concentus.OpusBandwidth
import io.github.jaredmdobson.concentus.OpusDecoder
import io.github.jaredmdobson.concentus.OpusEncoder
import io.github.jaredmdobson.concentus.OpusSignal

// ВНИМАНИЕ: этот файл побайтно одинаков в androidMain и desktopMain (Concentus — чистая Java, JVM-only,
// а общий commonMain про неё не знает). Правите здесь — правьте и во втором месте.

private class ConcentusEnc(rate: Int, bitrate: Int) : OpusEnc {
    private val enc = OpusEncoder(rate, 1, OpusApplication.OPUS_APPLICATION_VOIP).also {
        it.setBitrate(bitrate)
        it.setUseVBR(true)
        it.setSignalType(OpusSignal.OPUS_SIGNAL_VOICE)
        it.setBandwidth(OpusBandwidth.OPUS_BANDWIDTH_WIDEBAND)
        it.setMaxBandwidth(OpusBandwidth.OPUS_BANDWIDTH_WIDEBAND)
        it.setUseDTX(false)
        it.setComplexity(6)
    }
    private val out = ByteArray(1275) // максимальный размер пакета Opus

    override val lookahead: Int get() = enc.getLookahead()

    override fun encode(pcm: ShortArray, frameSamples: Int): ByteArray {
        val n = enc.encode(pcm, 0, frameSamples, out, 0, out.size)
        return out.copyOf(n)
    }

    override fun setComplexity(value: Int) {
        enc.setComplexity(value)
    }
}

private class ConcentusDec(rate: Int) : OpusDec {
    private val dec = OpusDecoder(rate, 1)

    override fun decode(packet: ByteArray, offset: Int, length: Int, out: ShortArray, maxSamples: Int): Int =
        dec.decode(packet, offset, length, out, 0, maxSamples, false)
}

internal actual fun createOpusEncoder(sampleRate: Int, bitrate: Int): OpusEnc = ConcentusEnc(sampleRate, bitrate)

internal actual fun createOpusDecoder(sampleRate: Int): OpusDec = ConcentusDec(sampleRate)
