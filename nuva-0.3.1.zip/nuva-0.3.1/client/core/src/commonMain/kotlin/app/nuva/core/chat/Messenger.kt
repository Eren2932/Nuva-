package app.nuva.core.chat

import app.cash.sqldelight.coroutines.asFlow
import app.cash.sqldelight.coroutines.mapToList
import app.cash.sqldelight.coroutines.mapToOneOrNull
import app.nuva.core.crypto.CryptoException
import app.nuva.core.crypto.NuvaCrypto
import app.nuva.core.net.HttpApi
import app.nuva.core.net.HttpResult
import app.nuva.core.net.NotConnectedException
import app.nuva.core.net.NuvaSocket
import app.nuva.core.net.isAuthed
import app.nuva.core.proto.ErrorCodes
import app.nuva.core.proto.Frames
import app.nuva.core.proto.RemoteAccount
import app.nuva.core.proto.ServerFrame
import app.nuva.core.store.Account
import app.nuva.core.util.B64
import app.nuva.core.util.Uuids
import app.nuva.core.voice.Nvo2
import app.nuva.core.voice.Nvoi
import app.nuva.core.voice.VoiceRecording
import app.nuva.db.Ctl
import app.nuva.db.Device
import app.nuva.db.Message
import app.nuva.db.NuvaDatabase
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.datetime.Clock
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.longOrNull

/**
 * Переписка 1:1 поверх store-and-forward сервера.
 *
 * Гарантии: исходящие — в локальной очереди (status=PENDING) до msg.sent, повтор идемпотентен
 * по client_msg_id; входящие — ack только ПОСЛЕ записи в БД (at-least-once + дедуп по
 * (peer, client_msg_id)).
 *
 * Служебные зашифрованные сообщения (тип в поле "t" открытого текста конверта; сервер их не отличает):
 *   text  — {body, ts, reply?:{id, own, text}}
 *   rcpt  — {ids}              доставлено на устройство
 *   read  — {ids}              реально прочитано (сообщение было на экране при открытом приложении)
 *   react — {id, own, emoji}   реакция; пустой emoji = снять
 *   del   — {ids}              «удалить у всех» (только свои сообщения отправителя)
 *   voice — {ts, vid, dur, key, wave, av?, reply?}  голосовое 0.3: vid — id блоба на сервере, key — его ключ
 *           (XChaCha20-Poly1305); сам звук (NVO2/Opus) лежит на сервере шифртекстом, см. [HttpApi].
 *           Заголовок уходит только после загрузки блоба.
 *   vchunk/voice{n} — формат 0.2.5 (кусочная отправка): принимаем, не отправляем.
 *   played — {ids}             голосовое прослушано получателем
 * "own" всегда с позиции отправителя служебного сообщения. Старые клиенты неизвестные типы молча пропускают.
 * rcpt/read/react/del/played лежат в постоянной очереди ctl и уходят, пока сервер не примет конверт.
 * Поле "av" в text/voice — версия аватарки отправителя: изменилась → получатель докачивает картинку.
 */
public class Messenger internal constructor(
    private val account: Account,
    private val db: NuvaDatabase,
    private val socket: NuvaSocket,
    private val api: HttpApi,
    private val io: CoroutineDispatcher,
    private val scope: CoroutineScope,
    private val foreground: StateFlow<Boolean>,
) {
    private val q get() = db.nuvaQueries
    private val json = Json { ignoreUnknownKeys = true }

    /** Открытый сейчас чат. «Прочитано» уходит только для него и только при [foreground]. */
    public val activeChat: MutableStateFlow<String?> = MutableStateFlow(null)

    private val _incoming = MutableSharedFlow<IncomingNotice>(extraBufferCapacity = 64)

    /** Новые входящие, пришедшие пока приложение не на экране: из них делаются системные уведомления. */
    public val incoming: SharedFlow<IncomingNotice> = _incoming.asSharedFlow()

    private val outboxKick = Channel<Unit>(Channel.CONFLATED)
    private val ctlKick = Channel<Unit>(Channel.CONFLATED)
    private val acks = Channel<Long>(Channel.UNLIMITED)
    private val uploadKick = Channel<Unit>(Channel.CONFLATED)
    private val downloadKick = Channel<Unit>(Channel.CONFLATED)
    private val avatarKick = Channel<Unit>(Channel.CONFLATED)

    private val _transfers = MutableStateFlow<Map<String, Float>>(emptyMap())

    /** Прогресс передачи голосовых по client_msg_id (0..1): загрузка своих и скачивание входящих. */
    public val transfers: StateFlow<Map<String, Float>> = _transfers.asStateFlow()

    @kotlin.concurrent.Volatile
    private var myAvatarVer: Long = 0

    @kotlin.concurrent.Volatile
    private var selfAvatarCheck: Boolean = true

    public fun start() {
        scope.launch { processDeliveries() }
        scope.launch { ackLoop() }
        scope.launch { ctlLoop() }
        scope.launch { outboxLoop() }
        scope.launch { uploadLoop() }
        scope.launch { downloadLoop() }
        scope.launch { avatarLoop() }
        scope.launch {
            myAvatarVer = withContext(io) { q.avatarFor(account.accountId).executeAsOneOrNull()?.ver ?: 0L }
            // Блобы идут по HTTP и от сокета не зависят: недокачанное и недогруженное продолжаем сразу.
            uploadKick.trySend(Unit)
            downloadKick.trySend(Unit)
        }
        scope.launch {
            socket.state.collect {
                if (it.isAuthed) {
                    selfAvatarCheck = true
                    outboxKick.trySend(Unit)
                    ctlKick.trySend(Unit)
                    uploadKick.trySend(Unit)
                    downloadKick.trySend(Unit)
                    avatarKick.trySend(Unit)
                }
            }
        }
    }

    // ─────────────── Наблюдаемые данные для UI ───────────────

    public fun chats(): Flow<List<ChatSummary>> =
        q.chatList { peerId, lastText, lastTs, lastOutgoing, lastStatus, unread, username, firstName, lastName ->
            ChatSummary(peerId, username, firstName, lastName, lastText, lastTs, lastOutgoing == 1L,
                MsgStatus.of(lastStatus), (unread ?: 0L).toInt())
        }.asFlow().mapToList(io)

    public fun messages(peerId: String, limit: Long): Flow<List<ChatMessage>> {
        val msgs = q.messagesFor(peerId, limit).asFlow().mapToList(io)
        val reacts = q.reactionsFor(peerId).asFlow().mapToList(io)
        return combine(msgs, reacts) { ml, rl ->
            val mine = HashMap<Pair<Long, String>, String>()
            val theirs = HashMap<Pair<Long, String>, String>()
            for (r in rl) (if (r.by_me == 1L) mine else theirs)[r.msg_out to r.client_msg_id] = r.emoji
            ml.map { m ->
                val key = m.outgoing to m.client_msg_id
                ChatMessage(
                    localId = m.local_id,
                    clientMsgId = m.client_msg_id,
                    outgoing = m.outgoing == 1L,
                    body = m.body,
                    ts = m.ts,
                    status = MsgStatus.of(m.status),
                    reply = m.reply_id?.let { ReplyRef(it, m.reply_out == 1L, m.reply_text) },
                    isRead = m.is_read == 1L,
                    myReaction = mine[key],
                    theirReaction = theirs[key],
                    voice = if (m.kind == KIND_VOICE && m.vid != null) VoiceInfo(
                        vid = m.vid,
                        durationMs = m.duration_ms ?: 0L,
                        wave = m.wave?.map { it.toInt() and 0xFF }.orEmpty(),
                        parts = (m.parts ?: 0L).toInt(),
                        haveParts = m.have_parts.toInt(),
                        sentParts = (m.sent_parts ?: 0L).toInt(),
                        listened = m.listened == 1L,
                        dl = (m.dl ?: 2L).toInt(),
                        uploaded = m.up == 1L,
                        blob = m.blob_key != null,
                    ) else null,
                )
            }
        }
    }

    /** Сколько сообщений новее указанного = индекс в списке «новые сверху». null — такого сообщения нет. */
    public suspend fun positionOf(peerId: String, clientMsgId: String, outgoing: Boolean): Long? = withContext(io) {
        val out = if (outgoing) 1L else 0L
        if (q.countMessage(peerId, out, clientMsgId).executeAsOne() == 0L) null
        else q.newerCount(peerId, peerId, out, clientMsgId).executeAsOne()
    }

    public fun peer(peerId: String): Flow<Peer?> =
        q.contactById(peerId) { accountId, username, firstName, lastName, identityKey, keyChanged, _, _ ->
            Peer(accountId, username, firstName, lastName, identityKey, keyChanged == 1L)
        }.asFlow().mapToOneOrNull(io)

    // ─────────────── Поиск и контакты ───────────────

    public suspend fun lookup(username: String): LookupResult {
        val name = username.trim().removePrefix("@").lowercase()
        if (!Limits.USERNAME.matches(name)) return LookupResult.NotFound
        if (!socket.state.value.isAuthed) return LookupResult.Offline
        val r = try {
            socket.request { Frames.lookupUsername(it, name) }
        } catch (e: NotConnectedException) {
            return LookupResult.Offline
        }
        return when (r) {
            is ServerFrame.UserInfo -> verified(r.account)?.let { LookupResult.Found(it) } ?: LookupResult.NotFound
            is ServerFrame.Error -> if (r.code == ErrorCodes.RATE_LIMITED) LookupResult.RateLimited else LookupResult.NotFound
            else -> LookupResult.NotFound
        }
    }

    /** «Написать»: закрепляем ключи собеседника (TOFU) и создаём чат. */
    public suspend fun openChat(remote: RemoteAccount): String {
        savePeer(remote, accept = false)
        withContext(io) { q.ensureChat(remote.accountId) }
        return remote.accountId
    }

    /** Пользователь сверил код безопасности / согласился с новым ключом собеседника. */
    public suspend fun acceptKeyChange(peerId: String): Boolean {
        val remote = fetchAccount(peerId) ?: return false
        savePeer(remote, accept = true)
        return true
    }

    public fun safetyNumber(peer: Peer): String = NuvaCrypto.safetyNumber(account.identity.ikPub, peer.identityKey)

    // ─────────────── Прочтение ───────────────

    /**
     * UI сообщает: входящие вплоть до [upToLocalId] сейчас реально на экране. Принимается, только если
     * приложение на переднем плане и именно этот чат открыт, — иначе «прочитано» не отправляется.
     */
    public suspend fun markRead(peerId: String, upToLocalId: Long) {
        if (!foreground.value || activeChat.value != peerId) return
        markReadInternal(peerId, upToLocalId)
    }

    /** Явное действие пользователя (кнопка «Прочитано» в уведомлении, ответ из уведомления). */
    public suspend fun markAllRead(peerId: String) {
        markReadInternal(peerId, null)
    }

    private suspend fun markReadInternal(peerId: String, upTo: Long?) {
        val queued = withContext(io) {
            db.transactionWithResult {
                val ids = if (upTo == null) q.unreadIncomingAll(peerId).executeAsList()
                else q.unreadIncomingUpTo(peerId, upTo).executeAsList()
                if (ids.isNotEmpty()) {
                    if (upTo == null) q.markIncomingReadAll(peerId) else q.markIncomingReadUpTo(peerId, upTo)
                    for (chunk in ids.chunked(CTL_CHUNK)) q.enqueueCtl(peerId, CTL_READ, idsPayload(chunk))
                }
                ids.isNotEmpty()
            }
        }
        if (queued) ctlKick.trySend(Unit)
    }

    // ─────────────── Реакции, удаление ───────────────

    /** Поставить реакцию; повтор той же — снимает. Для неотправленных сообщений не делает ничего. */
    public suspend fun react(peerId: String, msg: ChatMessage, emoji: String) {
        if (msg.outgoing && (msg.status == MsgStatus.PENDING || msg.status == MsgStatus.FAILED)) return
        val out = if (msg.outgoing) 1L else 0L
        val e = emoji.take(16)
        withContext(io) {
            db.transaction {
                val cur = q.reactionOf(peerId, out, msg.clientMsgId, 1L).executeAsOneOrNull()?.emoji
                val next = if (cur == e) "" else e
                if (next.isEmpty()) q.deleteReaction(peerId, out, msg.clientMsgId, 1L)
                else q.upsertReaction(peerId, out, msg.clientMsgId, 1L, next)
                q.enqueueCtl(peerId, CTL_REACT, JsonObject(linkedMapOf(
                    "id" to JsonPrimitive(msg.clientMsgId),
                    "own" to JsonPrimitive(msg.outgoing),
                    "emoji" to JsonPrimitive(next),
                )).toString())
            }
        }
        ctlKick.trySend(Unit)
    }

    /** «Удалить у меня»: только локально. */
    public suspend fun deleteForMe(peerId: String, msgs: List<ChatMessage>) {
        if (msgs.isEmpty()) return
        // Входящее, которое мы так и не скачали, сервер держит до TTL: отпускаем свою долю.
        releaseBlobs(msgs.filter { !it.outgoing }.mapNotNull { m -> m.voice?.takeIf { it.blob && it.dl <= 1 }?.vid })
        withContext(io) {
            db.transaction {
                for (m in msgs) removeMessage(peerId, m)
                refreshChatLast(peerId)
            }
        }
    }

    /** «Удалить у всех»: свои сообщения исчезают и у собеседника; чужие удаляются только у меня. */
    public suspend fun deleteForAll(peerId: String, msgs: List<ChatMessage>) {
        if (msgs.isEmpty()) return
        val remote = msgs.filter { it.outgoing && it.status != MsgStatus.PENDING && it.status != MsgStatus.FAILED }
            .map { it.clientMsgId }
        // Свои голосовые отзываем с сервера, чужие недокачанные — отпускаем.
        releaseBlobs(msgs.mapNotNull { m -> m.voice?.takeIf { it.blob && (m.outgoing || it.dl <= 1) }?.vid })
        withContext(io) {
            db.transaction {
                for (m in msgs) removeMessage(peerId, m)
                for (chunk in remote.chunked(CTL_CHUNK)) q.enqueueCtl(peerId, CTL_DEL, idsPayload(chunk))
                refreshChatLast(peerId)
            }
        }
        if (remote.isNotEmpty()) ctlKick.trySend(Unit)
    }

    /** Очистить переписку на этом устройстве (у собеседника остаётся). */
    public suspend fun clearChat(peerId: String) {
        val pending = withContext(io) {
            q.pendingVoiceDownloads().executeAsList().filter { it.peer_id == peerId }.map { it.vid }
        }
        releaseBlobs(pending)
        withContext(io) {
            db.transaction {
                q.deleteAllMessages(peerId)
                q.deleteAllReactions(peerId)
                q.deleteAllVoice(peerId)
                q.clearChatLast(peerId)
            }
        }
    }

    /** Внутри транзакции. */
    private fun removeMessage(peerId: String, m: ChatMessage) {
        val out = if (m.outgoing) 1L else 0L
        q.deleteMessage(peerId, out, m.clientMsgId)
        q.deleteReactionsOf(peerId, out, m.clientMsgId)
        deleteVoiceOf(peerId, out, m.clientMsgId)
    }

    /** Внутри транзакции: голосовое вместе со всеми кусками. Для текстовых ничего не делает. */
    private fun deleteVoiceOf(peerId: String, out: Long, cmid: String) {
        q.deleteVoiceParts(peerId, out, peerId, out, cmid)
        q.deleteVoice(peerId, out, cmid)
    }

    // ─────────────── Отправка ───────────────

    public suspend fun sendText(peerId: String, text: String, reply: ReplyRef? = null) {
        val body = text.trim().take(Limits.MAX_TEXT)
        if (body.isEmpty()) return
        val cmid = newMsgId()
        val ts = now()
        val snippet = reply?.text?.replace('\n', ' ')?.take(Limits.REPLY_SNIPPET).orEmpty()
        withContext(io) {
            db.transaction {
                q.ensureChat(peerId)
                q.insertMessage(
                    peerId, cmid, 1L, body, ts, null, MsgStatus.PENDING.code,
                    reply?.clientMsgId, if (reply?.mine == true) 1L else 0L, snippet, 1L, KIND_TEXT,
                )
                refreshChatLast(peerId)
            }
        }
        outboxKick.trySend(Unit)
    }

    /**
     * Голосовое: [rec] — готовая запись NVO2 (Opus), её собирает кодировщик прямо во время записи.
     * Запись целиком ложится в БД до отправки — после этого она не потеряется (обрыв, смерть процесса).
     * Дальше [uploadLoop] шифрует её случайным ключом, грузит блобом и только потом уходит заголовок.
     * false — запись короче [Limits.VOICE_MIN_MS] или слишком большая, ничего не отправлено.
     */
    public suspend fun sendVoice(peerId: String, rec: VoiceRecording, reply: ReplyRef? = null): Boolean {
        if (rec.durationMs < Limits.VOICE_MIN_MS || rec.durationMs > Nvoi.MAX_SECONDS * 1000L + 1000L) return false
        if (rec.data.isEmpty() || rec.data.size > Limits.BLOB_MAX_BYTES - 1024 || !Nvo2.isNvo2(rec.data)) return false
        val cmid = newMsgId()
        val vid = newMsgId()
        val key = NuvaCrypto.random(BLOB_KEY_LEN)
        val ts = now()
        val snippet = reply?.text?.replace('\n', ' ')?.take(Limits.REPLY_SNIPPET).orEmpty()
        withContext(io) {
            val parts = (rec.data.size + Limits.VOICE_STORE_CHUNK - 1) / Limits.VOICE_STORE_CHUNK
            db.transaction {
                q.ensureChat(peerId)
                q.insertMessage(
                    peerId, cmid, 1L, Limits.VOICE_LABEL, ts, null, MsgStatus.PENDING.code,
                    reply?.clientMsgId, if (reply?.mine == true) 1L else 0L, snippet, 1L, KIND_VOICE,
                )
                q.insertVoice(peerId, 1L, cmid, vid, rec.durationMs, rec.wave, parts.toLong(), key, 2L)
                for (i in 0 until parts) {
                    val from = i * Limits.VOICE_STORE_CHUNK
                    val to = minOf(rec.data.size, from + Limits.VOICE_STORE_CHUNK)
                    q.insertVoicePart(peerId, 1L, vid, i.toLong(), rec.data.copyOfRange(from, to))
                }
                refreshChatLast(peerId)
            }
        }
        uploadKick.trySend(Unit)
        outboxKick.trySend(Unit)
        return true
    }

    /** Байты голосового (NVO2 или старый NVOI); null — ещё не скачано (или сообщения нет). */
    public suspend fun voiceData(peerId: String, msg: ChatMessage): ByteArray? = withContext(io) {
        val out = if (msg.outgoing) 1L else 0L
        val v = q.voiceByKey(peerId, out, msg.clientMsgId).executeAsOneOrNull() ?: return@withContext null
        readVoice(peerId, out, v.vid, v.parts.toInt())
    }

    /** Склеивает куски из БД. Вызывать на [io]. */
    private fun readVoice(peerId: String, out: Long, vid: String, parts: Int): ByteArray? {
        if (parts <= 0) return null
        val chunks = ArrayList<ByteArray>(parts)
        for (i in 0 until parts) {
            chunks += q.voicePart(peerId, out, vid, i.toLong()).executeAsOneOrNull() ?: return null
        }
        val all = ByteArray(chunks.sumOf { it.size })
        var o = 0
        for (c in chunks) {
            c.copyInto(all, o)
            o += c.size
        }
        return all
    }

    /** Входящее голосовое начали слушать: локальная отметка + «прослушано» собеседнику. */
    public suspend fun markListened(peerId: String, msg: ChatMessage) {
        val v = msg.voice ?: return
        if (msg.outgoing || v.listened) return
        withContext(io) {
            db.transaction {
                q.setVoiceListened(peerId, 0L, listOf(msg.clientMsgId))
                q.enqueueCtl(peerId, CTL_PLAYED, idsPayload(listOf(msg.clientMsgId)))
            }
        }
        ctlKick.trySend(Unit)
    }

    public suspend fun retry(peerId: String, clientMsgId: String) {
        withContext(io) {
            db.transaction {
                q.retryFailed(peerId, clientMsgId)
                // Голосовое после сбоя грузим заново: набор устройств получателя мог смениться, а повторная
                // загрузка того же блоба сбрасывает квитанции на сервере.
                q.setVoiceUp(0L, peerId, clientMsgId)
                refreshChatLast(peerId)
            }
        }
        uploadKick.trySend(Unit)
        outboxKick.trySend(Unit)
    }

    private suspend fun outboxLoop() {
        for (kick in outboxKick) {
            if (socket.state.value.isAuthed) drainOutbox()
        }
    }

    private suspend fun drainOutbox() {
        val done = HashSet<Long>()
        while (true) {
            val batch = withContext(io) { q.pendingOutgoing().executeAsList() }.filter { it.local_id !in done }
            if (batch.isEmpty()) return
            for (m in batch) {
                done += m.local_id
                val reply = m.reply_id?.let { ReplyRef(it, m.reply_out == 1L, m.reply_text) }
                val r = if (m.kind == KIND_VOICE) deliverVoice(m, reply)
                else deliverEncrypted(m.peer_id, m.client_msg_id, textPlaintext(m.ts, m.body, reply))
                when (r) {
                    is SendResult.Sent -> withContext(io) {
                        db.transaction {
                            q.setSent(r.serverTs, m.peer_id, m.client_msg_id)
                            refreshChatLast(m.peer_id)
                        }
                    }
                    SendResult.NotFound, is SendResult.Rejected -> withContext(io) {
                        db.transaction {
                            q.setFailed(m.peer_id, m.client_msg_id)
                            refreshChatLast(m.peer_id)
                        }
                    }
                    SendResult.RateLimited -> {
                        scope.launch { delay(10_000); outboxKick.trySend(Unit) }
                        return
                    }
                    SendResult.Deferred -> Unit
                    SendResult.Offline -> return // повторим при следующем входе (state → authed)
                }
            }
        }
    }

    /** Заголовок голосового: уходит, когда блоб уже на сервере. Один маленький конверт на устройство. */
    private suspend fun deliverVoice(m: Message, reply: ReplyRef?): SendResult {
        val v = withContext(io) { q.voiceByKey(m.peer_id, 1L, m.client_msg_id).executeAsOneOrNull() }
            ?: return SendResult.Rejected("voice_missing")
        val key = v.blob_key
        if (key == null || v.up != 1L) {
            uploadKick.trySend(Unit)
            return SendResult.Deferred
        }
        return deliverEncrypted(m.peer_id, m.client_msg_id, voicePlaintext(m.ts, v.vid, v.duration_ms, key, v.wave, reply))
    }

    private sealed interface SendResult {
        class Sent(val serverTs: Long) : SendResult
        data object NotFound : SendResult
        data object RateLimited : SendResult
        data object Offline : SendResult
        /** Голосовое ещё грузится: заголовок уйдёт после загрузки блоба, очередь не блокируем. */
        data object Deferred : SendResult
        class Rejected(val code: String) : SendResult
    }

    /** Шифрует под каждое активное устройство получателя; при devices_mismatch обновляет список и повторяет. */
    private suspend fun deliverEncrypted(peerId: String, cmid: String, plaintext: ByteArray): SendResult {
        var devices = withContext(io) { q.devicesFor(peerId).executeAsList() }
        if (devices.isEmpty()) devices = refreshPeer(peerId) ?: return SendResult.Offline
        repeat(2) {
            if (devices.isEmpty()) return SendResult.NotFound
            val envelopes = devices.map { d ->
                d.device_id to NuvaCrypto.seal(
                    account.identity.xkPriv, d.x25519_key, account.deviceId, d.device_id, cmid, plaintext,
                )
            }
            val r = try {
                socket.request { id -> Frames.msgSend(id, peerId, cmid, envelopes) }
            } catch (e: NotConnectedException) {
                return SendResult.Offline
            }
            when (r) {
                is ServerFrame.MsgSent -> return SendResult.Sent(r.serverTs)
                is ServerFrame.Error -> when (r.code) {
                    ErrorCodes.DEVICES_MISMATCH -> devices = refreshPeer(peerId) ?: return SendResult.Offline
                    ErrorCodes.NOT_FOUND -> return SendResult.NotFound
                    ErrorCodes.RATE_LIMITED -> return SendResult.RateLimited
                    else -> return SendResult.Rejected(r.code)
                }
                else -> return SendResult.Rejected("unexpected")
            }
        }
        return SendResult.Rejected(ErrorCodes.DEVICES_MISMATCH)
    }

    // ─────────────── Приём ───────────────

    private suspend fun processDeliveries() {
        for (d in socket.deliveries) {
            try {
                handleDeliver(d)
            } catch (e: CancellationException) {
                throw e
            } catch (e: NotConnectedException) {
                // без ack: сервер выдаст конверт повторно при следующем входе
            } catch (e: Exception) {
                acks.send(d.serverId) // «ядовитый» конверт не должен блокировать очередь вечно
            }
        }
    }

    private suspend fun handleDeliver(d: ServerFrame.Deliver) {
        val from = d.fromAccount
        val fromDevice = d.fromDevice
        if (from == null || fromDevice == null || fromDevice == account.deviceId) {
            acks.send(d.serverId)
            return
        }
        val plain = openFrom(from, fromDevice, d) ?: run {
            acks.send(d.serverId)
            return
        }
        val obj = try {
            json.parseToJsonElement(plain.decodeToString()).jsonObject
        } catch (e: Exception) {
            null
        }
        when ((obj?.get("t") as? JsonPrimitive)?.contentOrNull) {
            "text" -> {
                val body = (obj!!["body"] as? JsonPrimitive)?.contentOrNull.orEmpty().take(Limits.MAX_TEXT * 4)
                val sentTs = (obj["ts"] as? JsonPrimitive)?.longOrNull
                val ts = if (sentTs == null || sentTs <= 0 || sentTs > now() + DAY_MS) d.serverTs else sentTs
                if (body.isNotEmpty()) {
                    noteAvatar(from, obj)
                    storeIncoming(from, d.clientMsgId, body, ts, d.serverTs, parseReply(obj))
                }
            }
            "rcpt" -> {
                val ids = idList(obj!!)
                if (ids.isNotEmpty()) withContext(io) {
                    db.transaction {
                        q.markDelivered(from, ids)
                        refreshChatLast(from)
                    }
                }
            }
            "read" -> {
                val ids = idList(obj!!)
                if (ids.isNotEmpty()) withContext(io) {
                    db.transaction {
                        q.markReadByPeer(from, ids)
                        refreshChatLast(from)
                    }
                }
            }
            "react" -> {
                val id = (obj!!["id"] as? JsonPrimitive)?.contentOrNull
                if (!id.isNullOrEmpty() && id.length <= 64) {
                    // "own" с позиции реагирующего: его сообщение = для меня входящее (msg_out = 0).
                    val msgOut = if ((obj["own"] as? JsonPrimitive)?.booleanOrNull == true) 0L else 1L
                    val emoji = (obj["emoji"] as? JsonPrimitive)?.contentOrNull.orEmpty().take(16)
                    withContext(io) {
                        db.transaction {
                            if (q.countMessage(from, msgOut, id).executeAsOne() > 0L) {
                                if (emoji.isEmpty()) q.deleteReaction(from, msgOut, id, 0L)
                                else q.upsertReaction(from, msgOut, id, 0L, emoji)
                            }
                        }
                    }
                }
            }
            "vchunk" -> {
                val o = obj!!
                val vid = (o["vid"] as? JsonPrimitive)?.contentOrNull
                val i = (o["i"] as? JsonPrimitive)?.longOrNull
                val n = (o["n"] as? JsonPrimitive)?.longOrNull
                val data = (o["d"] as? JsonPrimitive)?.contentOrNull?.let { runCatching { B64.decode(it) }.getOrNull() }
                if (!vid.isNullOrEmpty() && vid.length <= 64 && n != null && n in 1..Limits.VOICE_MAX_PARTS.toLong() &&
                    i != null && i in 0 until n && data != null && data.isNotEmpty() && data.size <= Limits.VOICE_PART_BYTES
                ) {
                    withContext(io) { q.insertVoicePart(from, 0L, vid, i, data) }
                }
            }
            "voice" -> {
                val o = obj!!
                val vid = (o["vid"] as? JsonPrimitive)?.contentOrNull
                val n = (o["n"] as? JsonPrimitive)?.longOrNull
                val dur = (o["dur"] as? JsonPrimitive)?.longOrNull
                val key = (o["key"] as? JsonPrimitive)?.contentOrNull
                    ?.let { runCatching { B64.decode(it) }.getOrNull() }?.takeIf { it.size == BLOB_KEY_LEN }
                val hasKey = o["key"] != null
                val okId = !vid.isNullOrEmpty() && vid.length <= 64
                // 0.3: блоб (vid — UUID, он идёт в путь запроса, поэтому строго проверяем); 0.2.5: куски (n).
                val okKind = if (hasKey) key != null && Uuids.isValid(vid.orEmpty())
                else n != null && n in 1..Limits.VOICE_MAX_PARTS.toLong()
                if (okId && okKind && dur != null && dur in 1..Nvoi.MAX_SECONDS * 1000L) {
                    val wave = (o["wave"] as? JsonPrimitive)?.contentOrNull
                        ?.let { runCatching { B64.decode(it) }.getOrNull() }
                        ?.takeIf { it.size <= 256 } ?: ByteArray(0)
                    val sentTs = (o["ts"] as? JsonPrimitive)?.longOrNull
                    val ts = if (sentTs == null || sentTs <= 0 || sentTs > now() + DAY_MS) d.serverTs else sentTs
                    noteAvatar(from, o)
                    storeIncoming(from, d.clientMsgId, Limits.VOICE_LABEL, ts, d.serverTs, parseReply(o),
                        IncomingVoice(vid.orEmpty(), dur, wave, if (hasKey) 0L else n ?: 0L, key))
                }
            }
            "played" -> {
                val ids = idList(obj!!)
                if (ids.isNotEmpty()) withContext(io) { q.setVoiceListened(from, 1L, ids) }
            }
            "del" -> {
                // Собеседник может удалить только свои сообщения: ищем среди входящих от него.
                val ids = idList(obj!!)
                if (ids.isNotEmpty()) withContext(io) {
                    db.transaction {
                        for (id in ids) {
                            q.deleteMessage(from, 0L, id)
                            q.deleteReactionsOf(from, 0L, id)
                            deleteVoiceOf(from, 0L, id)
                        }
                        refreshChatLast(from)
                    }
                }
            }
            else -> Unit // неизвестный тип из будущей версии — молча пропускаем
        }
        acks.send(d.serverId)
    }

    private fun parseReply(obj: JsonObject): ReplyRef? = (obj["reply"] as? JsonObject)?.let { r ->
        val rid = (r["id"] as? JsonPrimitive)?.contentOrNull
        if (rid.isNullOrEmpty() || rid.length > 64) null
        else ReplyRef(
            clientMsgId = rid,
            // "own" — с позиции отправителя: цитируется его сообщение = для меня оно «чужое».
            mine = (r["own"] as? JsonPrimitive)?.booleanOrNull != true,
            text = (r["text"] as? JsonPrimitive)?.contentOrNull.orEmpty().take(Limits.REPLY_SNIPPET * 2),
        )
    }

    private class IncomingVoice(val vid: String, val durationMs: Long, val wave: ByteArray, val parts: Long, val key: ByteArray?)

    /** Ключи отправителя: из кэша; если устройство незнакомо или ключ сменился — свежий lookup. */
    private suspend fun openFrom(from: String, fromDevice: String, d: ServerFrame.Deliver): ByteArray? {
        suspend fun device(): Device? = withContext(io) { q.deviceById(fromDevice).executeAsOneOrNull() }
            ?.takeIf { it.account_id == from }

        fun tryOpen(dev: Device): ByteArray? = try {
            NuvaCrypto.open(account.identity.xkPriv, dev.x25519_key, fromDevice, account.deviceId, d.clientMsgId, d.envelope)
        } catch (e: CryptoException) {
            null
        }

        device()?.let { dev -> tryOpen(dev)?.let { return it } }
        refreshPeer(from) ?: throw NotConnectedException()
        return device()?.let { tryOpen(it) }
    }

    private suspend fun storeIncoming(
        from: String, cmid: String, body: String, ts: Long, serverTs: Long, reply: ReplyRef?,
        voice: IncomingVoice? = null,
    ) {
        val inserted = withContext(io) {
            db.transactionWithResult {
                q.ensureChat(from)
                if (q.countMessage(from, 0L, cmid).executeAsOne() == 0L) {
                    q.insertMessage(
                        from, cmid, 0L, body, ts, serverTs, MsgStatus.INCOMING.code,
                        reply?.clientMsgId, if (reply?.mine == true) 1L else 0L, reply?.text.orEmpty(), 0L,
                        if (voice != null) KIND_VOICE else KIND_TEXT,
                    )
                    if (voice != null) {
                        q.insertVoice(from, 0L, cmid, voice.vid, voice.durationMs, voice.wave, voice.parts, voice.key,
                            if (voice.key != null) 0L else 2L)
                    }
                    // Квитанция «доставлено» кладётся в очередь в той же транзакции, что и сообщение.
                    q.enqueueCtl(from, CTL_RCPT, idsPayload(listOf(cmid)))
                    refreshChatLast(from)
                    true
                } else {
                    false
                }
            }
        }
        if (!inserted) return
        ctlKick.trySend(Unit)
        if (voice?.key != null) downloadKick.trySend(Unit)
        // Приложение на экране — сообщение и так видно (бейдж, чат). Уведомление нужно только в фоне.
        if (!foreground.value) {
            val c = withContext(io) { q.contactById(from).executeAsOneOrNull() }
            val title = if (c == null) "Nuva" else displayName(c.first_name, c.last_name, c.username)
            _incoming.tryEmit(IncomingNotice(from, title, if (voice != null) "🎤 $body" else body, ts))
        }
    }

    private suspend fun ackLoop() {
        val buf = ArrayList<Long>()
        while (true) {
            buf += acks.receive()
            withTimeoutOrNull(300) { while (buf.size < 100) buf += acks.receive() }
            socket.sendNoReply(Frames.msgAck(buf.toList())) // нет связи — сервер передоставит, дедуп спасёт
            buf.clear()
        }
    }

    // ─────────────── Очередь служебных сообщений ───────────────

    private suspend fun ctlLoop() {
        for (kick in ctlKick) {
            delay(250) // пачка квитанций за раз уходит одним конвертом
            if (socket.state.value.isAuthed) drainCtl()
        }
    }

    private class CtlOut(val peer: String, val plain: ByteArray, val rowIds: List<Long>)

    private suspend fun drainCtl() {
        while (socket.state.value.isAuthed) {
            val rows = withContext(io) { q.pendingCtl().executeAsList() }
            if (rows.isEmpty()) return
            val junk = ArrayList<Long>()
            val outs = buildCtlOuts(rows, junk)
            if (junk.isNotEmpty()) withContext(io) { q.deleteCtl(junk) }
            if (outs.isEmpty()) continue
            for (o in outs) {
                when (deliverEncrypted(o.peer, newMsgId(), o.plain)) {
                    // Принято, собеседника уже нет или сервер отверг конверт — строка своё отработала.
                    is SendResult.Sent, SendResult.NotFound, is SendResult.Rejected ->
                        withContext(io) { q.deleteCtl(o.rowIds) }
                    SendResult.RateLimited -> {
                        scope.launch { delay(10_000); ctlKick.trySend(Unit) }
                        return
                    }
                    SendResult.Deferred -> Unit
                    SendResult.Offline -> return
                }
            }
        }
    }

    /** rcpt/read/del/played одного собеседника склеиваются в один конверт (пачками по [CTL_CHUNK]); react — по одному. */
    private fun buildCtlOuts(rows: List<Ctl>, junk: MutableList<Long>): List<CtlOut> {
        val outs = ArrayList<CtlOut>()
        val merged = LinkedHashMap<Pair<String, String>, Pair<LinkedHashSet<String>, ArrayList<Long>>>()
        for (r in rows) {
            val o = try {
                json.parseToJsonElement(r.payload).jsonObject
            } catch (e: Exception) {
                junk += r.id
                continue
            }
            when (r.kind) {
                CTL_RCPT, CTL_READ, CTL_DEL, CTL_PLAYED -> {
                    val slot = merged.getOrPut(r.peer_id to r.kind) { LinkedHashSet<String>() to ArrayList<Long>() }
                    slot.first += idList(o)
                    slot.second += r.id
                }
                CTL_REACT -> {
                    val id = (o["id"] as? JsonPrimitive)?.contentOrNull
                    if (id == null) {
                        junk += r.id
                    } else {
                        val plain = JsonObject(linkedMapOf(
                            "v" to JsonPrimitive(1), "t" to JsonPrimitive("react"), "ts" to JsonPrimitive(now()),
                            "id" to JsonPrimitive(id),
                            "own" to (o["own"] ?: JsonPrimitive(false)),
                            "emoji" to (o["emoji"] ?: JsonPrimitive("")),
                        )).toString().encodeToByteArray()
                        outs += CtlOut(r.peer_id, plain, listOf(r.id))
                    }
                }
                else -> junk += r.id
            }
        }
        for ((key, slot) in merged) {
            val (peer, kind) = key
            val ids = slot.first.toList()
            if (ids.isEmpty()) {
                junk += slot.second
                continue
            }
            val chunks = ids.chunked(CTL_CHUNK)
            chunks.forEachIndexed { i, chunk ->
                // Строки удаляем вместе с последним конвертом: до этого они остаются в очереди.
                val rowIds = if (i == chunks.lastIndex) slot.second else emptyList()
                outs += CtlOut(peer, idsPlaintext(kind, chunk), rowIds)
            }
        }
        return outs
    }

    // ─────────────── Синхронизация ключей собеседника ───────────────

    /** null — нет связи; пустой список — аккаунта больше нет. */
    private suspend fun refreshPeer(peerId: String): List<Device>? {
        val remote = try {
            fetchAccountOrThrow(peerId)
        } catch (e: NotConnectedException) {
            return null
        }
        if (remote == null) {
            withContext(io) { q.deleteDevices(peerId) }
            return emptyList()
        }
        savePeer(remote, accept = false)
        return withContext(io) { q.devicesFor(peerId).executeAsList() }
    }

    private suspend fun fetchAccount(peerId: String): RemoteAccount? = try {
        fetchAccountOrThrow(peerId)
    } catch (e: NotConnectedException) {
        null
    }

    private suspend fun fetchAccountOrThrow(peerId: String): RemoteAccount? =
        when (val r = socket.request { Frames.lookupAccount(it, peerId) }) {
            is ServerFrame.UserInfo -> verified(r.account)
            is ServerFrame.Error -> if (r.code == ErrorCodes.NOT_FOUND) null else throw NotConnectedException(r.code)
            else -> throw NotConnectedException("unexpected")
        }

    /** Оставляем только устройства с валидной подписью X25519-ключа их identity-ключом. */
    private fun verified(a: RemoteAccount): RemoteAccount? {
        val ok = a.devices.filter { d ->
            d.identityKey.size == 32 && d.x25519Key.size == 32 &&
                NuvaCrypto.verify(d.identityKey, NuvaCrypto.xkPayload(d.x25519Key), d.x25519Sig)
        }
        if (ok.isEmpty() || !Uuids.isValid(a.accountId) || ok.any { !Uuids.isValid(it.deviceId) }) return null
        return RemoteAccount(a.accountId, a.username, a.firstName, a.lastName, ok, a.avatarVer)
    }

    private suspend fun savePeer(remote: RemoteAccount, accept: Boolean) {
        val primary = remote.devices.first().identityKey
        withContext(io) {
            db.transaction {
                val existing = q.contactById(remote.accountId).executeAsOneOrNull()
                val changed = !accept && existing != null &&
                    (existing.key_changed == 1L || !existing.identity_key.contentEquals(primary))
                val pinned = if (existing == null || accept) primary else existing.identity_key
                q.upsertContact(remote.accountId, remote.username, remote.firstName, remote.lastName,
                    pinned, if (changed) 1L else 0L, now(), remote.avatarVer)
                q.deleteDevices(remote.accountId)
                for (d in remote.devices) q.insertDevice(d.deviceId, remote.accountId, d.identityKey, d.x25519Key)
            }
        }
        avatarKick.trySend(Unit)
    }

    // ─────────────── Блобы: голосовые по HTTP ───────────────

    private fun setProgress(key: String, done: Long, total: Long) {
        val f = if (total > 0) (done.toFloat() / total).coerceIn(0f, 1f) else 0f
        _transfers.update { cur ->
            val old = cur[key]
            if (old != null && f < 1f && kotlin.math.abs(old - f) < 0.02f) cur else cur + (key to f)
        }
    }

    private fun clearProgress(key: String) {
        _transfers.update { it - key }
    }

    /** Сообщение удалили, а блоб ещё на сервере: освобождаем его, не дожидаясь TTL. Best-effort. */
    private fun releaseBlobs(vids: List<String>) {
        val ids = vids.filter { Uuids.isValid(it) }.distinct()
        if (ids.isEmpty()) return
        scope.launch { for (id in ids) api.ackBlob(id) }
    }

    /**
     * Загрузка исходящих голосовых — отдельный цикл, не [outboxLoop]: пока грузится запись на несколько
     * мегабайт, обычные сообщения уходят без задержки. Заголовок голосового отправит outboxLoop
     * (его будит завершение загрузки).
     */
    private suspend fun uploadLoop() {
        var backoff = RETRY_MIN_MS
        for (kick in uploadKick) {
            while (true) {
                val rows = withContext(io) { q.pendingVoiceUploads().executeAsList() }
                if (rows.isEmpty()) {
                    backoff = RETRY_MIN_MS
                    break
                }
                var wait: Long? = null
                for (row in rows) {
                    wait = uploadOne(row.peer_id, row.client_msg_id, row.vid, row.blob_key, row.parts)
                    if (wait != null) break
                }
                if (wait != null) {
                    val ms = if (wait == 0L) backoff else wait
                    backoff = minOf(backoff * 2, RETRY_MAX_MS)
                    scope.launch { delay(ms); uploadKick.trySend(Unit) }
                    break
                }
            }
        }
    }

    /** null — запись обработана (загружена либо окончательно провалена); иначе пауза до повтора, 0 — по умолчанию. */
    private suspend fun uploadOne(peerId: String, cmid: String, vid0: String, key0: ByteArray?, parts: Long): Long? {
        val legacy = key0 == null || key0.size != BLOB_KEY_LEN
        // Голосовое 0.2.5, не успевшее уйти: те же данные, но новый id блоба и ключ.
        val vid: String = if (legacy) newMsgId() else vid0
        val key: ByteArray = if (legacy || key0 == null) NuvaCrypto.random(BLOB_KEY_LEN) else key0
        if (legacy) {
            withContext(io) {
                db.transaction {
                    q.renameVoiceParts(vid, peerId, vid0)
                    q.setVoiceBlob(vid, key, peerId, cmid)
                }
            }
        }
        val plain = withContext(io) { readVoice(peerId, 1L, vid, parts.toInt()) }
        if (plain == null || plain.size > Limits.BLOB_MAX_BYTES - 1024) {
            failOutgoing(peerId, cmid)
            return null
        }
        val sealed = withContext(io) { NuvaCrypto.sealBlob(vid, plain, key) }
        setProgress(cmid, 0, 1)
        val r = try {
            api.putBlob(vid, peerId, sealed.data) { done, total -> setProgress(cmid, done, total) }
        } finally {
            clearProgress(cmid)
        }
        return when (r) {
            is HttpResult.Ok -> {
                withContext(io) { q.setVoiceUp(1L, peerId, cmid) }
                outboxKick.trySend(Unit)
                null
            }
            HttpResult.RateLimited -> 10_000L
            HttpResult.Offline -> 0L
            HttpResult.NotFound, HttpResult.NotModified -> {
                failOutgoing(peerId, cmid) // получателя нет
                null
            }
            is HttpResult.Rejected ->
                if (r.status == 401 || r.status == 408 || r.code == "disk_full") 0L
                else {
                    failOutgoing(peerId, cmid)
                    null
                }
        }
    }

    private suspend fun failOutgoing(peerId: String, cmid: String) {
        withContext(io) {
            db.transaction {
                q.setFailed(peerId, cmid)
                refreshChatLast(peerId)
            }
        }
    }

    /** Автоскачивание входящих голосовых: блоб → расшифровка → куски в БД → квитанция серверу. */
    private suspend fun downloadLoop() {
        var backoff = RETRY_MIN_MS
        for (kick in downloadKick) {
            while (true) {
                val rows = withContext(io) { q.pendingVoiceDownloads().executeAsList() }
                if (rows.isEmpty()) {
                    backoff = RETRY_MIN_MS
                    break
                }
                var wait: Long? = null
                for (row in rows) {
                    wait = downloadOne(row.peer_id, row.client_msg_id, row.vid, row.blob_key, row.dl)
                    if (wait != null) break
                }
                if (wait != null) {
                    val ms = if (wait == 0L) backoff else wait
                    backoff = minOf(backoff * 2, RETRY_MAX_MS)
                    scope.launch { delay(ms); downloadKick.trySend(Unit) }
                    break
                }
            }
        }
    }

    private suspend fun setDl(peerId: String, cmid: String, dl: Long) {
        withContext(io) { q.setVoiceDl(dl, peerId, cmid) }
    }

    private fun looksLikeVoice(d: ByteArray): Boolean =
        if (Nvo2.isNvo2(d)) Nvo2.durationMs(d) != null else Nvoi.header(d) != null

    private suspend fun downloadOne(peerId: String, cmid: String, vid: String, key: ByteArray?, dl: Long): Long? {
        if (key == null || key.size != BLOB_KEY_LEN || !Uuids.isValid(vid)) {
            setDl(peerId, cmid, 3L)
            return null
        }
        if (dl == 0L) {
            setProgress(cmid, 0, 1)
            val res = try {
                api.getBlob(vid) { done, total -> setProgress(cmid, done, total) }
            } finally {
                clearProgress(cmid)
            }
            when (res) {
                is HttpResult.Ok -> {
                    val plain = try {
                        withContext(io) { NuvaCrypto.openBlob(vid, key, res.value) }
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        null
                    }
                    if (plain == null || !looksLikeVoice(plain)) {
                        setDl(peerId, cmid, 3L) // повреждено/подменено: повторять бессмысленно
                        api.ackBlob(vid)
                        return null
                    }
                    withContext(io) {
                        db.transaction {
                            // Сообщение могли удалить, пока качалось: тогда куски никому не нужны.
                            if (q.voiceByKey(peerId, 0L, cmid).executeAsOneOrNull() != null) {
                                val n = (plain.size + Limits.VOICE_STORE_CHUNK - 1) / Limits.VOICE_STORE_CHUNK
                                for (i in 0 until n) {
                                    val from = i * Limits.VOICE_STORE_CHUNK
                                    val to = minOf(plain.size, from + Limits.VOICE_STORE_CHUNK)
                                    q.insertVoicePart(peerId, 0L, vid, i.toLong(), plain.copyOfRange(from, to))
                                }
                                q.setVoiceDownloaded(n.toLong(), peerId, cmid)
                            }
                        }
                    }
                }
                HttpResult.NotFound, HttpResult.NotModified -> {
                    setDl(peerId, cmid, 3L) // истёк TTL или отозван отправителем
                    return null
                }
                HttpResult.RateLimited -> return 10_000L
                HttpResult.Offline -> return 0L
                is HttpResult.Rejected -> {
                    if (res.status == 401 || res.status == 408) return 0L
                    if (res.status in 500..599) return 0L
                    setDl(peerId, cmid, 3L)
                    return null
                }
            }
        }
        // Квитанция: когда её пришлют все устройства получателя, сервер удалит блоб.
        return when (val r = api.ackBlob(vid)) {
            is HttpResult.Ok, HttpResult.NotFound, HttpResult.NotModified -> {
                setDl(peerId, cmid, 2L)
                null
            }
            HttpResult.RateLimited -> 10_000L
            HttpResult.Offline -> 0L
            is HttpResult.Rejected -> if (r.status == 401 || r.status == 408 || r.status >= 500) 0L else {
                setDl(peerId, cmid, 2L)
                null
            }
        }
    }

    // ─────────────── Аватарки ───────────────

    /** Аватарка аккаунта (своего или собеседника); null — нет. Кэшируется в БД, пока версия не изменится. */
    public fun avatar(accountId: String): Flow<AvatarImage?> =
        q.avatarFor(accountId).asFlow().mapToOneOrNull(io).map { row -> row?.let { r -> r.jpeg?.let { d -> AvatarImage(r.ver, d) } } }

    /** Своя аватарка. */
    public val myAvatar: Flow<AvatarImage?> get() = avatar(account.accountId)

    private fun isJpeg(d: ByteArray): Boolean =
        d.size in 4..Limits.AVATAR_MAX_BYTES && d[0] == 0xFF.toByte() && d[1] == 0xD8.toByte() && d[2] == 0xFF.toByte()

    /** Загрузить свою аватарку: [jpeg] — уже обрезанный и сжатый квадрат (см. [Limits.AVATAR_SIDE]). */
    public suspend fun setAvatar(jpeg: ByteArray): AvatarResult {
        if (!isJpeg(jpeg)) return AvatarResult.INVALID
        return when (val r = api.putAvatar(jpeg)) {
            is HttpResult.Ok -> {
                saveOwnAvatar(r.value, jpeg)
                AvatarResult.OK
            }
            HttpResult.Offline -> AvatarResult.OFFLINE
            HttpResult.RateLimited -> AvatarResult.RATE_LIMITED
            HttpResult.NotFound, HttpResult.NotModified -> AvatarResult.REJECTED
            is HttpResult.Rejected -> if (r.status in 500..599 || r.status == 401) AvatarResult.OFFLINE else AvatarResult.REJECTED
        }
    }

    public suspend fun removeAvatar(): AvatarResult =
        when (val r = api.deleteAvatar()) {
            is HttpResult.Ok -> {
                saveOwnAvatar(r.value, null)
                AvatarResult.OK
            }
            HttpResult.Offline -> AvatarResult.OFFLINE
            HttpResult.RateLimited -> AvatarResult.RATE_LIMITED
            HttpResult.NotFound, HttpResult.NotModified -> AvatarResult.OK // и так нет
            is HttpResult.Rejected -> if (r.status in 500..599 || r.status == 401) AvatarResult.OFFLINE else AvatarResult.REJECTED
        }

    private suspend fun saveOwnAvatar(ver: Long, data: ByteArray?) {
        withContext(io) { q.upsertAvatar(account.accountId, ver, data) }
        myAvatarVer = ver
    }

    /** Из text/voice пришла версия аватарки отправителя: новее нашей — докачиваем. */
    private suspend fun noteAvatar(from: String, obj: JsonObject?) {
        val av = (obj?.get("av") as? JsonPrimitive)?.longOrNull ?: return
        if (av <= 0 || av > 1_000_000_000L) return
        val changed = withContext(io) {
            val c = q.contactById(from).executeAsOneOrNull()
            if (c != null && av > c.avatar_ver) {
                q.setContactAvatarVer(av, from)
                true
            } else false
        }
        if (changed) avatarKick.trySend(Unit)
    }

    private suspend fun avatarLoop() {
        var backoff = RETRY_MIN_MS
        for (kick in avatarKick) {
            var wait: Long? = null
            if (selfAvatarCheck && socket.state.value.isAuthed) {
                wait = syncOwnAvatar()
                if (wait == null) selfAvatarCheck = false
            }
            if (wait == null) {
                val skip = HashSet<String>()
                while (true) {
                    val stale = withContext(io) { q.staleAvatars().executeAsList() }.filter { it.account_id !in skip }
                    if (stale.isEmpty()) break
                    for (c in stale) {
                        skip += c.account_id
                        wait = fetchAvatar(c.account_id, c.avatar_ver, c.have_ver ?: 0L)
                        if (wait != null) break
                    }
                    if (wait != null) break
                }
            }
            if (wait != null) {
                val ms = if (wait == 0L) backoff else wait
                backoff = minOf(backoff * 2, RETRY_MAX_MS)
                scope.launch { delay(ms); avatarKick.trySend(Unit) }
            } else backoff = RETRY_MIN_MS
        }
    }

    /** null — готово; иначе пауза до повтора (0 — по умолчанию). */
    private suspend fun fetchAvatar(accountId: String, wantVer: Long, haveVer: Long): Long? {
        return when (val r = api.getAvatar(accountId, haveVer.takeIf { it > 0 })) {
            is HttpResult.Ok -> {
                val p = r.value
                if (isJpeg(p.data)) {
                    withContext(io) {
                        db.transaction {
                            q.upsertAvatar(accountId, p.ver, p.data)
                            if (p.ver != wantVer) q.setContactAvatarVer(p.ver, accountId)
                        }
                    }
                } else {
                    // Мусор вместо картинки: запоминаем версию, чтобы не качать по кругу.
                    withContext(io) { q.upsertAvatar(accountId, wantVer, null) }
                }
                null
            }
            HttpResult.NotFound -> {
                withContext(io) { q.upsertAvatar(accountId, wantVer, null) }
                null
            }
            HttpResult.NotModified -> {
                withContext(io) { q.setContactAvatarVer(haveVer, accountId) }
                null
            }
            HttpResult.RateLimited -> 10_000L
            HttpResult.Offline -> 0L
            is HttpResult.Rejected -> if (r.status == 401 || r.status == 408 || r.status >= 500) 0L else {
                withContext(io) { q.upsertAvatar(accountId, wantVer, null) }
                null
            }
        }
    }

    /** Свой аккаунт мог поменять аватарку с другого устройства: сверяем версию с сервером после входа. */
    private suspend fun syncOwnAvatar(): Long? {
        val fetched: RemoteAccount? = try {
            fetchAccountOrThrow(account.accountId)
        } catch (e: NotConnectedException) {
            return 0L
        }
        val remote = fetched ?: return null
        val have = withContext(io) { q.avatarFor(account.accountId).executeAsOneOrNull() }
        val haveVer = have?.ver ?: 0L
        if (haveVer == remote.avatarVer) {
            myAvatarVer = haveVer
            return null
        }
        return when (val r = api.getAvatar(account.accountId, haveVer.takeIf { it > 0 })) {
            is HttpResult.Ok -> {
                if (isJpeg(r.value.data)) saveOwnAvatar(r.value.ver, r.value.data)
                null
            }
            HttpResult.NotFound -> {
                saveOwnAvatar(remote.avatarVer, null)
                null
            }
            HttpResult.NotModified -> {
                myAvatarVer = haveVer
                null
            }
            HttpResult.RateLimited -> 10_000L
            HttpResult.Offline -> 0L
            is HttpResult.Rejected -> if (r.status == 401 || r.status == 408 || r.status >= 500) 0L else null
        }
    }

    // ─────────────── helpers ───────────────

    /** Вызывать внутри транзакции. Сообщений не осталось — текст в списке чатов очищается. */
    private fun refreshChatLast(peerId: String) {
        val m = q.lastMessage(peerId).executeAsOneOrNull()
        if (m == null) {
            q.clearChatLast(peerId)
            return
        }
        q.setChatLast(m.body, m.ts, m.outgoing, m.status, peerId)
    }

    private fun textPlaintext(ts: Long, body: String, reply: ReplyRef?): ByteArray {
        val m = linkedMapOf<String, kotlinx.serialization.json.JsonElement>(
            "v" to JsonPrimitive(1), "t" to JsonPrimitive("text"), "ts" to JsonPrimitive(ts), "body" to JsonPrimitive(body),
        )
        if (reply != null) {
            m["reply"] = JsonObject(linkedMapOf(
                "id" to JsonPrimitive(reply.clientMsgId),
                "own" to JsonPrimitive(reply.mine), // с позиции отправителя = меня
                "text" to JsonPrimitive(reply.text),
            ))
        }
        if (myAvatarVer > 0) m["av"] = JsonPrimitive(myAvatarVer)
        return JsonObject(m).toString().encodeToByteArray()
    }

    private fun voicePlaintext(
        ts: Long, vid: String, durationMs: Long, key: ByteArray, wave: ByteArray, reply: ReplyRef?,
    ): ByteArray {
        val m = linkedMapOf<String, kotlinx.serialization.json.JsonElement>(
            "v" to JsonPrimitive(1), "t" to JsonPrimitive("voice"), "ts" to JsonPrimitive(ts),
            "vid" to JsonPrimitive(vid), "dur" to JsonPrimitive(durationMs), "key" to JsonPrimitive(B64.encode(key)),
            "wave" to JsonPrimitive(B64.encode(wave)),
        )
        if (reply != null) {
            m["reply"] = JsonObject(linkedMapOf(
                "id" to JsonPrimitive(reply.clientMsgId),
                "own" to JsonPrimitive(reply.mine),
                "text" to JsonPrimitive(reply.text),
            ))
        }
        if (myAvatarVer > 0) m["av"] = JsonPrimitive(myAvatarVer)
        return JsonObject(m).toString().encodeToByteArray()
    }

    private fun idsPlaintext(kind: String, ids: List<String>): ByteArray = JsonObject(linkedMapOf(
        "v" to JsonPrimitive(1), "t" to JsonPrimitive(kind), "ts" to JsonPrimitive(now()),
        "ids" to JsonArray(ids.map { JsonPrimitive(it) }),
    )).toString().encodeToByteArray()

    private fun idsPayload(ids: List<String>): String =
        JsonObject(linkedMapOf("ids" to JsonArray(ids.map { JsonPrimitive(it) }))).toString()

    private fun idList(o: JsonObject): List<String> = (o["ids"] as? JsonArray).orEmpty()
        .mapNotNull { (it as? JsonPrimitive)?.contentOrNull }.filter { it.length <= 64 }.take(500)

    private fun newMsgId(): String = Uuids.v7(now(), NuvaCrypto.random(10))

    private fun now(): Long = Clock.System.now().toEpochMilliseconds()

    private companion object {
        const val DAY_MS = 86_400_000L
        const val RETRY_MIN_MS = 2_000L
        const val RETRY_MAX_MS = 60_000L
        const val CTL_CHUNK = 200
        const val CTL_RCPT = "rcpt"
        const val CTL_READ = "read"
        const val CTL_REACT = "react"
        const val CTL_DEL = "del"
        const val CTL_PLAYED = "played"
        const val KIND_TEXT = 0L
        const val KIND_VOICE = 1L
        const val BLOB_KEY_LEN = 32
    }
}
