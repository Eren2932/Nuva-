package app.nuva.core.net

import app.nuva.core.crypto.NuvaCrypto
import app.nuva.core.store.Account
import app.nuva.core.util.B64
import app.nuva.core.util.toHex
import io.ktor.client.HttpClient
import io.ktor.client.plugins.onDownload
import io.ktor.client.plugins.onUpload
import io.ktor.client.request.header
import io.ktor.client.request.request
import io.ktor.client.request.setBody
import io.ktor.client.statement.bodyAsBytes
import io.ktor.http.ContentType
import io.ktor.http.HttpHeaders
import io.ktor.http.HttpMethod
import io.ktor.http.contentType
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.datetime.Clock
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.longOrNull

/** Итог HTTP-вызова. Offline — сеть или 5xx: повторять позже; Rejected — сервер отказал по существу. */
internal sealed interface HttpResult<out T> {
    class Ok<T>(val value: T) : HttpResult<T>
    data object NotFound : HttpResult<Nothing>
    data object NotModified : HttpResult<Nothing>
    data object RateLimited : HttpResult<Nothing>
    data object Offline : HttpResult<Nothing>
    class Rejected(val status: Int, val code: String) : HttpResult<Nothing>
}

/** Картинка, пришедшая с сервера: [ver] из ETag. */
internal class AvatarPayload(val ver: Long, val data: ByteArray)

/**
 * HTTP-часть протокола 0.3: блобы (голосовые) и аватарки. Каждый запрос подписан ключом устройства
 * (NUVA-HTTP-V1; в подпись входят хост, метод, путь с query, время и SHA-256 тела), то есть
 * той же личностью, что и вход по WebSocket. Тело блоба — уже шифртекст: сервер ничего не читает.
 *
 * Часы: сервер допускает расхождение в секундах; при 401 clock_skew берём его время из заголовка
 * и повторяем запрос ровно один раз.
 */
internal class HttpApi(
    private val http: HttpClient,
    private val host: String,
    private val account: Account,
) {
    @kotlin.concurrent.Volatile
    private var skewSeconds: Long = 0

    private class Raw(val status: Int, val body: ByteArray, val etag: String?, val serverTime: Long?)

    // ───────────── блобы ─────────────

    suspend fun putBlob(blobId: String, to: String, data: ByteArray, progress: (Long, Long) -> Unit): HttpResult<Unit> =
        interpret(call(HttpMethod.Put, "/blob/$blobId?to=$to", data, TRANSFER_TIMEOUT_MS, upload = progress)) { }

    suspend fun getBlob(blobId: String, progress: (Long, Long) -> Unit): HttpResult<ByteArray> =
        interpret(call(HttpMethod.Get, "/blob/$blobId", null, TRANSFER_TIMEOUT_MS, download = progress)) { it.body }

    /** Получатель: «забрал и сохранил» (сервер удалит блоб, когда так ответят все устройства). Отправитель: отзыв. */
    suspend fun ackBlob(blobId: String): HttpResult<Unit> =
        when (val r = interpret(call(HttpMethod.Delete, "/blob/$blobId", null, SHORT_TIMEOUT_MS)) { }) {
            HttpResult.NotFound -> HttpResult.Ok(Unit) // уже удалён — цель достигнута
            else -> r
        }

    // ───────────── аватарки ─────────────

    suspend fun putAvatar(jpeg: ByteArray): HttpResult<Long> =
        interpret(call(HttpMethod.Put, "/avatar", jpeg, TRANSFER_TIMEOUT_MS, ctype = ContentType.Image.JPEG)) { parseVer(it.body) }

    suspend fun deleteAvatar(): HttpResult<Long> =
        interpret(call(HttpMethod.Delete, "/avatar", null, SHORT_TIMEOUT_MS)) { parseVer(it.body) }

    /** [haveVer] — версия, что лежит у нас: сервер ответит 304, если она актуальна. */
    suspend fun getAvatar(accountId: String, haveVer: Long?): HttpResult<AvatarPayload> {
        val inm = if (haveVer != null && haveVer > 0) "\"$haveVer\"" else null
        val raw = call(HttpMethod.Get, "/avatar/$accountId", null, TRANSFER_TIMEOUT_MS, ifNoneMatch = inm)
        if (raw != null && raw.status in 200..299) {
            val ver = raw.etag?.trim('"')?.toLongOrNull()
            // Без ETag или без тела картинку принять нельзя: считаем ответ сбойным и повторим позже.
            if (ver == null || raw.body.isEmpty()) return HttpResult.Offline
            return HttpResult.Ok(AvatarPayload(ver, raw.body))
        }
        return interpret<AvatarPayload>(raw) { throw IllegalStateException("unreachable") }
    }

    // ───────────── ядро ─────────────

    private fun parseVer(body: ByteArray): Long = try {
        (Json.parseToJsonElement(body.decodeToString()).jsonObject["ver"] as? JsonPrimitive)?.longOrNull ?: 0L
    } catch (e: Exception) {
        0L
    }

    private fun <T> interpret(raw: Raw?, ok: (Raw) -> T): HttpResult<T> {
        if (raw == null) return HttpResult.Offline
        return when (raw.status) {
            200, 201, 204 -> HttpResult.Ok(ok(raw))
            304 -> HttpResult.NotModified
            404 -> HttpResult.NotFound
            429 -> HttpResult.RateLimited
            in 500..599 -> HttpResult.Offline
            else -> HttpResult.Rejected(raw.status, errorCode(raw.body))
        }
    }

    private fun errorCode(body: ByteArray): String = try {
        ((Json.parseToJsonElement(body.decodeToString()) as JsonObject)["error"] as? JsonPrimitive)?.contentOrNull ?: "http"
    } catch (e: Exception) {
        "http"
    }

    /** null — сети нет (в том числе таймаут). Один повтор при расхождении часов. */
    private suspend fun call(
        verb: HttpMethod, target: String, body: ByteArray?, timeoutMs: Long,
        ctype: ContentType = ContentType.Application.OctetStream,
        ifNoneMatch: String? = null,
        upload: ((Long, Long) -> Unit)? = null,
        download: ((Long, Long) -> Unit)? = null,
    ): Raw? {
        repeat(2) { attempt ->
            val got: Raw? = try {
                once(verb, target, body, timeoutMs, ctype, ifNoneMatch, upload, download)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                return null
            }
            val raw = got ?: return null // таймаут
            val st = raw.serverTime
            if (raw.status == 401 && st != null && attempt == 0) {
                skewSeconds = st - Clock.System.now().epochSeconds
                return@repeat
            }
            return raw
        }
        return null
    }

    private suspend fun once(
        verb: HttpMethod, target: String, body: ByteArray?, timeoutMs: Long, ctype: ContentType,
        ifNoneMatch: String?, upload: ((Long, Long) -> Unit)?, download: ((Long, Long) -> Unit)?,
    ): Raw? {
        val bodyHash = if (body == null) EMPTY_SHA256 else NuvaCrypto.sha256(body)
        val ts = Clock.System.now().epochSeconds + skewSeconds
        val sig = account.identity.sign(
            NuvaCrypto.httpPayload(host, account.deviceId, ts, verb.value, target, bodyHash),
        )
        return withTimeoutOrNull(timeoutMs) {
            val resp = http.request("https://$host$target") {
                method = verb
                header("X-Nuva-Device", account.deviceId)
                header("X-Nuva-Ts", ts.toString())
                header("X-Nuva-Sig", B64.encode(sig))
                if (body != null) {
                    header("X-Nuva-Sha256", bodyHash.toHex())
                    contentType(ctype)
                    setBody(body)
                }
                if (ifNoneMatch != null) header(HttpHeaders.IfNoneMatch, ifNoneMatch)
                if (upload != null) onUpload { sent, total -> upload(sent, total ?: body?.size?.toLong() ?: 0L) }
                if (download != null) onDownload { got, total -> download(got, total ?: 0L) }
            }
            Raw(
                status = resp.status.value,
                body = resp.bodyAsBytes(),
                etag = resp.headers[HttpHeaders.ETag],
                serverTime = resp.headers["X-Nuva-Server-Time"]?.toLongOrNull(),
            )
        }
    }

    private companion object {
        val EMPTY_SHA256: ByteArray = NuvaCrypto.sha256(ByteArray(0))
        const val TRANSFER_TIMEOUT_MS = 120_000L
        const val SHORT_TIMEOUT_MS = 20_000L
    }
}
