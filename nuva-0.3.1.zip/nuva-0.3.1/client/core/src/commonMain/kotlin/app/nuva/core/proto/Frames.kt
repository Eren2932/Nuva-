package app.nuva.core.proto

import app.nuva.core.util.B64
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.longOrNull
import kotlinx.serialization.json.put

/** Протокол v1 (+ расширения 0.2): сборка клиентских фреймов и разбор серверных. */
public object Frames {
    public const val SUBPROTOCOL: String = "nuva.v1"

    private fun frame(type: String, id: String?, body: MutableMap<String, JsonElement>.() -> Unit): String {
        val m = linkedMapOf<String, JsonElement>("v" to JsonPrimitive(1), "type" to JsonPrimitive(type))
        if (id != null) m["id"] = JsonPrimitive(id)
        m.body()
        return JsonObject(m).toString()
    }

    public fun register(
        id: String, invite: String, username: String, ikPub: ByteArray, xkPub: ByteArray,
        xkSig: ByteArray, platform: String, sig: ByteArray,
    ): String = frame("account.register", id) {
        put("invite", JsonPrimitive(invite))
        put("username", JsonPrimitive(username))
        put("device", buildJsonObject {
            put("identity_key", B64.encode(ikPub))
            put("x25519_key", B64.encode(xkPub))
            put("x25519_sig", B64.encode(xkSig))
            put("platform", platform)
        })
        put("sig", JsonPrimitive(B64.encode(sig)))
    }

    public fun authResponse(id: String, deviceId: String, sig: ByteArray): String = frame("auth.response", id) {
        put("device_id", JsonPrimitive(deviceId))
        put("sig", JsonPrimitive(B64.encode(sig)))
    }

    public fun ping(id: String): String = frame("ping", id) {}

    public fun profileSet(id: String, firstName: String, lastName: String): String = frame("profile.set", id) {
        put("first_name", JsonPrimitive(firstName))
        put("last_name", JsonPrimitive(lastName))
    }

    public fun lookupUsername(id: String, username: String): String = frame("user.lookup", id) {
        put("username", JsonPrimitive(username))
    }

    public fun lookupAccount(id: String, accountId: String): String = frame("user.lookup", id) {
        put("account_id", JsonPrimitive(accountId))
    }

    public fun msgSend(id: String, to: String, clientMsgId: String, envelopes: List<Pair<String, ByteArray>>): String =
        frame("msg.send", id) {
            put("to", JsonPrimitive(to))
            put("client_msg_id", JsonPrimitive(clientMsgId))
            put("envelopes", buildJsonArray {
                for ((device, env) in envelopes) add(buildJsonObject {
                    put("device_id", device)
                    put("envelope", B64.encode(env))
                })
            })
        }

    public fun msgAck(serverIds: List<Long>): String = frame("msg.ack", null) {
        put("server_ids", JsonArray(serverIds.map { JsonPrimitive(it) }))
    }

    // ─────────────── Разбор ───────────────

    private val json = Json { ignoreUnknownKeys = true }

    /** Никогда не бросает: мусор от сервера → [ServerFrame.Unknown]. */
    public fun parse(text: String): ServerFrame = try {
        parseObject(json.parseToJsonElement(text).jsonObject)
    } catch (e: Exception) {
        ServerFrame.Unknown(null, null)
    }

    private fun JsonObject.str(k: String): String? = (this[k] as? JsonPrimitive)?.takeIf { it.isString }?.contentOrNull
    private fun JsonObject.long(k: String): Long? = (this[k] as? JsonPrimitive)?.longOrNull
    private fun JsonObject.obj(k: String): JsonObject? = this[k] as? JsonObject
    private fun JsonObject.reqStr(k: String): String = str(k) ?: error("missing $k")
    private fun JsonObject.bytes(k: String): ByteArray = B64.decode(reqStr(k))

    private fun parseObject(o: JsonObject): ServerFrame {
        val type = o.str("type")
        val id = o.str("id")
        return when (type) {
            "auth.challenge" -> ServerFrame.Challenge(o.bytes("nonce"))
            "auth.ok" -> ServerFrame.AuthOk(id, o.reqStr("account_id"), o.reqStr("device_id"),
                (o["pending"] as? JsonPrimitive)?.intOrNull ?: 0)
            "account.registered" -> ServerFrame.Registered(id, o.reqStr("account_id"), o.reqStr("device_id"))
            "queue.empty" -> ServerFrame.QueueEmpty
            "pong" -> ServerFrame.Pong(id, o.long("server_time") ?: 0)
            "msg.deliver" -> ServerFrame.Deliver(
                serverId = o.long("server_id") ?: error("server_id"),
                fromAccount = o.str("from_account"),
                fromDevice = o.str("from_device"),
                clientMsgId = o.reqStr("client_msg_id"),
                envelope = o.bytes("envelope"),
                serverTs = o.long("server_ts") ?: 0,
            )
            "msg.sent" -> ServerFrame.MsgSent(id, o.reqStr("client_msg_id"), o.long("server_ts") ?: 0)
            "profile.ok" -> ServerFrame.ProfileOk(id, o.str("first_name") ?: "", o.str("last_name") ?: "")
            "user.info" -> ServerFrame.UserInfo(id, parseAccount(o.obj("account") ?: error("account")))
            "error" -> ServerFrame.Error(id, o.str("code") ?: "unknown", o.str("message"), o.obj("details"))
            else -> ServerFrame.Unknown(type, id)
        }
    }

    private fun parseAccount(a: JsonObject): RemoteAccount = RemoteAccount(
        accountId = a.reqStr("account_id"),
        username = a.reqStr("username"),
        firstName = a.str("first_name") ?: "",
        lastName = a.str("last_name") ?: "",
        avatarVer = ((a["avatar_ver"] as? JsonPrimitive)?.longOrNull ?: 0L).coerceIn(0L, 1_000_000_000L),
        devices = (a["devices"] as? JsonArray).orEmpty().mapNotNull { el ->
            val d = el as? JsonObject ?: return@mapNotNull null
            try {
                RemoteDevice(d.reqStr("device_id"), d.bytes("identity_key"), d.bytes("x25519_key"), d.bytes("x25519_sig"))
            } catch (e: Exception) {
                null
            }
        },
    )

    public fun stringList(details: JsonObject?, key: String): List<String> =
        (details?.get(key) as? JsonArray).orEmpty().mapNotNull { (it as? JsonPrimitive)?.contentOrNull }
}

public class RemoteDevice(
    public val deviceId: String,
    public val identityKey: ByteArray,
    public val x25519Key: ByteArray,
    public val x25519Sig: ByteArray,
)

public class RemoteAccount(
    public val accountId: String,
    public val username: String,
    public val firstName: String,
    public val lastName: String,
    public val devices: List<RemoteDevice>,
    /** Версия аватарки на сервере (0 — нет); саму картинку берём по HTTP. */
    public val avatarVer: Long = 0,
)

public sealed interface ServerFrame {
    public val id: String? get() = null

    public class Challenge(public val nonce: ByteArray) : ServerFrame
    public class AuthOk(override val id: String?, public val accountId: String, public val deviceId: String,
                        public val pending: Int) : ServerFrame
    public class Registered(override val id: String?, public val accountId: String,
                            public val deviceId: String) : ServerFrame
    public data object QueueEmpty : ServerFrame
    public class Pong(override val id: String?, public val serverTime: Long) : ServerFrame
    public class Deliver(
        public val serverId: Long, public val fromAccount: String?, public val fromDevice: String?,
        public val clientMsgId: String, public val envelope: ByteArray, public val serverTs: Long,
    ) : ServerFrame
    public class MsgSent(override val id: String?, public val clientMsgId: String, public val serverTs: Long) : ServerFrame
    public class ProfileOk(override val id: String?, public val firstName: String, public val lastName: String) : ServerFrame
    public class UserInfo(override val id: String?, public val account: RemoteAccount) : ServerFrame
    public class Error(override val id: String?, public val code: String, public val message: String?,
                       public val details: JsonObject?) : ServerFrame
    public class Unknown(public val type: String?, override val id: String?) : ServerFrame
}

/** Коды ошибок сервера (protocol.py). */
public object ErrorCodes {
    public const val BAD_REQUEST: String = "bad_request"
    public const val AUTH_FAILED: String = "auth_failed"
    public const val INVITE_INVALID: String = "invite_invalid"
    public const val USERNAME_TAKEN: String = "username_taken"
    public const val USERNAME_INVALID: String = "username_invalid"
    public const val RATE_LIMITED: String = "rate_limited"
    public const val NOT_FOUND: String = "not_found"
    public const val DEVICES_MISMATCH: String = "devices_mismatch"
    public const val PAYLOAD_TOO_LARGE: String = "payload_too_large"
}
