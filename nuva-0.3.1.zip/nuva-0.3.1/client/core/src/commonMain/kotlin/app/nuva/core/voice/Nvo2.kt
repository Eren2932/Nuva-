package app.nuva.core.voice

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.launch
import kotlin.time.TimeSource

/**
 * NVO2 — контейнер голосового сообщения на Opus (заменил NVOI/IMA-ADPCM).
 *
 * Профиль: 16 кГц, моно, кадр 20 мс (320 отсчётов), Opus VOIP/wideband, VBR ~32 кбит/с (реально ~25–30).
 *
 *   0   4  "NVO2"
 *   4   1  версия (2)
 *   5   1  флаги (0)
 *   6   2  частота дискретизации (u16, 16000)
 *   8   2  отсчётов в кадре (u16, 320)
 *  10   2  pre-skip: сколько отсчётов декодера в начале выбросить (задержка кодека)
 *  12   4  всего отсчётов речи (u32) — без pre-skip и добивки последнего кадра
 *  16   2  пик записи 0..32767 — по нему при ВОСПРОИЗВЕДЕНИИ выравнивается громкость
 *  18   2  зарезервировано
 *  20   4  число пакетов (u32)
 *  24  ..  пакеты: [u16 длина][байты Opus] подряд
 *
 * Все числа little-endian. Формат допускает быструю перемотку: таблица смещений строится одним проходом.
 */
public object Nvo2 {
    public const val RATE: Int = 16_000
    public const val FRAME: Int = 320
    public const val BITRATE: Int = 32_000
    public const val HEADER_BYTES: Int = 24
    private const val VERSION: Int = 2
    private val MAGIC = byteArrayOf('N'.code.toByte(), 'V'.code.toByte(), 'O'.code.toByte(), '2'.code.toByte())
    private val FRAME_SIZES = intArrayOf(40, 80, 160, 320, 640, 960) // допустимые длительности Opus при 16 кГц

    internal class Header(
        val rate: Int, val frame: Int, val preSkip: Int, val total: Int, val peak: Int, val packets: Int,
    )

    public fun isNvo2(data: ByteArray): Boolean =
        data.size >= HEADER_BYTES && MAGIC.indices.all { data[it] == MAGIC[it] }

    /** Длительность в мс или null, если это не корректный NVO2. */
    public fun durationMs(data: ByteArray): Long? =
        readHeader(data)?.let { it.total.toLong() * 1000L / it.rate }

    internal fun readHeader(d: ByteArray): Header? {
        if (!isNvo2(d) || d[4].toInt() != VERSION) return null
        val rate = u16(d, 6)
        val frame = u16(d, 8)
        val preSkip = u16(d, 10)
        val total = u32(d, 12)
        val peak = u16(d, 16)
        val packets = u32(d, 20)
        if (rate != RATE || frame !in FRAME_SIZES || preSkip > frame * 4) return null
        if (total < 0 || packets < 0) return null
        val maxSamples = RATE.toLong() * Nvoi.MAX_SECONDS
        if (total > maxSamples || packets.toLong() * frame > maxSamples + frame * 8L) return null
        return Header(rate, frame, preSkip, total, peak, packets)
    }

    internal fun writeHeader(out: ByteArray, preSkip: Int, total: Int, peak: Int, packets: Int) {
        MAGIC.copyInto(out)
        out[4] = VERSION.toByte()
        out[5] = 0
        put16(out, 6, RATE); put16(out, 8, FRAME); put16(out, 10, preSkip)
        put32(out, 12, total); put16(out, 16, peak.coerceIn(0, 32767)); put16(out, 18, 0)
        put32(out, 20, packets)
    }

    private fun u16(d: ByteArray, o: Int): Int = (d[o].toInt() and 0xFF) or ((d[o + 1].toInt() and 0xFF) shl 8)
    private fun u32(d: ByteArray, o: Int): Int =
        (d[o].toInt() and 0xFF) or ((d[o + 1].toInt() and 0xFF) shl 8) or
            ((d[o + 2].toInt() and 0xFF) shl 16) or ((d[o + 3].toInt() and 0xFF) shl 24)

    private fun put16(d: ByteArray, o: Int, v: Int) {
        d[o] = v.toByte(); d[o + 1] = (v shr 8).toByte()
    }

    private fun put32(d: ByteArray, o: Int, v: Int) {
        d[o] = v.toByte(); d[o + 1] = (v shr 8).toByte(); d[o + 2] = (v shr 16).toByte(); d[o + 3] = (v shr 24).toByte()
    }

    /** Таблица пакетов: (смещение, длина). Обрывается на первом битом пакете — хвост считается потерянным. */
    internal fun index(d: ByteArray, h: Header): Pair<IntArray, IntArray> {
        val offsets = IntArray(h.packets)
        val lens = IntArray(h.packets)
        var p = HEADER_BYTES
        var n = 0
        while (n < h.packets && p + 2 <= d.size) {
            val len = u16(d, p)
            if (len == 0 || p + 2 + len > d.size) break
            offsets[n] = p + 2
            lens[n] = len
            p += 2 + len
            n++
        }
        return if (n == h.packets) offsets to lens else offsets.copyOf(n) to lens.copyOf(n)
    }
}

/** Готовая запись: контейнер NVO2, длительность и огибающая для пузыря. */
public class VoiceRecording(public val data: ByteArray, public val durationMs: Long, public val wave: ByteArray)

/**
 * Потоковый кодировщик: захват отдаёт 20-мс куски через [push] (из любого потока, без блокировок), а кодирует
 * отдельная корутина на Dispatchers.Default — поток захвата не ждёт кодек, AudioRecord не переполняется.
 *
 * Если кодек не успевает (медленный телефон), сложность автоматически снижается: лучше чуть хуже звук,
 * чем потерянные куски. К моменту [finish] почти всё уже закодировано — «отправить» не ждёт.
 */
public class OpusVoiceEncoder(scope: CoroutineScope = CoroutineScope(Dispatchers.Default)) {
    private val enc = createOpusEncoder(Nvo2.RATE, Nvo2.BITRATE)
    private val inbox = Channel<ShortArray>(Channel.UNLIMITED)
    private val body = ByteSink()
    private var peaks = IntArray(512)
    private var frames = 0
    private val frame = ShortArray(Nvo2.FRAME)
    private var filled = 0
    private var total = 0L
    private var peak = 0
    private var complexity = 6
    private var emaNs = 0.0

    @kotlin.concurrent.Volatile
    private var failed = false
    private val maxSamples = Nvo2.RATE.toLong() * Nvoi.MAX_SECONDS

    private val job: Job = scope.launch(Dispatchers.Default) {
        try {
            enc.setComplexity(complexity)
            for (chunk in inbox) consume(chunk)
        } catch (e: Exception) {
            if (e is CancellationException) throw e
            failed = true
            inbox.cancel()
        }
    }

    /** Любой поток. Копирует [n] первых отсчётов — буфер захвата можно переиспользовать сразу. */
    public fun push(pcm: ShortArray, n: Int) {
        if (n > 0) inbox.trySend(pcm.copyOf(n))
    }

    private fun consume(chunk: ShortArray) {
        var i = 0
        val room = (maxSamples - total).coerceAtLeast(0).toInt()
        val size = minOf(chunk.size, room)
        while (i < size) {
            val n = minOf(Nvo2.FRAME - filled, size - i)
            chunk.copyInto(frame, filled, i, i + n)
            filled += n
            i += n
            total += n
            if (filled == Nvo2.FRAME) {
                encodeFrame(Nvo2.FRAME)
                filled = 0
            }
        }
    }

    private fun encodeFrame(real: Int) {
        var fp = 0
        for (i in 0 until real) {
            val a = frame[i].toInt().let { if (it < 0) -it else it }
            if (a > fp) fp = a
        }
        if (real < Nvo2.FRAME) frame.fill(0, real, Nvo2.FRAME)
        if (fp > peak) peak = fp
        if (frames == peaks.size) peaks = peaks.copyOf(peaks.size * 2)
        peaks[frames++] = fp

        val t0 = TimeSource.Monotonic.markNow()
        val packet = enc.encode(frame, Nvo2.FRAME)
        emaNs = emaNs * 0.9 + t0.elapsedNow().inWholeNanoseconds * 0.1
        // Кадр длится 20 мс; если среднее время кодирования выше половины — сбрасываем сложность.
        if (emaNs > 10_000_000.0 && complexity > 2) {
            complexity = 2
            enc.setComplexity(complexity)
        }
        body.u16(packet.size)
        body.write(packet)
    }

    /** Дожимает хвост и собирает контейнер. null — пусто или кодек упал. Можно вызывать один раз. */
    public suspend fun finish(): VoiceRecording? {
        inbox.close()
        job.join()
        if (failed || total <= 0L) return null
        try {
            if (filled > 0) {
                encodeFrame(filled)
                filled = 0
            }
            // Хвост: пока закодировано меньше, чем речь + задержка кодека, добавляем тихие кадры.
            val need = total + enc.lookahead
            while (frames.toLong() * Nvo2.FRAME < need) encodeFrame(0)
        } catch (e: Exception) {
            if (e is CancellationException) throw e
            return null
        }
        val out = ByteArray(Nvo2.HEADER_BYTES + body.size)
        Nvo2.writeHeader(out, enc.lookahead, total.toInt(), peak, frames)
        body.copyTo(out, Nvo2.HEADER_BYTES)
        val wave = Nvoi.waveformFromPeaks(peaks, frames)
        return VoiceRecording(out, total * 1000L / Nvo2.RATE, wave)
    }

    public fun cancel() {
        inbox.cancel()
        job.cancel()
    }
}

/** Растущий буфер байтов (в commonMain нет ByteArrayOutputStream). */
internal class ByteSink(initial: Int = 1 shl 16) {
    private var buf = ByteArray(initial)
    var size = 0
        private set

    private fun ensure(extra: Int) {
        if (size + extra > buf.size) buf = buf.copyOf(maxOf(buf.size * 2, size + extra))
    }

    fun u16(v: Int) {
        ensure(2)
        buf[size++] = v.toByte()
        buf[size++] = (v shr 8).toByte()
    }

    fun write(b: ByteArray, off: Int = 0, len: Int = b.size) {
        ensure(len)
        b.copyInto(buf, size, off, off + len)
        size += len
    }

    fun copyTo(dst: ByteArray, at: Int) {
        buf.copyInto(dst, at, 0, size)
    }
}
