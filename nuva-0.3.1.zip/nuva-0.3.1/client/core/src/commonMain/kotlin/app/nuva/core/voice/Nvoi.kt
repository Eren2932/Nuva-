package app.nuva.core.voice

import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * NVOI — формат голосовых сообщений Nuva. Чистый Kotlin, одинаково на Android и desktop, без кодеков ОС:
 * Opus-энкодер в Android есть только с API 29 (у нас minSdk 26), а на JVM его нечем декодировать.
 *
 * Кодек — IMA ADPCM, 4 бита на отсчёт, моно, 16 кГц (≈64 кбит/с, речь в широкой полосе).
 *
 * Раскладка (все числа little-endian):
 * ```
 *  0  4  "NVOI"
 *  4  1  версия = 1
 *  5  1  кодек  = 1 (IMA ADPCM 4 bit mono)
 *  6  2  частота дискретизации, Гц
 *  8  4  число отсчётов
 * 12  2  размер блока в байтах (256)
 * 14  2  0
 * 16  …  блоки
 * ```
 * Блок: i16 точный первый отсчёт, u8 индекс шага, u8 0, затем полубайты (младший — раньше).
 * Полный блок 256 байт = 1 + 252·2 = 505 отсчётов. Блоки независимы: битый блок не тянет ошибку дальше,
 * перемотка — с начала любого блока.
 */
public object Nvoi {
    public const val SAMPLE_RATE: Int = 16_000
    public const val HEADER_BYTES: Int = 16
    public const val BLOCK_BYTES: Int = 256
    public const val VERSION: Int = 1
    public const val CODEC_IMA4: Int = 1

    /** Столбиков в сохранённой волне (UI пересэмплирует под свою ширину). */
    public const val WAVE_BARS: Int = 64

    private val MAGIC = byteArrayOf('N'.code.toByte(), 'V'.code.toByte(), 'O'.code.toByte(), 'I'.code.toByte())

    private val STEP = intArrayOf(
        7, 8, 9, 10, 11, 12, 13, 14, 16, 17, 19, 21, 23, 25, 28, 31, 34, 37, 41, 45, 50, 55, 60, 66, 73, 80, 88, 97,
        107, 118, 130, 143, 157, 173, 190, 209, 230, 253, 279, 307, 337, 371, 408, 449, 494, 544, 598, 658, 724, 796,
        876, 963, 1060, 1166, 1282, 1411, 1552, 1707, 1878, 2066, 2272, 2499, 2749, 3024, 3327, 3660, 4026, 4428, 4871,
        5358, 5894, 6484, 7132, 7845, 8630, 9493, 10442, 11487, 12635, 13899, 15289, 16818, 18500, 20350, 22385, 24623,
        27086, 29794, 32767,
    )
    private val INDEX = intArrayOf(-1, -1, -1, -1, 2, 4, 6, 8)

    public fun samplesPerBlock(blockBytes: Int = BLOCK_BYTES): Int = 1 + (blockBytes - 4) * 2

    public class Header(public val sampleRate: Int, public val samples: Int, public val blockBytes: Int) {
        public val durationMs: Long get() = samples.toLong() * 1000L / sampleRate
    }

    public fun encode(pcm: ShortArray, sampleRate: Int = SAMPLE_RATE): ByteArray {
        val spb = samplesPerBlock()
        val n = pcm.size
        val full = n / spb
        val rest = n - full * spb
        val size = HEADER_BYTES + full * BLOCK_BYTES + (if (rest > 0) 4 + rest / 2 else 0)
        val out = ByteArray(size)
        MAGIC.copyInto(out, 0)
        out[4] = VERSION.toByte()
        out[5] = CODEC_IMA4.toByte()
        putU16(out, 6, sampleRate)
        putU32(out, 8, n.toLong())
        putU16(out, 12, BLOCK_BYTES)

        var o = HEADER_BYTES
        var index = 0
        var s = 0
        while (s < n) {
            val count = min(spb, n - s)
            val first = pcm[s].toInt()
            putU16(out, o, first and 0xFFFF)
            out[o + 2] = index.toByte()
            out[o + 3] = 0
            var p = o + 4
            var pred = first
            var i = 1
            while (i < count) {
                // Кодируем по восстановленному сигналу (как увидит декодер) — без накопления ошибки.
                var step = STEP[index]
                var diff = pcm[s + i].toInt() - pred
                var nib = 0
                if (diff < 0) {
                    nib = 8
                    diff = -diff
                }
                var vp = step shr 3
                if (diff >= step) { nib = nib or 4; diff -= step; vp += step }
                step = step shr 1
                if (diff >= step) { nib = nib or 2; diff -= step; vp += step }
                step = step shr 1
                if (diff >= step) { nib = nib or 1; vp += step }
                pred = if (nib and 8 != 0) max(-32768, pred - vp) else min(32767, pred + vp)
                index = (index + INDEX[nib and 7]).coerceIn(0, 88)
                // Отсчёт i (1-based внутри блока): нечётные — в младший полубайт, чётные — в старший.
                if (i and 1 == 1) out[p] = nib.toByte()
                else {
                    out[p] = (out[p].toInt() or (nib shl 4)).toByte()
                    p++
                }
                i++
            }
            o += if (count == spb) BLOCK_BYTES else 4 + count / 2
            s += count
        }
        return out
    }

    /** null — это не NVOI или неизвестная версия. Обрезанный файл декодируется до места обрыва. */
    public fun header(data: ByteArray): Header? {
        if (data.size < HEADER_BYTES) return null
        for (i in 0 until 4) if (data[i] != MAGIC[i]) return null
        if (data[4].toInt() != VERSION || data[5].toInt() != CODEC_IMA4) return null
        val rate = u16(data, 6)
        val samples = u32(data, 8)
        val block = u16(data, 12)
        if (rate !in 8_000..48_000 || block < 8 || block > 4096 || block % 2 != 0) return null
        if (samples < 0 || samples > rate.toLong() * MAX_SECONDS) return null
        return Header(rate, samples.toInt(), block)
    }

    public fun decode(data: ByteArray): ShortArray? {
        val h = header(data) ?: return null
        val spb = samplesPerBlock(h.blockBytes)
        val out = ShortArray(h.samples)
        var o = HEADER_BYTES
        var s = 0
        while (s < h.samples && o + 4 <= data.size) {
            val count = min(spb, h.samples - s)
            var pred = (u16(data, o).toShort()).toInt()
            var index = (data[o + 2].toInt() and 0xFF).coerceIn(0, 88)
            out[s] = pred.toShort()
            var p = o + 4
            var i = 1
            while (i < count) {
                if (p >= data.size) return out.copyOf(s + i)
                val b = data[p].toInt() and 0xFF
                val nib = if (i and 1 == 1) b and 0x0F else (b shr 4).also { p++ }
                var step = STEP[index]
                var vp = step shr 3
                if (nib and 4 != 0) vp += step
                step = step shr 1
                if (nib and 2 != 0) vp += step
                step = step shr 1
                if (nib and 1 != 0) vp += step
                pred = if (nib and 8 != 0) max(-32768, pred - vp) else min(32767, pred + vp)
                index = (index + INDEX[nib and 7]).coerceIn(0, 88)
                out[s + i] = pred.toShort()
                i++
            }
            o += h.blockBytes
            s += count
        }
        return if (s >= h.samples) out else out.copyOf(s)
    }

    /**
     * Волна для пузыря: [bars] значений 0..255 — пик сегмента в децибелах (окно −50…0 dBFS),
     * нормированный к самому громкому сегменту. Тихая запись не выглядит «плоской линией».
     */
    /** Огибающая по пикам кадров (потоковый кодировщик не хранит PCM): окна по [count] значениям [peaks]. */
    public fun waveformFromPeaks(peaks: IntArray, count: Int, bars: Int = WAVE_BARS): ByteArray {
        val out = ByteArray(bars)
        if (count <= 0) return out
        val levels = FloatArray(bars)
        for (b in 0 until bars) {
            val from = (count.toLong() * b / bars).toInt()
            val to = max(from + 1, (count.toLong() * (b + 1) / bars).toInt()).coerceAtMost(count)
            var peak = 0
            for (i in from until to) peak = max(peak, peaks[i])
            val db = if (peak <= 0) -50f else (20 * log10(peak / 32768f)).coerceIn(-50f, 0f)
            levels[b] = (db + 50f) / 50f
        }
        val top = levels.max().coerceAtLeast(0.05f)
        for (b in 0 until bars) out[b] = (levels[b] / top * 255f).roundToInt().coerceIn(0, 255).toByte()
        return out
    }

    public fun waveform(pcm: ShortArray, bars: Int = WAVE_BARS): ByteArray {
        val out = ByteArray(bars)
        if (pcm.isEmpty()) return out
        val levels = FloatArray(bars)
        for (b in 0 until bars) {
            val from = (pcm.size.toLong() * b / bars).toInt()
            val to = max(from + 1, (pcm.size.toLong() * (b + 1) / bars).toInt()).coerceAtMost(pcm.size)
            var peak = 0
            for (i in from until to) peak = max(peak, abs(pcm[i].toInt()))
            val db = if (peak <= 0) -50f else (20 * log10(peak / 32768f)).coerceIn(-50f, 0f)
            levels[b] = (db + 50f) / 50f
        }
        val top = levels.max().coerceAtLeast(0.05f)
        for (b in 0 until bars) out[b] = (levels[b] / top * 255f).roundToInt().coerceIn(0, 255).toByte()
        return out
    }

    /**
     * Мягкая нормализация громкости перед кодированием: пик поднимается до −1 dBFS, но усиление не больше ×4
     * (шум тихой комнаты не превращается в рёв). Громкое не трогаем.
     */
    public fun normalize(pcm: ShortArray): ShortArray {
        var peak = 1
        for (v in pcm) peak = max(peak, abs(v.toInt()))
        val gain = min(4f, 29_204f / peak) // 29204 ≈ 32767 · 10^(−1/20)
        if (gain <= 1.02f) return pcm
        return ShortArray(pcm.size) { (pcm[it] * gain).roundToInt().coerceIn(-32768, 32767).toShort() }
    }

    /** Голосовые ограничены 10 минутами: ~4,8 МБ, 147 конвертов. */
    public const val MAX_SECONDS: Int = 600

    private fun putU16(b: ByteArray, o: Int, v: Int) {
        b[o] = v.toByte()
        b[o + 1] = (v shr 8).toByte()
    }

    private fun putU32(b: ByteArray, o: Int, v: Long) {
        for (i in 0 until 4) b[o + i] = (v shr (8 * i)).toByte()
    }

    private fun u16(b: ByteArray, o: Int): Int = (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8)

    private fun u32(b: ByteArray, o: Int): Long {
        var v = 0L
        for (i in 0 until 4) v = v or ((b[o + i].toLong() and 0xFF) shl (8 * i))
        return v
    }
}
