package app.nuva.core.voice

/**
 * Opus на обеих платформах — один и тот же чистый-Java Concentus (без нативного кода), поэтому реализация
 * [createOpusEncoder]/[createOpusDecoder] в androidMain и desktopMain идентична. Остальная логика (контейнер,
 * потоковое кодирование, прогрессивное декодирование) — общая и живёт здесь, в commonMain.
 */
internal interface OpusEnc {
    /** Задержка кодека в отсчётах: столько «лишнего» стоит в начале декодированного потока. */
    val lookahead: Int

    /** Кодирует ровно один кадр: [pcm] с нулевого элемента, длина кадра = frameSamples. Возвращает пакет. */
    fun encode(pcm: ShortArray, frameSamples: Int): ByteArray

    fun setComplexity(value: Int)
}

internal interface OpusDec {
    /** Декодирует пакет в [out] с нуля. Возвращает число отсчётов (до [maxSamples]). */
    fun decode(packet: ByteArray, offset: Int, length: Int, out: ShortArray, maxSamples: Int): Int
}

/** Речевой профиль: 16 кГц моно, VOIP, широкая полоса, VBR около [bitrate] бит/с. */
internal expect fun createOpusEncoder(sampleRate: Int, bitrate: Int): OpusEnc

internal expect fun createOpusDecoder(sampleRate: Int): OpusDec
