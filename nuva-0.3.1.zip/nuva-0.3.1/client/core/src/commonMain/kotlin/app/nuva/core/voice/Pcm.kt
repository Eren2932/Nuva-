package app.nuva.core.voice

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

private const val ZERO_CROSSINGS = 16   // полуширина ядра в нулях sinc
private const val OVERSAMPLE = 256      // точек таблицы ядра на один входной отсчёт
private const val PASS = 0.9            // срез = 0.9 от Найквиста меньшей частоты

/** Утилиты 16-битного моно PCM: индикатор громкости и ресэмплинг к частоте NVOI. */
public object Pcm {
    /**
     * Громкость фрагмента для индикатора записи, 0..1: пик в dBFS, окно −50…0 dB.
     * Линейная шкала «мёртвая» на тихой речи, логарифм даёт живую пульсацию.
     */
    public fun level(buf: ShortArray, n: Int = buf.size): Float {
        var peak = 0
        for (i in 0 until min(n, buf.size)) {
            val a = abs(buf[i].toInt())
            if (a > peak) peak = a
        }
        if (peak == 0) return 0f
        val db = 20.0 * log10(peak / 32768.0)
        return ((db + 50.0) / 50.0).coerceIn(0.0, 1.0).toFloat()
    }

    /**
     * Ресэмплинг [from] → [to] Гц оконным sinc (Блэкман, 16 нулей). Срез 0.9·Найквиста целевой частоты:
     * 48→16 кГц — полоса до 6 кГц ровная (0 dB), выше 9 кГц подавление ≥ 75 dB. Веса нормируются,
     * так что постоянная составляющая и края записи не «проседают».
     * Целиком в памяти; для записи с микрофона есть потоковый [StreamResampler] с тем же результатом.
     */
    public fun resample(pcm: ShortArray, from: Int, to: Int): ShortArray {
        require(from > 0 && to > 0) { "bad rate" }
        if (from == to || pcm.isEmpty()) return pcm
        val r = StreamResampler(from, to)
        val a = r.push(pcm, pcm.size)
        return a + r.finish()
    }
}

/**
 * Потоковый ресэмплер: тот же фильтр, что и [Pcm.resample], но порциями — во время записи микрофон
 * отдаёт кадры, и приводить их к 16 кГц нужно сразу, а не после остановки. Результат не зависит от
 * того, как вход нарезан на порции. Не потокобезопасен.
 */
public class StreamResampler(private val from: Int, private val to: Int) {
    private val passthrough = from == to
    private val c = min(1.0, to.toDouble() / from) * PASS
    private val half = ceil(ZERO_CROSSINGS / c).toInt()
    private val tab = DoubleArray(half * OVERSAMPLE + 1) { i ->
        val t = i.toDouble() / OVERSAMPLE
        val u = c * t
        val sinc = if (u == 0.0) 1.0 else sin(PI * u) / (PI * u)
        val w = t / half
        val win = if (w < 1.0) 0.42 + 0.5 * cos(PI * w) + 0.08 * cos(2 * PI * w) else 0.0
        c * sinc * win
    }
    private val step = from.toDouble() / to
    private var buf = ShortArray(8192) // необработанный вход
    private var size = 0
    private var base = 0L              // абсолютный индекс buf[0]
    private var outIdx = 0L            // следующий выходной отсчёт
    private var total = 0L             // всего получено входных отсчётов

    init {
        require(from > 0 && to > 0) { "bad rate" }
    }

    /** Добавить [n] отсчётов из [src]; вернёт готовые выходные (может быть пусто). */
    public fun push(src: ShortArray, n: Int = src.size): ShortArray {
        if (passthrough) return src.copyOf(n)
        if (n > 0) {
            if (size + n > buf.size) buf = buf.copyOf(max(buf.size * 2, size + n))
            src.copyInto(buf, size, 0, n)
            size += n
            total += n
        }
        return run(false)
    }

    /** Конец входа: дорабатывает хвост (край окна считается по реально имеющимся отсчётам). */
    public fun finish(): ShortArray = if (passthrough) ShortArray(0) else run(true)

    private fun run(last: Boolean): ShortArray {
        var out = ShortArray(((size + half).toLong() * to / from + 4).toInt())
        var cnt = 0
        val lastTab = tab.size - 1
        val end = base + size - 1
        while (true) {
            val pos = outIdx * step
            if (last) {
                if (outIdx >= total * to / from) break
            } else if (floor(pos + half).toLong() > end) break
            val lo = max(base, ceil(pos - half).toLong())
            val hi = min(end, floor(pos + half).toLong())
            var acc = 0.0
            var ws = 0.0
            var k = lo
            while (k <= hi) {
                val d = abs(k - pos) * OVERSAMPLE
                val j = d.toInt()
                if (j < lastTab) {
                    val h = tab[j] + (tab[j + 1] - tab[j]) * (d - j)
                    acc += buf[(k - base).toInt()] * h
                    ws += h
                }
                k++
            }
            val v = if (ws != 0.0) acc / ws else 0.0
            if (cnt == out.size) out = out.copyOf(out.size * 2)
            out[cnt++] = v.roundToInt().coerceIn(-32768, 32767).toShort()
            outIdx++
        }
        val keepFrom = max(base, ceil(outIdx * step - half).toLong())
        val drop = min(keepFrom - base, size.toLong()).toInt()
        if (drop > 0) {
            buf.copyInto(buf, 0, drop, size)
            size -= drop
            base += drop
        }
        return out.copyOf(cnt)
    }
}
