package app.nuva.core.voice

/**
 * Приёмник захвата микрофона: общий для всех платформ. Платформа только читает PCM с микрофона и зовёт [feed];
 * дальше кадры приводятся к 16 кГц ([StreamResampler]) и сразу уходят в потоковый [OpusVoiceEncoder].
 * К кнопке «отправить» всё уже закодировано.
 *
 * [feed] — из потока захвата, остальное читается из UI-потока.
 */
public class VoiceCapture(private val inputRate: Int) {
    private val encoder = OpusVoiceEncoder()
    private val resampler = StreamResampler(inputRate, Nvo2.RATE)

    @kotlin.concurrent.Volatile
    public var level: Float = 0f
        private set

    @kotlin.concurrent.Volatile
    private var samples: Long = 0

    /** Длительность записанного без пауз, мс. */
    public val durationMs: Long get() = samples * 1000L / inputRate

    @kotlin.concurrent.Volatile
    public var paused: Boolean = false

    /** Поток захвата продолжает читать микрофон и на паузе (без щелчка при возобновлении) — отсчёты просто не копятся. */
    public fun feed(buf: ShortArray, n: Int) {
        if (n <= 0) return
        level = Pcm.level(buf, n)
        if (paused) return
        samples += n
        val out = resampler.push(buf, n)
        if (out.isNotEmpty()) encoder.push(out, out.size)
    }

    public suspend fun finish(): VoiceRecording? {
        val tail = resampler.finish()
        if (tail.isNotEmpty()) encoder.push(tail, tail.size)
        return encoder.finish()
    }

    public fun cancel() {
        encoder.cancel()
    }
}
