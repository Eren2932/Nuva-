package app.nuva.core.voice

import kotlin.math.abs

/**
 * Голосовое, готовое к воспроизведению. Opus декодируется ПРОГРЕССИВНО: звук идёт, как только готова первая
 * четверть секунды, а остальное доезжает фоном (десятиминутную запись на телефоне целиком до старта не ждём).
 *
 * Потоки: [decode] — блокирующий цикл, его гоняют на фоновом диспетчере; [available] читает проигрыватель.
 * Старые сообщения (NVOI, ADPCM) декодируются мгновенно целиком в [open].
 *
 * Громкость выравнивается здесь, при воспроизведении ([gain]): запись идёт «как есть» с микрофона,
 * поэтому у тихих говорящих нет усиленного шума в самом файле.
 */
public class VoiceClip private constructor(
    public val sampleRate: Int,
    public val totalSamples: Int,
    public val gain: Float,
    public val pcm: ShortArray,
    private val data: ByteArray?,
    private val offsets: IntArray,
    private val lens: IntArray,
    private val frame: Int,
    private val preSkip: Int,
) {
    private class Region(val from: Int, val to: Int)

    @kotlin.concurrent.Volatile
    private var region = if (data == null) Region(0, totalSamples) else Region(0, 0)

    public val durationMs: Long get() = totalSamples.toLong() * 1000L / sampleRate

    /** Сколько отсчётов подряд готово начиная с [at] (0 — позиция вне декодированного участка). */
    public fun available(at: Int): Int {
        val r = region
        return if (at >= r.from && at < r.to) r.to - at else 0
    }

    public val isFullyDecoded: Boolean get() = region.let { it.from == 0 && it.to >= totalSamples }

    /** Позиция внутри уже декодированного участка — перемотка бесплатна. */
    public fun covers(at: Int): Boolean = region.let { at >= it.from && at <= it.to }

    /**
     * Декодирует от [from] до конца. Блокирует поток; [active] проверяется на каждом пакете — вернул false,
     * цикл выходит. Перед [from] прогоняется «разгон» ([PREROLL] кадров), чтобы состояние декодера сошлось.
     * Два одновременных вызова на один клип запрещены (сначала дождитесь выхода предыдущего).
     */
    public fun decode(from: Int, active: () -> Boolean) {
        val src = data ?: return
        val start = from.coerceIn(0, totalSamples)
        val firstPacket = ((start + preSkip) / frame).coerceAtMost(offsets.size)
        val roll = maxOf(0, firstPacket - PREROLL)
        val fromOut = maxOf(0, firstPacket * frame - preSkip)
        region = Region(fromOut, fromOut)
        val dec = createOpusDecoder(sampleRate)
        val buf = ShortArray(frame)
        var p = roll
        while (p < offsets.size && active()) {
            val n = try {
                dec.decode(src, offsets[p], lens[p], buf, frame)
            } catch (e: Exception) {
                buf.fill(0) // битый пакет — тишина вместо обрыва всего сообщения
                frame
            }
            val base = p * frame - preSkip
            for (i in 0 until n) {
                val idx = base + i
                if (idx in 0 until totalSamples) pcm[idx] = scale(buf[i].toInt())
            }
            if (p >= firstPacket) region = Region(fromOut, minOf(totalSamples, base + n))
            p++
        }
        // Обрезанный/битый хвост — договариваем тишиной, чтобы проигрыватель не ждал вечно.
        if (p >= offsets.size && region.from == fromOut) region = Region(fromOut, totalSamples)
    }

    private fun scale(v: Int): Short {
        val x = (v * gain).toInt()
        return (if (x > 32767) 32767 else if (x < -32768) -32768 else x).toShort()
    }

    public companion object {
        /** Кадры «разгона» перед позицией перемотки: 12 × 20 мс. */
        public const val PREROLL: Int = 12
        private const val TARGET_PEAK = 29_000f
        private const val MAX_GAIN = 3f

        /** Мягкое выравнивание: тихое подтягиваем (до ×3), громкое не трогаем, клиппинга не допускаем. */
        public fun gainFor(peak: Int): Float =
            if (peak <= 0) 1f else (TARGET_PEAK / peak).coerceIn(1f, MAX_GAIN)

        /** null — не голосовое Nuva или битый заголовок. */
        public fun open(data: ByteArray): VoiceClip? {
            val h2 = Nvo2.readHeader(data)
            if (h2 != null) {
                val (offs, lens) = Nvo2.index(data, h2)
                if (offs.isEmpty()) return null
                val total = minOf(h2.total, (offs.size * h2.frame - h2.preSkip).coerceAtLeast(0))
                if (total <= 0) return null
                return VoiceClip(h2.rate, total, gainFor(h2.peak), ShortArray(total), data, offs, lens, h2.frame, h2.preSkip)
            }
            val h1 = Nvoi.header(data) ?: return null
            val pcm = Nvoi.decode(data) ?: return null
            var peak = 0
            for (s in pcm) peak = maxOf(peak, abs(s.toInt()))
            val g = gainFor(peak)
            if (g != 1f) for (i in pcm.indices) pcm[i] = (pcm[i] * g).toInt().coerceIn(-32768, 32767).toShort()
            return VoiceClip(h1.sampleRate, pcm.size, 1f, pcm, null, IntArray(0), IntArray(0), 1, 0)
        }
    }
}
