package app.nuva.core

import app.nuva.core.voice.Nvoi
import kotlin.math.PI
import kotlin.math.log10
import kotlin.math.sin
import kotlin.test.Test
import kotlin.test.assertContentEquals
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

class NvoiTest {
    private fun tone(n: Int): ShortArray = ShortArray(n) { i ->
        val t = i / 16_000.0
        (8000 * sin(2 * PI * 220 * t) + 3000 * sin(2 * PI * 1800 * t)).toInt().toShort()
    }

    @Test
    fun sizeAndHeader() {
        for (n in listOf(0, 1, 2, 504, 505, 506, 1010, 16_000 * 2 - 123)) {
            val pcm = tone(n)
            val data = Nvoi.encode(pcm)
            val spb = Nvoi.samplesPerBlock()
            val full = n / spb
            val rest = n - full * spb
            assertEquals(Nvoi.HEADER_BYTES + full * Nvoi.BLOCK_BYTES + (if (rest > 0) 4 + rest / 2 else 0), data.size, "n=$n")
            val h = assertNotNull(Nvoi.header(data))
            assertEquals(n, h.samples)
            assertEquals(Nvoi.SAMPLE_RATE, h.sampleRate)
            assertEquals(n, Nvoi.decode(data)!!.size)
        }
    }

    @Test
    fun roundTripQuality() {
        val pcm = tone(16_000 * 2 - 123)
        val back = Nvoi.decode(Nvoi.encode(pcm))!!
        var sig = 0.0
        var err = 0.0
        for (i in pcm.indices) {
            sig += pcm[i].toDouble() * pcm[i]
            val e = (pcm[i] - back[i]).toDouble()
            err += e * e
        }
        val snr = 10 * log10(sig / err)
        assertTrue(snr > 25, "SNR $snr dB")
        // Первый отсчёт каждого блока хранится точно.
        for (b in 0 until pcm.size / Nvoi.samplesPerBlock()) {
            val i = b * Nvoi.samplesPerBlock()
            assertEquals(pcm[i], back[i])
        }
    }

    @Test
    fun deterministicAndTruncationSafe() {
        val pcm = tone(5000)
        val a = Nvoi.encode(pcm)
        assertContentEquals(a, Nvoi.encode(pcm))
        val cut = a.copyOf(a.size - 100)
        val partial = assertNotNull(Nvoi.decode(cut))
        assertTrue(partial.size in 1 until pcm.size)
        assertNull(Nvoi.header(byteArrayOf(1, 2, 3)))
        assertNull(Nvoi.decode(ByteArray(40)))
    }

    @Test
    fun waveformNormalized() {
        val w = Nvoi.waveform(tone(16_000))
        assertEquals(Nvoi.WAVE_BARS, w.size)
        assertEquals(255, w.maxOf { it.toInt() and 0xFF })
        assertTrue(Nvoi.waveform(ShortArray(0)).all { it.toInt() == 0 })
    }
}
