package app.nuva.core

import app.nuva.core.voice.Pcm
import kotlin.math.PI
import kotlin.math.log10
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertSame
import kotlin.test.assertTrue

class PcmTest {
    private fun tone(f: Double, rate: Int, n: Int): ShortArray =
        ShortArray(n) { (10_000 * sin(2 * PI * f * it / rate)).toInt().toShort() }

    private fun rms(a: ShortArray, from: Int, to: Int): Double {
        var s = 0.0
        for (i in from until to) s += a[i].toDouble() * a[i]
        return sqrt(s / (to - from))
    }

    @Test
    fun passbandIsClean() {
        for (src in listOf(48_000, 44_100)) {
            val out = Pcm.resample(tone(1000.0, src, src / 5), src, 16_000)
            assertEquals(16_000 / 5, out.size)
            val ref = tone(1000.0, 16_000, out.size)
            var sig = 0.0
            var err = 0.0
            for (i in 200 until out.size - 200) {
                sig += ref[i].toDouble() * ref[i]
                val e = (out[i] - ref[i]).toDouble()
                err += e * e
            }
            assertTrue(10 * log10(sig / err) > 60, "src=$src")
        }
    }

    @Test
    fun aliasesAreSuppressed() {
        // 12 кГц при 48 кГц после 48→16 иначе отразился бы в 4 кГц — слышимый свист.
        val out = Pcm.resample(tone(12_000.0, 48_000, 9_600), 48_000, 16_000)
        val atten = 20 * log10(rms(out, 200, out.size - 200) / (10_000 / sqrt(2.0)))
        assertTrue(atten < -60, "atten=$atten")
    }

    @Test
    fun identityAndLevel() {
        val a = tone(440.0, 16_000, 100)
        assertSame(a, Pcm.resample(a, 16_000, 16_000))
        assertEquals(0f, Pcm.level(ShortArray(10)))
        assertEquals(1f, Pcm.level(shortArrayOf(Short.MIN_VALUE)))
        val l = Pcm.level(shortArrayOf(328)) // ≈ −40 dBFS
        assertTrue(l in 0.19f..0.21f, "l=$l")
    }
}
