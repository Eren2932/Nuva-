package app.nuva.ui

import app.nuva.core.InitResult
import app.nuva.core.NuvaCore
import app.nuva.core.Platform
import app.nuva.ui.nav.Router
import app.nuva.ui.onboarding.OnboardingState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.MutableStateFlow

/** Корень приложения: один на процесс (Android — в Application, desktop — в main). */
class AppGraph(platform: Platform, val host: HostBridge = HostBridge.None) {
    val scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    val core: NuvaCore = NuvaCore(platform, scope)
    val router: Router = Router()
    val onboarding: OnboardingState = OnboardingState()

    // Инициализация ровно один раз, даже если заставку пересоздали (поворот экрана).
    private val boot = scope.async(start = CoroutineStart.LAZY) { core.init() }

    suspend fun init(): InitResult = boot.await()

    fun onForeground() = core.onForeground()

    /** Окно на экране и в фокусе. Только тогда сообщения считаются прочитанными. */
    fun setForeground(value: Boolean) = core.setForeground(value)

    /** Чат, который надо открыть (тап по уведомлению). Подхватывается в NuvaApp, когда есть куда идти. */
    val pendingChat: MutableStateFlow<String?> = MutableStateFlow(null)

    fun openChat(peerId: String) {
        pendingChat.value = peerId
    }

    /** Экран может перехватить «назад» (закрыть меню, снять выделение). true — событие обработано. */
    var backHook: (() -> Boolean)? = null

    /**
     * Системная «назад». Во время регистрации назад нельзя (запрос уже ушёл на сервер),
     * но после ошибки — можно: возвращаем к исправлению ввода.
     */
    fun back(): Boolean {
        if (backHook?.invoke() == true) return true
        val top = router.state.value.top
        val phase = onboarding.phase
        if (top == app.nuva.ui.nav.Screen.KeyGen && phase is app.nuva.ui.onboarding.RegPhase.Error &&
            onboarding.job?.isActive != true) {
            router.backTo(phase.back ?: app.nuva.ui.nav.Screen.Username)
            return true
        }
        return router.back()
    }
}
