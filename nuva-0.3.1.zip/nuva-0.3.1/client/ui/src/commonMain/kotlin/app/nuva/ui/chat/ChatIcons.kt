package app.nuva.ui.chat

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** Иконки, которых нет в material-icons-core. Сетка 24×24, линия 2. */

private fun DrawScope.lineStyle(): Stroke =
    Stroke(width = 2f * (size.width / 24f), cap = StrokeCap.Round, join = StrokeJoin.Round)

/** Стрелка «ответить» ↩. */
@Composable
fun ReplyIcon(color: Color, size: Dp = 24.dp, modifier: Modifier = Modifier) {
    Canvas(modifier.size(size)) {
        val k = this.size.width / 24f
        val p = Path().apply {
            moveTo(10f * k, 5f * k)
            lineTo(4f * k, 11f * k)
            lineTo(10f * k, 17f * k)
        }
        drawPath(p, color, style = lineStyle())
        val body = Path().apply {
            moveTo(4.5f * k, 11f * k)
            lineTo(14f * k, 11f * k)
            cubicTo(18f * k, 11f * k, 20f * k, 13.5f * k, 20f * k, 18.5f * k)
        }
        drawPath(body, color, style = lineStyle())
    }
}

/** Два листа «копировать». */
@Composable
fun CopyIcon(color: Color, size: Dp = 24.dp, modifier: Modifier = Modifier) {
    Canvas(modifier.size(size)) {
        val k = this.size.width / 24f
        drawRoundRect(color, Offset(8f * k, 8f * k), Size(11f * k, 12f * k), CornerRadius(2.5f * k), style = lineStyle())
        val back = Path().apply {
            moveTo(15f * k, 5.5f * k)
            lineTo(15f * k, 5f * k)
            cubicTo(15f * k, 4f * k, 14.2f * k, 3.5f * k, 13.5f * k, 3.5f * k)
            lineTo(6.5f * k, 3.5f * k)
            cubicTo(5.4f * k, 3.5f * k, 4.5f * k, 4.4f * k, 4.5f * k, 5.5f * k)
            lineTo(4.5f * k, 14.5f * k)
            cubicTo(4.5f * k, 15.6f * k, 5.4f * k, 16f * k, 6f * k, 16f * k)
        }
        drawPath(back, color, style = lineStyle())
    }
}

/** Микрофон: капсула 6×11, дужка и ножка. */
@Composable
fun MicIcon(color: Color, size: Dp = 24.dp, modifier: Modifier = Modifier) {
    Canvas(modifier.size(size)) {
        val k = this.size.width / 24f
        drawRoundRect(color, Offset(9f * k, 2.5f * k), Size(6f * k, 11.5f * k), CornerRadius(3f * k))
        val arc = Path().apply {
            moveTo(5.5f * k, 11f * k)
            cubicTo(5.5f * k, 14.8f * k, 8.4f * k, 17.5f * k, 12f * k, 17.5f * k)
            cubicTo(15.6f * k, 17.5f * k, 18.5f * k, 14.8f * k, 18.5f * k, 11f * k)
            moveTo(12f * k, 17.5f * k)
            lineTo(12f * k, 21f * k)
        }
        drawPath(arc, color, style = lineStyle())
    }
}

/** Треугольник «play», оптически сдвинут вправо на 1 из 24. */
@Composable
fun PlayIcon(color: Color, size: Dp = 24.dp, modifier: Modifier = Modifier) {
    Canvas(modifier.size(size)) {
        val k = this.size.width / 24f
        val p = Path().apply {
            moveTo(8f * k, 5.2f * k)
            lineTo(19f * k, 12f * k)
            lineTo(8f * k, 18.8f * k)
            close()
        }
        drawPath(p, color)
        drawPath(p, color, style = Stroke(width = 2.2f * k, join = StrokeJoin.Round))
    }
}

/** Две скруглённые полосы «пауза». */
@Composable
fun PauseIcon(color: Color, size: Dp = 24.dp, modifier: Modifier = Modifier) {
    Canvas(modifier.size(size)) {
        val k = this.size.width / 24f
        drawRoundRect(color, Offset(6.5f * k, 5f * k), Size(4f * k, 14f * k), CornerRadius(1.6f * k))
        drawRoundRect(color, Offset(13.5f * k, 5f * k), Size(4f * k, 14f * k), CornerRadius(1.6f * k))
    }
}

/** Замок: дужка + корпус. [open] 0..1 — дужка приподнимается (фиксация записи). */
@Composable
fun LockIcon(color: Color, size: Dp = 24.dp, open: Float = 0f, modifier: Modifier = Modifier) {
    Canvas(modifier.size(size)) {
        val k = this.size.width / 24f
        val lift = 2.5f * k * open
        val shackle = Path().apply {
            moveTo(8f * k, 11f * k - lift)
            lineTo(8f * k, 8f * k - lift)
            cubicTo(8f * k, 5.5f * k - lift, 9.8f * k, 3.8f * k - lift, 12f * k, 3.8f * k - lift)
            cubicTo(14.2f * k, 3.8f * k - lift, 16f * k, 5.5f * k - lift, 16f * k, 8f * k - lift)
            lineTo(16f * k, 11f * k - lift)
        }
        drawPath(shackle, color, style = lineStyle())
        drawRoundRect(color, Offset(5.5f * k, 10.5f * k), Size(13f * k, 10f * k), CornerRadius(2.5f * k))
    }
}

/** Шеврон вверх. */
@Composable
fun ChevronUpIcon(color: Color, size: Dp = 24.dp, modifier: Modifier = Modifier) {
    Canvas(modifier.size(size)) {
        val k = this.size.width / 24f
        val p = Path().apply {
            moveTo(7f * k, 14.5f * k)
            lineTo(12f * k, 9.5f * k)
            lineTo(17f * k, 14.5f * k)
        }
        drawPath(p, color, style = lineStyle())
    }
}

/** Стрелка вниз (голосовое ещё докачивается). */
@Composable
fun DownloadIcon(color: Color, size: Dp = 24.dp, modifier: Modifier = Modifier) {
    Canvas(modifier.size(size)) {
        val k = this.size.width / 24f
        val p = Path().apply {
            moveTo(12f * k, 5f * k)
            lineTo(12f * k, 18f * k)
            moveTo(6.5f * k, 12.5f * k)
            lineTo(12f * k, 18f * k)
            lineTo(17.5f * k, 12.5f * k)
        }
        drawPath(p, color, style = lineStyle())
    }
}
