package app.nuva.ui.chat

import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import app.nuva.ui.theme.NuvaColors

/**
 * Палитра экрана чата. 0.2.5: вернули фирменные цвета 0.2.3 (NuvaColors, PANTONE 18-3840 #6559A3) —
 * референсная палитра 0.2.4 ушла. Геометрия и механика (градиент, привязанный к экрану) остались.
 */
object ChatColors {
    val Bg = NuvaColors.Night
    val Incoming = NuvaColors.Surface2
    /** Плашки шапки: тонкая обводка в тон фона. */
    val Pill = NuvaColors.Surface2
    val PillBorder = Color(0x803A3650)
    val Input = NuvaColors.Surface2
    /** Мини-блок по нажатию: и меню, и полоса реакций. */
    val Popup = NuvaColors.Surface3
    /** Кнопки (отправка, микрофон), полоски цитат, ссылки. */
    val Accent = NuvaColors.BrandLight
    /** Акцентный текст на тёмном фоне («ОТМЕНА», имя в цитате). */
    val AccentText = NuvaColors.BrandSoft
    /** Подсветка сообщения после перехода к цитате (мягко гаснет). */
    val Highlight = NuvaColors.BrandLight
    /** Выбранное сообщение в режиме выделения. */
    val SelectionBand = Color(0x338A7FCB)
    val Hint = NuvaColors.TextMid
    val ChipBg = Color(0xD91F1C2A)
    /** Красная точка записи голосового. */
    val RecordDot = Color(0xFFFF5A5F)

    private val GradLight = Color(0xFF7366BA)
    private val GradDeep = Color(0xFF5B4F9B)

    /**
     * Градиент исходящих (цвета 0.2.3: #7366BA → #5B4F9B) привязан к ЭКРАНУ, а не к пузырю: сверху справа
     * светлее, снизу слева глубже. Координаты — в системе самого пузыря: [hostOrigin] — левый верх чата
     * относительно пузыря.
     */
    fun outgoingBrush(hostOrigin: Offset, host: Size): Brush = Brush.linearGradient(
        colors = listOf(GradLight, GradDeep),
        start = Offset(hostOrigin.x + host.width, hostOrigin.y),
        end = Offset(hostOrigin.x, hostOrigin.y + host.height),
    )
}

/** Положение и размер области чата в корне окна: от них зависит общий градиент пузырей. */
@Stable
class GradientHost {
    var origin by mutableStateOf(Offset.Zero)
    var size by mutableStateOf(Size.Zero)
}

val LocalGradientHost = staticCompositionLocalOf { GradientHost() }
