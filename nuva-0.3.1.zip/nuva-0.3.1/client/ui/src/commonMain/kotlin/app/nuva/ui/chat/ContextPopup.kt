package app.nuva.ui.chat

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

enum class PopupIcon { Reply, Copy, Retry, Delete }

class PopupAction(val label: String, val icon: PopupIcon, val onClick: () -> Unit)

/** Быстрые реакции в полосе: первые 7. Остальные — по кнопке «развернуть». */
internal val QuickReactions = listOf("👍", "👎", "❤️", "🔥", "😁", "😮", "😢")
private val MoreReactions = listOf(
    "🙏", "👏", "🎉", "💯", "🤔", "😡", "🥰",
    "🤝", "😎", "🤯", "😭", "🤮", "💔", "🙈",
)

// Геометрия мини-блока (dp), снята с ролика.
private const val STRIP_W = 290f
private const val STRIP_H = 46f
private const val CELL = 34f
private const val GAP = 11f
private const val MENU_W = 192f
private const val ITEM_H = 46f
private const val MENU_PAD = 4f
private const val EDGE = 6f
private const val MENU_RIGHT_FROM_TOUCH = 28f
private const val STRIP_SHIFT_RIGHT = 8f

/**
 * Мини-блок по нажатию на сообщение: полоса реакций 46dp и под ней меню (пункты по 46dp, радиус 12dp).
 * Позиция считается от точки касания [anchor] (px, координаты чата): правый край меню = касание + 28dp,
 * по бокам не ближе 6dp к краю, а если снизу не хватает места — блок сдвигается вверх.
 * Открывается из правого верхнего угла (масштаб 0.5→1 за ~80мс), полоса реакций разворачивается справа
 * налево с небольшим перелётом, закрывается за ~65мс. Фон не затемняется.
 */
@Composable
internal fun MessageContextPopup(
    anchor: Offset,
    hostSize: Size,
    topInsetPx: Float,
    myReaction: String?,
    actions: List<PopupAction>,
    onReact: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    val dens = LocalDensity.current
    val dp = dens.density
    val scope = rememberCoroutineScope()
    val p = remember { Animatable(0f) }
    val pStrip = remember { Animatable(0f) }
    var closing by remember { mutableStateOf(false) }
    var expanded by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        launch { p.animateTo(1f, tween(80, easing = FastOutSlowInEasing)) }
        // Перелёт: кубик Безье с выходом за 1.
        pStrip.animateTo(1f, tween(230, easing = CubicBezierEasing(0.2f, 1.45f, 0.4f, 1f)))
    }

    fun close(after: () -> Unit = {}) {
        if (closing) return
        closing = true
        scope.launch {
            launch { pStrip.animateTo(0f, tween(65)) }
            p.animateTo(0f, tween(65))
            onDismiss()
            after()
        }
    }

    // ── геометрия, px
    val w = hostSize.width
    val h = hostSize.height
    val edge = EDGE * dp
    val menuW = MENU_W * dp
    val menuH = (actions.size * ITEM_H + 2 * MENU_PAD) * dp
    val stripW = STRIP_W * dp
    val stripH = STRIP_H * dp
    val gap = GAP * dp

    val extraRows = (MoreReactions.size + 6) / 7
    val panelH = (STRIP_H + extraRows * 40f) * dp  // развёрнутая панель: строка быстрых + дополнительные

    val menuRight = (anchor.x + MENU_RIGHT_FROM_TOUCH * dp).coerceIn(edge + menuW, kotlin.math.max(w - edge, edge + menuW))
    val menuLeft = menuRight - menuW
    val stripCenter = (menuLeft + menuW / 2f + STRIP_SHIFT_RIGHT * dp)
        .coerceIn(edge + stripW / 2f, kotlin.math.max(w - edge - stripW / 2f, edge + stripW / 2f))
    val stripLeft = stripCenter - stripW / 2f

    val blockH = if (expanded) panelH else stripH + gap + menuH
    var top = anchor.y - stripH / 2f
    top = top.coerceAtMost(h - edge - blockH).coerceAtLeast(topInsetPx + edge)

    Box(
        Modifier
            .fillMaxSize()
            // Нажатие мимо закрывает блок. Фон не затемняем.
            .pointerInput(Unit) { detectTapGestures { close() } },
    ) {
        // Полоса реакций (в развёрнутом виде — панель)
        val stripRadius by animateFloatAsState(if (expanded) 20f else 23f, tween(120), label = "stripRadius")
        Column(
            Modifier
                .offset { IntOffset(stripLeft.roundToInt(), top.roundToInt()) }
                .width(STRIP_W.dp)
                .graphicsLayer {
                    val s = pStrip.value
                    scaleX = 0.35f + 0.65f * s
                    scaleY = 0.75f + 0.25f * s
                    alpha = p.value.coerceIn(0f, 1f)
                    transformOrigin = TransformOrigin(1f, 0.5f)
                }
                .clip(RoundedCornerShape(stripRadius.dp))
                .background(ChatColors.Popup)
                // Съедаем нажатия, чтобы они не закрывали блок.
                .pointerInput(Unit) { detectTapGestures { } },
        ) {
            ReactionRow(
                emojis = QuickReactions,
                myReaction = myReaction,
                trailing = {
                    Box(
                        Modifier.size(CELL.dp).clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                        ) { expanded = !expanded },
                        contentAlignment = Alignment.Center,
                    ) {
                        Box(
                            Modifier.size(28.dp).background(Color.White.copy(alpha = 0.14f), CircleShape),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(
                                Icons.Filled.KeyboardArrowDown, null,
                                Modifier.size(18.dp).graphicsLayer { rotationZ = if (expanded) 180f else 0f },
                                tint = Color.White,
                            )
                        }
                    }
                },
                onPick = { e -> onReact(e); close() },
            )
            if (expanded) {
                MoreReactions.chunked(7).forEach { row ->
                    ReactionRow(emojis = row, myReaction = myReaction, trailing = null, onPick = { e -> onReact(e); close() })
                }
                Spacer(Modifier.height(4.dp))
            }
        }

        // Меню
        if (!expanded) {
            Column(
                Modifier
                    .offset { IntOffset(menuLeft.roundToInt(), (top + stripH + gap).roundToInt()) }
                    .width(MENU_W.dp)
                    .graphicsLayer {
                        val s = 0.5f + 0.5f * p.value
                        scaleX = s
                        scaleY = s
                        alpha = p.value.coerceIn(0f, 1f)
                        transformOrigin = TransformOrigin(1f, 0f)
                    }
                    .clip(RoundedCornerShape(12.dp))
                    .background(ChatColors.Popup)
                    .padding(vertical = MENU_PAD.dp)
                    .pointerInput(Unit) { detectTapGestures { } },
            ) {
                for (a in actions) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .height(ITEM_H.dp)
                            .clickable { close { a.onClick() } }
                            .padding(start = 20.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        PopupGlyph(a.icon)
                        Spacer(Modifier.width(18.dp))
                        Text(a.label, fontSize = 15.sp, color = Color.White, maxLines = 1)
                    }
                }
            }
        }
    }
}

@Composable
private fun ReactionRow(
    emojis: List<String>,
    myReaction: String?,
    trailing: (@Composable () -> Unit)?,
    onPick: (String) -> Unit,
) {
    Row(
        Modifier.fillMaxWidth().height(if (trailing != null) STRIP_H.dp else 40.dp).padding(horizontal = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        for (e in emojis) {
            Box(
                Modifier
                    .size(CELL.dp)
                    .clip(CircleShape)
                    .background(if (e == myReaction) Color.White.copy(alpha = 0.16f) else Color.Transparent)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                    ) { onPick(e) },
                contentAlignment = Alignment.Center,
            ) {
                Text(e, fontSize = 22.sp)
            }
        }
        trailing?.invoke()
    }
}

@Composable
private fun PopupGlyph(icon: PopupIcon) {
    val tint = Color.White.copy(alpha = 0.92f)
    when (icon) {
        PopupIcon.Reply -> ReplyIcon(tint, 22.dp)
        PopupIcon.Copy -> CopyIcon(tint, 22.dp)
        PopupIcon.Retry -> Icon(Icons.Filled.Refresh, null, Modifier.size(22.dp), tint = tint)
        PopupIcon.Delete -> Icon(Icons.Filled.Delete, null, Modifier.size(22.dp), tint = Color(0xFFFF6B6B))
    }
}
