package app.nuva.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import app.nuva.core.chat.MsgStatus

/**
 * ◷ ожидает отправки · ✓ ушло на сервер / доставлено на устройство · ✓✓ собеседник РЕАЛЬНО прочитал
 * (сообщение было у него на экране при открытом приложении) · ! ошибка. Как в Telegram.
 */
@Composable
fun StatusTicks(status: MsgStatus, color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier.size(width = 18.dp, height = 12.dp)) {
        val w = size.width
        val h = size.height
        val sw = 1.6.dp.toPx()
        val stroke = Stroke(width = sw, cap = StrokeCap.Round, join = StrokeJoin.Round)
        fun check(dx: Float) {
            val p = Path().apply {
                moveTo(dx + w * 0.05f, h * 0.55f)
                lineTo(dx + w * 0.25f, h * 0.85f)
                lineTo(dx + w * 0.62f, h * 0.15f)
            }
            drawPath(p, color, style = stroke)
        }
        when (status) {
            MsgStatus.PENDING -> {
                val c = Offset(w * 0.55f, h / 2f)
                val r = h * 0.42f
                drawCircle(color, radius = r, center = c, style = Stroke(width = sw))
                drawLine(color, c, Offset(c.x, c.y - r * 0.6f), strokeWidth = sw, cap = StrokeCap.Round)
                drawLine(color, c, Offset(c.x + r * 0.45f, c.y), strokeWidth = sw, cap = StrokeCap.Round)
            }
            MsgStatus.SENT, MsgStatus.DELIVERED -> check(w * 0.2f)
            MsgStatus.READ -> {
                check(0f)
                check(w * 0.32f)
            }
            MsgStatus.FAILED -> {
                val c = Offset(w * 0.55f, h / 2f)
                drawCircle(Color(0xFFFF6B7A), radius = h * 0.5f, center = c)
                drawLine(Color.White, Offset(c.x, c.y - h * 0.25f), Offset(c.x, c.y + h * 0.05f), strokeWidth = sw, cap = StrokeCap.Round)
                drawCircle(Color.White, radius = sw * 0.6f, center = Offset(c.x, c.y + h * 0.25f))
            }
            MsgStatus.INCOMING -> Unit
        }
    }
}
