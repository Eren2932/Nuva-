package app.nuva.ui.profile

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.nuva.core.net.SocketState
import app.nuva.ui.AppGraph
import app.nuva.ui.HostBridge
import app.nuva.ui.components.Avatar
import app.nuva.ui.components.NuvaTopBar
import app.nuva.ui.components.hexGrid
import app.nuva.ui.nav.Screen
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun ProfileScreen(graph: AppGraph) {
    val acc by graph.core.account.collectAsState()
    val socket by graph.core.socket.state.collectAsState()
    var confirm by remember { mutableStateOf(false) }
    val a = acc ?: return

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        NuvaTopBar {
            IconButton(onClick = { graph.router.back() }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Назад")
            }
            Text("Профиль", style = MaterialTheme.typography.titleLarge)
        }
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).navigationBarsPadding().padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(Modifier.height(12.dp))
            Avatar(a.accountId, a.displayName, 96.dp)
            Spacer(Modifier.height(14.dp))
            Text(a.displayName, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center)
            Text("@${a.username}", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.secondary)
            Spacer(Modifier.height(24.dp))

            Card {
                InfoRow("Сервер", graph.core.serverHost)
                InfoRow("Соединение", when (socket) {
                    SocketState.Online -> "в сети"
                    SocketState.Syncing -> "обновление…"
                    SocketState.Connecting, SocketState.Offline -> "соединение…"
                    SocketState.Rejected -> "устройство не авторизовано"
                })
                InfoRow("Версия", graph.core.versionName)
            }
            Spacer(Modifier.height(14.dp))
            if (graph.host.supportsBackground) {
                NotificationsCard(graph.host)
                Spacer(Modifier.height(14.dp))
            }
            Card {
                Text("Ключ этого устройства", style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(8.dp))
                Text(hexGrid(a.identity.ikPub), fontFamily = FontFamily.Monospace, fontSize = 14.sp, lineHeight = 21.sp)
                Spacer(Modifier.height(8.dp))
                Text("Приватная часть хранится только здесь и никогда не передаётся.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.height(14.dp))
            Card(Modifier.clickable { confirm = true }) {
                Text("Выйти и удалить данные с устройства", color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
            }
        }
    }
    if (confirm) ResetAccountDialog(graph, onDismiss = { confirm = false })
}

/**
 * Уведомления и фоновая работа. Без Firebase сообщения в фоне приходят, пока жива служба приёма
 * (тихая постоянная иконка). Прошивки вроде ColorOS/Realme её убивают, если не снять ограничения батареи.
 */
@Composable
private fun NotificationsCard(host: HostBridge) {
    var enabled by remember { mutableStateOf(host.backgroundEnabled()) }
    var allowed by remember { mutableStateOf(host.notificationsAllowed()) }
    LaunchedEffect(Unit) {
        while (true) {
            allowed = host.notificationsAllowed()
            delay(1000)
        }
    }
    Card {
        Text("Уведомления", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Приём сообщений в фоне", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
                Text("Служба держит защищённое соединение, чтобы уведомления приходили при закрытом приложении.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.width(12.dp))
            Switch(checked = enabled, onCheckedChange = { enabled = it; host.setBackgroundEnabled(it) })
        }
        if (!allowed) {
            Spacer(Modifier.height(12.dp))
            Text("Уведомления выключены — нажмите, чтобы разрешить", Modifier.fillMaxWidth().clickable { host.requestNotifications() }.padding(vertical = 6.dp),
                color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Medium)
        }
        Spacer(Modifier.height(8.dp))
        Text("Снять ограничения батареи", Modifier.fillMaxWidth().clickable { host.openBatterySettings() }.padding(vertical = 8.dp),
            color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Medium)
        Text("Автозапуск и права приложения", Modifier.fillMaxWidth().clickable { host.openAppSettings() }.padding(vertical = 8.dp),
            color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Medium)
        Text("На ColorOS, MIUI и похожих прошивках разрешите автозапуск и уберите Nuva из ограничений батареи, иначе система остановит приём.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun Card(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Surface(Modifier.fillMaxWidth(), color = MaterialTheme.colorScheme.surfaceContainer, shape = RoundedCornerShape(16.dp)) {
        Column(modifier.fillMaxWidth().padding(16.dp)) { content() }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, fontWeight = FontWeight.Medium)
    }
}

/**
 * Удаление учётки с устройства. Ключи нигде больше не хранятся (мультиустройств пока нет),
 * поэтому это необратимо: переписка и аккаунт на этом устройстве пропадают навсегда.
 */
@Composable
fun ResetAccountDialog(graph: AppGraph, onDismiss: () -> Unit) {
    var busy by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        title = { Text("Удалить данные?") },
        text = {
            Text("Ключи и вся переписка будут стёрты с этого устройства без возможности восстановления. " +
                "Для нового входа понадобится новое приглашение.")
        },
        confirmButton = {
            TextButton(enabled = !busy, onClick = {
                busy = true
                graph.scope.launch {
                    graph.core.resetLocal()
                    graph.router.replaceAll(Screen.Welcome)
                }
            }) { Text("Удалить", color = MaterialTheme.colorScheme.error) }
        },
        dismissButton = { TextButton(enabled = !busy, onClick = onDismiss) { Text("Отмена") } },
    )
}
