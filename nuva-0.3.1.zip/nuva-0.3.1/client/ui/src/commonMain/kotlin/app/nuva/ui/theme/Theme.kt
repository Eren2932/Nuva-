package app.nuva.ui.theme

import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

/** Палитра Nuva. Базовый цвет — PANTONE 18-3840 «роскошный фиолетовый», #6559A3. */
object NuvaColors {
    val Brand = Color(0xFF6559A3)
    val BrandLight = Color(0xFF8A7FCB)
    val BrandSoft = Color(0xFFBDB4EE)
    val BrandDeep = Color(0xFF453B7E)

    val Night = Color(0xFF0F0E15)      // фон, он же фон системной заставки (без вспышек)
    val Surface1 = Color(0xFF17151F)
    val Surface2 = Color(0xFF1F1C2A)
    val Surface3 = Color(0xFF292536)
    val TextHigh = Color(0xFFECEAF4)
    val TextMid = Color(0xFFA29DB4)
    val Outline = Color(0xFF3A3650)
    val Danger = Color(0xFFFF6B7A)
    val Online = Color(0xFF7FD4A0)

    val OutgoingBubble = Brush.linearGradient(listOf(Color(0xFF5B4F9B), Color(0xFF7366BA)))
    val IncomingBubble = Surface2
}

private val Dark = darkColorScheme(
    primary = NuvaColors.Brand,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF2B2648),
    onPrimaryContainer = Color(0xFFE4DFFF),
    secondary = NuvaColors.BrandSoft,
    onSecondary = Color(0xFF1E1A33),
    secondaryContainer = Color(0xFF2B2648),
    onSecondaryContainer = Color(0xFFE4DFFF),
    tertiary = NuvaColors.BrandLight,
    background = NuvaColors.Night,
    onBackground = NuvaColors.TextHigh,
    surface = NuvaColors.Night,
    onSurface = NuvaColors.TextHigh,
    surfaceVariant = NuvaColors.Surface2,
    onSurfaceVariant = NuvaColors.TextMid,
    surfaceContainerLowest = Color(0xFF0B0A10),
    surfaceContainerLow = Color(0xFF13121A),
    surfaceContainer = NuvaColors.Surface1,
    surfaceContainerHigh = NuvaColors.Surface2,
    surfaceContainerHighest = NuvaColors.Surface3,
    outline = NuvaColors.Outline,
    outlineVariant = Color(0xFF2A2738),
    error = NuvaColors.Danger,
    onError = Color(0xFF2D0008),
)

private val Light = lightColorScheme(
    primary = NuvaColors.Brand,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE6E1FF),
    onPrimaryContainer = Color(0xFF1E1650),
    secondary = NuvaColors.BrandDeep,
    background = Color.White,
    surface = Color.White,
    surfaceVariant = Color(0xFFF1EFF8),
    onSurfaceVariant = Color(0xFF5F5A70),
    outline = Color(0xFFCAC5DA),
)

/** 0.2: тёмная тема — основная (утверждено). Светлая схема готова для будущего переключателя. */
@Composable
fun NuvaTheme(dark: Boolean = true, content: @Composable () -> Unit) {
    val scheme = if (dark) Dark else Light
    // MaterialTheme не задаёт цвет контента по умолчанию: вне Surface/Scaffold Text и Icon берут
    // LocalContentColor = чёрный. Из-за этого заголовки онбординга были чёрными на тёмном фоне.
    MaterialTheme(colorScheme = scheme) {
        CompositionLocalProvider(LocalContentColor provides scheme.onBackground, content = content)
    }
}
