package app.nuva.ui.voice

import app.nuva.core.voice.VoiceClip
import app.nuva.core.voice.VoiceRecording

/**
 * Аудио платформы для голосовых. Реализации — в app-android (AudioRecord/AudioTrack) и app-desktop
 * (javax.sound). UI работает только через этот контракт.
 *
 * Правило: ни один метод не блокирует главный поток. Открытие микрофона, создание AudioTrack, аудиофокус —
 * всё это binder-вызовы на десятки/сотни миллисекунд, из-за них раньше «подпрыгивала» анимация записи.
 */
interface VoiceAudio {
    /** Есть ли доступ к микрофону прямо сейчас. */
    fun micAllowed(): Boolean = true

    /** Запросить доступ. [onResult] вызывается на главном потоке. */
    fun requestMic(onResult: (Boolean) -> Unit) = onResult(true)

    fun recorder(): VoiceRecorder
    fun player(): VoicePlayer
}

/**
 * Захват микрофона. Кадры сразу кодируются в Opus ([app.nuva.core.voice.VoiceCapture]), так что
 * [finish] отдаёт готовую запись почти мгновенно.
 */
interface VoiceRecorder {
    /** Не блокирует: микрофон открывается в фоновом потоке. Не открылся — [failed] станет true. */
    fun start()

    /** Микрофон занят/недоступен/оборвался. */
    val failed: Boolean

    /** Громкость последних ~20 мс, 0..1. Читается каждый кадр. */
    val level: Float

    /** Длительность записанного без учёта пауз, мс (0, пока микрофон не открылся). */
    val durationMs: Long

    /** Пауза: микрофон читается дальше, но отсчёты не копятся. */
    var paused: Boolean

    /** Останавливает запись и отдаёт NVO2; null — пусто или сбой. Один раз. */
    suspend fun finish(): VoiceRecording?

    fun cancel()
}

/**
 * Проигрыватель. Один на экран чата: новый [play] останавливает предыдущий.
 * Читает PCM прямо из [VoiceClip] по мере декодирования.
 */
interface VoicePlayer {
    /** Играть [clip] с отсчёта [from]. Возвращается сразу, звук начнётся в фоновом потоке. */
    fun play(clip: VoiceClip, from: Int)

    /** Позиция в отсчётах от начала клипа. */
    val position: Int

    /** false — остановлен или доиграл до конца. */
    val isPlaying: Boolean

    /** Не блокирует. */
    fun stop()
}
