package app.nuva.ui.voice

import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import app.nuva.core.chat.ChatMessage
import app.nuva.core.voice.VoiceClip
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.emptyFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Воспроизведение голосовых в открытом чате. Одновременно играет одно сообщение. Позиция каждого
 * сообщения запоминается (пауза → продолжить с того же места). Прогресс обновляется раз в кадр
 * из позиции проигрывателя — без таймеров и рассинхрона со звуком.
 *
 * @param load байты голосового (NVO2/Opus или старый NVOI; null — ещё не скачано)
 * @param onListened входящее начали слушать
 * @param next следующее голосовое для автопроигрывания (входящее непрослушанное ниже по ленте)
 */
@Stable
class VoicePlayback(
    private val audio: VoiceAudio?,
    private val scope: CoroutineScope,
    private val load: suspend (ChatMessage) -> ByteArray?,
    private val onListened: (ChatMessage) -> Unit,
    private val next: (ChatMessage) -> ChatMessage?,
    transfers: Flow<Map<String, Float>> = emptyFlow(),
) {
    val available: Boolean get() = audio != null

    /** Ключ играющего (или загружаемого) сообщения. */
    var currentKey by mutableStateOf<String?>(null)
        private set
    var playing by mutableStateOf(false)
        private set
    /** Текущая позиция играющего, мс. */
    var positionMs by mutableStateOf(0L)
        private set

    private val progress = mutableStateMapOf<String, Float>()

    // Прогресс загрузки/скачивания блобов по client_msg_id (из Messenger.transfers).
    private var transferState by mutableStateOf<Map<String, Float>>(emptyMap())
    private val transferJob = scope.launch { transfers.collect { transferState = it } }

    fun transferOf(msg: ChatMessage): Float? = transferState[msg.clientMsgId]
    // Клип 10-минутной записи — ~19 МБ PCM, поэтому кэш маленький.
    private val cache = LinkedHashMap<String, VoiceClip>(2, 0.75f, true)
    private var player: VoicePlayer? = null
    private var job: Job? = null

    fun isCurrent(msg: ChatMessage): Boolean = currentKey == key(msg)
    fun isPlaying(msg: ChatMessage): Boolean = playing && isCurrent(msg)
    fun progressOf(msg: ChatMessage): Float = progress[key(msg)] ?: 0f

    fun toggle(msg: ChatMessage) {
        if (isPlaying(msg)) pause() else start(msg, progressOf(msg).let { if (it >= 0.995f) 0f else it })
    }

    /** Перемотка на долю [f]. Если сообщение играет — продолжает с новой точки. */
    fun seek(msg: ChatMessage, f: Float) {
        val v = f.coerceIn(0f, 1f)
        progress[key(msg)] = v
        if (isPlaying(msg)) start(msg, v)
    }

    fun pause() {
        job?.cancel()
        job = null
        player?.stop()
        playing = false
    }

    fun release() {
        transferJob.cancel()
        pause()
        currentKey = null
        cache.clear()
        player = null
    }

    private fun start(msg: ChatMessage, from: Float) {
        val a = audio ?: return
        val v = msg.voice ?: return
        if (!v.ready) return
        val prev = job
        prev?.cancel()
        player?.stop() // не блокирует
        val k = key(msg)
        currentKey = k
        playing = true
        job = scope.launch {
            // Предыдущая корутина вместе со своим декодером должна закончиться до нас: клип общий.
            prev?.join()
            val clip = cache[k] ?: withContext(Dispatchers.Default) {
                load(msg)?.let { VoiceClip.open(it) }
            }?.also {
                cache[k] = it
                while (cache.size > 2) cache.remove(cache.keys.first())
            }
            if (clip == null || clip.totalSamples <= 0) {
                playing = false
                if (currentKey == k) currentKey = null
                return@launch
            }
            val total = clip.totalSamples
            val rate = clip.sampleRate
            val at = (from * total).toInt().coerceIn(0, total - 1)
            // Декодируем параллельно с воспроизведением: звук начинается через ~100 мс, а не после декода всей записи.
            val decoder = if (clip.isFullyDecoded) null else launch(Dispatchers.Default) {
                clip.decode(at) { isActive }
            }
            val p = player ?: a.player().also { player = it }
            p.play(clip, at)
            if (!msg.outgoing && !v.listened) onListened(msg)
            while (isActive) {
                withFrameNanos { }
                val pos = p.position.coerceIn(0, total)
                progress[k] = pos.toFloat() / total
                positionMs = pos * 1000L / rate
                if (!p.isPlaying) break
            }
            decoder?.cancel()
            if (!isActive) return@launch
            p.stop() // освобождаем аудиовыход сразу, а не при следующем play()
            // Доиграли: сброс в начало, как в референсе, и автопереход к следующему непрослушанному.
            progress[k] = 0f
            playing = false
            currentKey = null
            next(msg)?.let { start(it, 0f) }
        }
    }

    private fun key(msg: ChatMessage): String = (if (msg.outgoing) "o:" else "i:") + msg.clientMsgId
}
