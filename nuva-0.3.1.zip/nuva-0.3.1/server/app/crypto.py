"""Серверная часть крипто v1: только проверка подписей и кодирование (§4).

Сервер никогда не шифрует и не расшифровывает. Форматы payload — байт-в-байт как в
tools/vectors.py (эталон); tests/test_crypto.py сверяет их с test-vectors.json.
"""
from __future__ import annotations

import base64
import binascii
import hashlib
import hmac
import re
import secrets
import time
import uuid

from nacl.exceptions import BadSignatureError
from nacl.signing import VerifyKey

SEP = b"\x00"
LABEL_XK = b"NUVA-XK-V1"
LABEL_AUTH = b"NUVA-AUTH-V1"
LABEL_REG = b"NUVA-REG-V1"
LABEL_HTTP = b"NUVA-HTTP-V1"

NONCE_LEN = 32
KEY_LEN = 32
SIG_LEN = 64

_B64URL_RE = re.compile(r"^[A-Za-z0-9_-]*$")


class B64Error(ValueError):
    pass


def b64url_encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def b64url_decode(text: str) -> bytes:
    """Строгий base64url без паддинга: лишние символы, '=' и неканонический хвост — ошибка."""
    if not isinstance(text, str) or not _B64URL_RE.fullmatch(text) or len(text) % 4 == 1:
        raise B64Error("invalid base64url")
    try:
        raw = base64.urlsafe_b64decode(text + "=" * (-len(text) % 4))
    except (binascii.Error, ValueError) as exc:
        raise B64Error("invalid base64url") from exc
    if b64url_encode(raw) != text:  # отсекаем неканонические младшие биты
        raise B64Error("non-canonical base64url")
    return raw


def verify_ed25519(public_key: bytes, payload: bytes, signature: bytes) -> bool:
    if len(public_key) != KEY_LEN or len(signature) != SIG_LEN:
        return False
    try:
        VerifyKey(public_key).verify(payload, signature)
        return True
    except (BadSignatureError, ValueError, TypeError):
        return False


def xk_payload(xk_pub: bytes) -> bytes:
    return LABEL_XK + SEP + xk_pub


def auth_payload(host: str, device_id: uuid.UUID, nonce: bytes) -> bytes:
    return LABEL_AUTH + SEP + host.encode("ascii") + SEP + device_id.bytes + nonce


def reg_payload(host: str, nonce: bytes, ik_pub: bytes, xk_pub: bytes, username: str) -> bytes:
    return (LABEL_REG + SEP + host.encode("ascii") + SEP + nonce + ik_pub + xk_pub
            + username.encode("utf-8"))


def http_payload(host: str, device_id: uuid.UUID, ts: int, method: str, target: str,
                 body_sha256: bytes) -> bytes:
    """Подпись HTTP-запроса устройства (блобы, аватарки). Зеркало NuvaCrypto.httpPayload.

    target — путь вместе с query ровно в том виде, в каком он ушёл по сети ("/blob/<id>?to=<id>").
    Хеш тела входит в подпись: подменить тело или переиспользовать подпись для другого запроса нельзя.
    """
    return (LABEL_HTTP + SEP + host.encode("ascii") + SEP + device_id.bytes + ts.to_bytes(8, "big")
            + method.encode("ascii") + SEP + target.encode("ascii") + SEP + body_sha256)


def new_nonce() -> bytes:
    return secrets.token_bytes(NONCE_LEN)


# ── Инвайты: XXXXX-XXXXX, Crockford Base32 (без I L O U), 50 бит ──

CROCKFORD = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"
_CROCKFORD_ALIASES = str.maketrans({"I": "1", "L": "1", "O": "0"})
INVITE_LEN = 10


def generate_invite_code() -> str:
    raw = "".join(secrets.choice(CROCKFORD) for _ in range(INVITE_LEN))
    return f"{raw[:5]}-{raw[5:]}"


def normalize_invite(code: str) -> str:
    """upper, без дефисов/пробелов; I/L→1, O→0 (человек путает при наборе)."""
    return "".join(ch for ch in code.upper() if ch not in "- \t").translate(_CROCKFORD_ALIASES)


def invite_hash(code: str) -> bytes:
    return hashlib.sha256(normalize_invite(code).encode("ascii", "replace")).digest()


def invite_well_formed(code: str) -> bool:
    n = normalize_invite(code)
    return len(n) == INVITE_LEN and all(c in CROCKFORD for c in n)


def consteq(a: bytes, b: bytes) -> bool:
    return hmac.compare_digest(a, b)


# ── UUIDv7 (RFC 9562): время в префиксе — дружит с B-tree индексами ──

def uuid7() -> uuid.UUID:
    ts_ms = time.time_ns() // 1_000_000
    rand = int.from_bytes(secrets.token_bytes(10), "big")
    rand_a = rand >> 68 & 0xFFF          # 12 бит
    rand_b = rand & ((1 << 62) - 1)      # 62 бита
    value = ((ts_ms & ((1 << 48) - 1)) << 80) | (0x7 << 76) | (rand_a << 64) | (0b10 << 62) | rand_b
    return uuid.UUID(int=value)
