"""profile.set и user.lookup (протокол 0.2, §5.8; 0.3 — avatar_ver в user.info).

Имя/фамилия — публичная часть профиля, как и юзернейм: их видит любой, кто знает @username.
Поиск только по ТОЧНОМУ юзернейму или account_id — префиксный поиск отдал бы базу перебором.
"""
from __future__ import annotations

import logging

from .. import protocol
from ..protocol import ProfileSet, UserLookup
from . import Session, within_rate
from .register import USERNAME_RE

log = logging.getLogger("nuva.profile")

_SQL_SET_PROFILE = """
UPDATE accounts SET first_name = $2, last_name = $3 WHERE id = $1 AND status = 'active'
"""

_SQL_BY_USERNAME = """
SELECT id, username, first_name, last_name, avatar_ver FROM accounts WHERE username = $1 AND status = 'active'
"""

_SQL_BY_ID = """
SELECT id, username, first_name, last_name, avatar_ver FROM accounts WHERE id = $1 AND status = 'active'
"""

_SQL_DEVICES = """
SELECT id, identity_key, x25519_key, x25519_sig
  FROM devices
 WHERE account_id = $1 AND revoked_at IS NULL
 ORDER BY created_at
"""


async def handle_profile_set(s: Session, frame: ProfileSet) -> None:
    async with s.pool.acquire() as con:
        await con.execute(_SQL_SET_PROFILE, s.account_id, frame.first_name, frame.last_name)
    # Возвращаем нормализованные значения: клиент хранит ровно то, что видят другие.
    await s.conn.send(protocol.profile_ok(frame.id, frame.first_name, frame.last_name))


async def handle_user_lookup(s: Session, frame: UserLookup) -> None:
    if not within_rate(s.lookup_times, s.settings.lookups_per_minute):
        await s.conn.send(protocol.error(protocol.E_RATE_LIMITED, frame.id, "too many lookups"))
        return

    async with s.pool.acquire() as con:
        if frame.username is not None:
            username = frame.username.strip().removeprefix("@").lower()
            row = (await con.fetchrow(_SQL_BY_USERNAME, username)
                   if USERNAME_RE.fullmatch(username) else None)
        else:
            row = await con.fetchrow(_SQL_BY_ID, frame.account_id)
        devices = await con.fetch(_SQL_DEVICES, row["id"]) if row is not None else []

    # Аккаунт без активных устройств писать некуда — для клиента он не существует.
    if row is None or not devices:
        await s.conn.send(protocol.error(protocol.E_NOT_FOUND, frame.id))
        return
    await s.conn.send(protocol.user_info(
        frame.id, row["id"], row["username"], row["first_name"], row["last_name"],
        [protocol.device_info(d["id"], bytes(d["identity_key"]), bytes(d["x25519_key"]),
                              bytes(d["x25519_sig"])) for d in devices],
        avatar_ver=row["avatar_ver"],
    ))
