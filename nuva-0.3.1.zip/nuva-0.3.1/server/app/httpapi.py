"""HTTP-часть протокола 0.3: зашифрованные блобы (голосовые) и публичные аватарки.

Зачем отдельно от WebSocket: куски голосового как отдельные конверты упирались в лимит отправок и
вставали в одну очередь с обычными сообщениями. Теперь запись шифруется на устройстве случайным ключом,
уходит ОДНИМ PUT-запросом, а получателю летит одно маленькое сообщение (id блоба + ключ).

Аутентификация — подпись устройства (Ed25519, тот же ключ, что и при входе по WebSocket):
    X-Nuva-Device: <device_id>
    X-Nuva-Ts:     <unix-секунды>
    X-Nuva-Sha256: <hex SHA-256 тела>   (для GET/DELETE — хеш пустого тела)
    X-Nuva-Sig:    base64url(sign(crypto.http_payload(...)))
Подпись проверяется ДО чтения тела, а совпадение хеша — после: чужой мусор на диск не попадает.
"""
from __future__ import annotations

import asyncio
import hashlib
import logging
import os
import shutil
import time
import uuid
from collections import deque
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Request
from fastapi.responses import FileResponse, JSONResponse, Response

from . import crypto
from .config import Settings
from .handlers import within_rate

log = logging.getLogger("nuva.http")

router = APIRouter()

EMPTY_SHA256 = hashlib.sha256(b"").digest()
_NO_STORE = {"Cache-Control": "no-store"}
_HEX = set("0123456789abcdef")


class ApiError(Exception):
    def __init__(self, status: int, code: str, **extra: Any):
        super().__init__(code)
        self.status = status
        self.code = code
        self.extra = extra


async def api_error_handler(_: Request, exc: Exception) -> JSONResponse:
    assert isinstance(exc, ApiError)
    headers = dict(_NO_STORE)
    if exc.status == 401:
        headers["X-Nuva-Server-Time"] = str(int(time.time()))
    return JSONResponse({"error": exc.code, **exc.extra}, status_code=exc.status, headers=headers)


@dataclass(slots=True)
class Caller:
    device_id: uuid.UUID
    account_id: uuid.UUID


# ───────────────────────── общие помощники ─────────────────────────

_SQL_DEVICE = """
SELECT d.account_id, d.identity_key, d.revoked_at, a.status
  FROM devices d
  JOIN accounts a ON a.id = d.account_id
 WHERE d.id = $1
"""


def _parse_uuid(text: str | None) -> uuid.UUID:
    try:
        if text is None:
            raise ValueError
        return uuid.UUID(text)
    except (ValueError, AttributeError, TypeError):
        raise ApiError(400, "bad_id") from None


def _claimed_hash(request: Request, has_body: bool) -> bytes:
    if not has_body:
        return EMPTY_SHA256
    raw = request.headers.get("x-nuva-sha256", "").lower()
    if len(raw) != 64 or not set(raw) <= _HEX:
        raise ApiError(400, "bad_hash")
    return bytes.fromhex(raw)


async def authenticate(request: Request, body_sha256: bytes) -> Caller:
    """Проверяет подпись устройства. Любая причина отказа — один и тот же 401 (не раскрываем, что есть что)."""
    settings: Settings = request.app.state.settings
    h = request.headers
    try:
        device_id = uuid.UUID(h["x-nuva-device"])
        ts = int(h["x-nuva-ts"])
        sig = crypto.b64url_decode(h["x-nuva-sig"])
    except (KeyError, ValueError, crypto.B64Error):
        raise ApiError(401, "unauthorized") from None
    now = int(time.time())
    if abs(now - ts) > settings.http_ts_skew_s:
        # Часы клиента ушли: отдаём время сервера, клиент поправит смещение и повторит запрос один раз.
        raise ApiError(401, "clock_skew", server_time=now)
    target = request.url.path + (f"?{request.url.query}" if request.url.query else "")
    async with request.app.state.pool.acquire() as con:
        row = await con.fetchrow(_SQL_DEVICE, device_id)
    payload = crypto.http_payload(settings.server_host, device_id, ts, request.method, target, body_sha256)
    ok = (
        row is not None
        and row["revoked_at"] is None
        and row["status"] == "active"
        and crypto.verify_ed25519(bytes(row["identity_key"]), payload, sig)
    )
    if not ok:
        raise ApiError(401, "unauthorized")
    return Caller(device_id=device_id, account_id=row["account_id"])


def _rate(request: Request, kind: str, key: uuid.UUID, limit: int, window_s: float = 60.0) -> None:
    rates: dict[tuple[str, uuid.UUID], deque[float]] = request.app.state.http_rates
    times = rates.setdefault((kind, key), deque())
    if not within_rate(times, limit, window_s):
        raise ApiError(429, "rate_limited")


def blob_path(settings: Settings, blob_id: uuid.UUID) -> Path:
    return settings.blob_dir / f"{blob_id}.bin"


def _content_length(request: Request, limit: int) -> int:
    raw = request.headers.get("content-length")
    if raw is None:
        raise ApiError(411, "length_required")
    try:
        n = int(raw)
    except ValueError:
        raise ApiError(400, "bad_length") from None
    if n <= 0:
        raise ApiError(400, "empty_body")
    if n > limit:
        raise ApiError(413, "too_large", max=limit)
    return n


async def _read_body(request: Request, declared: int, timeout_s: float, sink) -> tuple[int, bytes]:
    """Стримит тело в sink(chunk) (вызывается в потоке), считая SHA-256 и размер. Лишнее — 413."""
    digest = hashlib.sha256()
    total = 0
    try:
        async with asyncio.timeout(timeout_s):
            async for chunk in request.stream():
                if not chunk:
                    continue
                total += len(chunk)
                if total > declared:
                    raise ApiError(413, "too_large", max=declared)
                digest.update(chunk)
                await asyncio.to_thread(sink, chunk)
    except TimeoutError:
        raise ApiError(408, "timeout") from None
    return total, digest.digest()


def _unlink_quiet(path: Path) -> None:
    try:
        path.unlink()
    except FileNotFoundError:
        pass
    except OSError:
        log.warning("cannot remove %s", path.name)


async def remove_blob(app_state: Any, blob_id: uuid.UUID) -> None:
    async with app_state.pool.acquire() as con:
        await con.execute("DELETE FROM blobs WHERE id = $1", blob_id)
    await asyncio.to_thread(_unlink_quiet, blob_path(app_state.settings, blob_id))


# ───────────────────────── блобы ─────────────────────────

_SQL_RECIPIENT_OK = """
SELECT EXISTS (
  SELECT 1 FROM accounts a
   WHERE a.id = $1 AND a.status = 'active'
     AND EXISTS (SELECT 1 FROM devices d WHERE d.account_id = a.id AND d.revoked_at IS NULL))
"""

_SQL_USED_QUOTA = "SELECT COALESCE(sum(size), 0) FROM blobs WHERE uploader_account = $1 AND id <> $2"

_SQL_UPSERT_BLOB = """
INSERT INTO blobs (id, uploader_account, recipient_account, size, sha256, expires_at)
VALUES ($1, $2, $3, $4, $5, now() + make_interval(days => $6))
ON CONFLICT (id) DO UPDATE
   SET size = EXCLUDED.size, sha256 = EXCLUDED.sha256,
       created_at = now(), expires_at = EXCLUDED.expires_at
 WHERE blobs.uploader_account = EXCLUDED.uploader_account
   AND blobs.recipient_account = EXCLUDED.recipient_account
RETURNING id
"""


@router.put("/blob/{blob_id}")
async def put_blob(blob_id: str, request: Request) -> JSONResponse:
    st = request.app.state
    s: Settings = st.settings
    bid = _parse_uuid(blob_id)
    to = _parse_uuid(request.query_params.get("to"))
    claimed = _claimed_hash(request, has_body=True)
    caller = await authenticate(request, claimed)
    _rate(request, "blob-up", caller.account_id, s.blob_uploads_per_minute)
    size = _content_length(request, s.blob_max_bytes)

    if shutil.disk_usage(s.blob_dir).free - size < s.blob_min_free_bytes:
        raise ApiError(507, "disk_full")
    async with st.pool.acquire() as con:
        if not await con.fetchval(_SQL_RECIPIENT_OK, to):
            raise ApiError(404, "recipient_not_found")
        used = int(await con.fetchval(_SQL_USED_QUOTA, caller.account_id, bid))
    if used + size > s.blob_quota_bytes:
        raise ApiError(507, "quota_exceeded", used=used, quota=s.blob_quota_bytes)

    tmp = s.blob_dir / f"{bid}.{uuid.uuid4().hex[:8]}.part"
    final = blob_path(s, bid)
    async with st.upload_slots:
        f = await asyncio.to_thread(open, tmp, "wb")
        try:
            try:
                got, digest = await _read_body(request, size, s.blob_io_timeout_s, f.write)
                await asyncio.to_thread(f.flush)
                await asyncio.to_thread(os.fsync, f.fileno())
            finally:
                await asyncio.to_thread(f.close)
            if got != size:
                raise ApiError(400, "short_body")
            if not crypto.consteq(digest, claimed):
                raise ApiError(400, "hash_mismatch")
            # Сначала запись в БД с проверкой владельца, и только потом файл встаёт на место: чужой блоб
            # перезаписать нельзя, а при сбое между шагами остаётся запись без файла (GET уберёт её сам).
            async with st.pool.acquire() as con:
                async with con.transaction():
                    ok = await con.fetchval(_SQL_UPSERT_BLOB, bid, caller.account_id, to, size, digest,
                                            s.blob_ttl_days)
                    if ok is None:
                        raise ApiError(409, "id_taken")
                    await con.execute("DELETE FROM blob_acks WHERE blob_id = $1", bid)
            await asyncio.to_thread(os.replace, tmp, final)
        except BaseException:
            await asyncio.to_thread(_unlink_quiet, tmp)
            raise
    return JSONResponse({"id": str(bid), "size": size}, status_code=201, headers=_NO_STORE)


_SQL_BLOB = """
SELECT uploader_account, recipient_account, created_at FROM blobs WHERE id = $1 AND expires_at > now()
"""

_SQL_PENDING = """
SELECT EXISTS (
  SELECT 1 FROM devices d
   WHERE d.account_id = $2 AND d.revoked_at IS NULL AND d.created_at <= $3
     AND NOT EXISTS (SELECT 1 FROM blob_acks a WHERE a.blob_id = $1 AND a.device_id = d.id))
"""


@router.get("/blob/{blob_id}")
async def get_blob(blob_id: str, request: Request) -> Response:
    st = request.app.state
    s: Settings = st.settings
    bid = _parse_uuid(blob_id)
    caller = await authenticate(request, EMPTY_SHA256)
    _rate(request, "blob-down", caller.device_id, s.blob_downloads_per_minute)
    async with st.pool.acquire() as con:
        row = await con.fetchrow(_SQL_BLOB, bid)
    if row is None or caller.account_id not in (row["uploader_account"], row["recipient_account"]):
        raise ApiError(404, "not_found")
    path = blob_path(s, bid)
    if not await asyncio.to_thread(path.is_file):
        await remove_blob(st, bid)  # запись без файла (сбой между rename и INSERT, ручная чистка диска)
        raise ApiError(404, "gone")
    return FileResponse(path, media_type="application/octet-stream", headers=_NO_STORE)


@router.delete("/blob/{blob_id}")
async def ack_blob(blob_id: str, request: Request) -> Response:
    """Квитанция «забрал и сохранил». Получатель — отмечает устройство; отправитель — отзывает блоб."""
    st = request.app.state
    bid = _parse_uuid(blob_id)
    caller = await authenticate(request, EMPTY_SHA256)
    async with st.pool.acquire() as con:
        row = await con.fetchrow(_SQL_BLOB, bid)
        if row is None:
            return Response(status_code=204, headers=_NO_STORE)
        if caller.account_id == row["recipient_account"]:
            await con.execute("INSERT INTO blob_acks (blob_id, device_id) VALUES ($1, $2)"
                              " ON CONFLICT DO NOTHING", bid, caller.device_id)
            pending = await con.fetchval(_SQL_PENDING, bid, row["recipient_account"], row["created_at"])
            drop = not pending
        else:
            drop = caller.account_id == row["uploader_account"]
    if drop:
        await remove_blob(st, bid)
    return Response(status_code=204, headers=_NO_STORE)


# ───────────────────────── аватарки ─────────────────────────

def jpeg_size(data: bytes) -> tuple[int, int] | None:
    """(ширина, высота) из SOF-маркера или None, если это не JPEG. Не декодирует картинку."""
    n = len(data)
    if n < 4 or data[0] != 0xFF or data[1] != 0xD8:
        return None
    i = 2
    while i + 4 <= n:
        if data[i] != 0xFF:
            return None
        marker = data[i + 1]
        if marker == 0xFF:  # заполнитель
            i += 1
            continue
        if marker in (0xD8, 0x01) or 0xD0 <= marker <= 0xD7:
            i += 2
            continue
        seg = int.from_bytes(data[i + 2:i + 4], "big")
        if seg < 2:
            return None
        if marker in (0xC0, 0xC1, 0xC2):  # baseline / extended / progressive
            if i + 9 > n or seg < 8:
                return None
            h = int.from_bytes(data[i + 5:i + 7], "big")
            w = int.from_bytes(data[i + 7:i + 9], "big")
            return (w, h) if w > 0 and h > 0 else None
        if marker == 0xDA:  # начало данных, а SOF так и не встретился
            return None
        i += 2 + seg
    return None


@router.put("/avatar")
async def put_avatar(request: Request) -> JSONResponse:
    st = request.app.state
    s: Settings = st.settings
    claimed = _claimed_hash(request, has_body=True)
    caller = await authenticate(request, claimed)
    _rate(request, "avatar-set", caller.account_id, s.avatar_sets_per_hour, 3600.0)
    size = _content_length(request, s.avatar_max_bytes)
    chunks: list[bytes] = []
    got, digest = await _read_body(request, size, 30.0, chunks.append)
    if got != size:
        raise ApiError(400, "short_body")
    if not crypto.consteq(digest, claimed):
        raise ApiError(400, "hash_mismatch")
    data = b"".join(chunks)
    dims = jpeg_size(data)
    if dims is None:
        raise ApiError(415, "not_jpeg")
    if not (32 <= dims[0] <= s.avatar_max_side and 32 <= dims[1] <= s.avatar_max_side):
        raise ApiError(422, "bad_dimensions", max=s.avatar_max_side)
    async with st.pool.acquire() as con:
        async with con.transaction():
            await con.execute(
                "INSERT INTO avatars (account_id, data) VALUES ($1, $2)"
                " ON CONFLICT (account_id) DO UPDATE SET data = EXCLUDED.data, updated_at = now()",
                caller.account_id, data)
            ver = await con.fetchval(
                "UPDATE accounts SET avatar_ver = avatar_ver + 1 WHERE id = $1 RETURNING avatar_ver",
                caller.account_id)
    return JSONResponse({"ver": ver}, headers=_NO_STORE)


@router.delete("/avatar")
async def delete_avatar(request: Request) -> JSONResponse:
    st = request.app.state
    s: Settings = st.settings
    caller = await authenticate(request, EMPTY_SHA256)
    _rate(request, "avatar-set", caller.account_id, s.avatar_sets_per_hour, 3600.0)
    async with st.pool.acquire() as con:
        async with con.transaction():
            had = await con.fetchval("DELETE FROM avatars WHERE account_id = $1 RETURNING 1", caller.account_id)
            if had:
                ver = await con.fetchval(
                    "UPDATE accounts SET avatar_ver = avatar_ver + 1 WHERE id = $1 RETURNING avatar_ver",
                    caller.account_id)
            else:
                ver = await con.fetchval("SELECT avatar_ver FROM accounts WHERE id = $1", caller.account_id)
    return JSONResponse({"ver": ver}, headers=_NO_STORE)


@router.get("/avatar/{account_id}")
async def get_avatar(account_id: str, request: Request) -> Response:
    st = request.app.state
    acc = _parse_uuid(account_id)
    caller = await authenticate(request, EMPTY_SHA256)
    _rate(request, "avatar-get", caller.device_id, 240)
    async with st.pool.acquire() as con:
        row = await con.fetchrow(
            "SELECT a.avatar_ver, v.data FROM accounts a JOIN avatars v ON v.account_id = a.id"
            " WHERE a.id = $1 AND a.status = 'active'", acc)
    if row is None:
        raise ApiError(404, "no_avatar")
    ver = int(row["avatar_ver"])
    etag = f'"{ver}"'
    headers = {"ETag": etag, "Cache-Control": "private, no-cache", "X-Nuva-Avatar-Ver": str(ver)}
    if request.headers.get("if-none-match") == etag:
        return Response(status_code=304, headers=headers)
    return Response(content=bytes(row["data"]), media_type="image/jpeg", headers=headers)
