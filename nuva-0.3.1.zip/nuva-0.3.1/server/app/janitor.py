"""Фоновая уборка: просроченные сообщения и блобы, осиротевшие файлы, счётчики лимитов.

Диск VPS — 10 ГБ, поэтому ничего не «копится до перезапуска»: раз в janitor_interval_s сервер сам
чистит то, что клиенты уже не заберут. Сообщения и блобы живут не дольше 30 дней (expires_at).
"""
from __future__ import annotations

import asyncio
import logging
import os
import time
import uuid
from pathlib import Path
from typing import Any

from .config import Settings

log = logging.getLogger("nuva.janitor")

_BATCH = 2000
_ORPHAN_GRACE_S = 3600  # свежие файлы не трогаем: загрузка может быть в полёте


async def purge_messages(pool: Any) -> int:
    """Конверты с истёкшим expires_at (раньше они только скрывались при чтении и лежали вечно)."""
    total = 0
    while True:
        async with pool.acquire() as con:
            res = await con.execute(
                "DELETE FROM messages WHERE server_id IN ("
                " SELECT server_id FROM messages WHERE expires_at <= now() ORDER BY server_id LIMIT $1)",
                _BATCH)
        n = int(res.rsplit(" ", 1)[-1])
        total += n
        if n < _BATCH:
            return total
        await asyncio.sleep(0)


_SQL_PURGE_BLOBS = """
DELETE FROM blobs WHERE id IN (
  SELECT b.id FROM blobs b
   WHERE b.expires_at <= now()
      OR NOT EXISTS (                      -- все нужные устройства уже забрали, либо оставшиеся отозваны
           SELECT 1 FROM devices d
            WHERE d.account_id = b.recipient_account AND d.revoked_at IS NULL AND d.created_at <= b.created_at
              AND NOT EXISTS (SELECT 1 FROM blob_acks a WHERE a.blob_id = b.id AND a.device_id = d.id))
   LIMIT $1)
RETURNING id
"""


def _unlink_all(paths: list[Path]) -> int:
    n = 0
    for p in paths:
        try:
            p.unlink()
            n += 1
        except FileNotFoundError:
            pass
        except OSError:
            log.warning("cannot remove %s", p.name)
    return n


async def purge_blobs(pool: Any, settings: Settings) -> int:
    total = 0
    while True:
        async with pool.acquire() as con:
            rows = await con.fetch(_SQL_PURGE_BLOBS, 500)
        paths = [settings.blob_dir / f"{r['id']}.bin" for r in rows]
        await asyncio.to_thread(_unlink_all, paths)
        total += len(rows)
        if len(rows) < 500:
            return total
        await asyncio.sleep(0)


def _scan(blob_dir: Path, now: float) -> tuple[list[tuple[uuid.UUID, Path]], list[Path]]:
    """(старые .bin с их id, старые .part). Свежие и посторонние файлы пропускаем."""
    bins: list[tuple[uuid.UUID, Path]] = []
    parts: list[Path] = []
    with os.scandir(blob_dir) as it:
        for e in it:
            if not e.is_file(follow_symlinks=False):
                continue
            try:
                if now - e.stat().st_mtime < _ORPHAN_GRACE_S:
                    continue
            except OSError:
                continue
            if e.name.endswith(".part"):
                parts.append(Path(e.path))
            elif e.name.endswith(".bin"):
                try:
                    bins.append((uuid.UUID(e.name[:-4]), Path(e.path)))
                except ValueError:
                    pass
    return bins, parts


async def purge_orphan_files(pool: Any, settings: Settings) -> int:
    """Файлы без записи в БД (каскадное удаление аккаунта, сбой между rename и INSERT) и хвосты .part."""
    bins, parts = await asyncio.to_thread(_scan, settings.blob_dir, time.time())
    doomed = list(parts)
    for i in range(0, len(bins), 1000):
        chunk = bins[i:i + 1000]
        async with pool.acquire() as con:
            known = {r["id"] for r in await con.fetch(
                "SELECT id FROM blobs WHERE id = ANY($1::uuid[])", [b for b, _ in chunk])}
        doomed.extend(p for b, p in chunk if b not in known)
    return await asyncio.to_thread(_unlink_all, doomed)


def prune_rates(rates: dict) -> None:
    for key in [k for k, v in rates.items() if not v or time.monotonic() - v[-1] > 3600]:
        del rates[key]


async def sweep(state: Any) -> dict[str, int]:
    settings: Settings = state.settings
    out = {
        "messages": await purge_messages(state.pool),
        "blobs": await purge_blobs(state.pool, settings),
        "orphans": await purge_orphan_files(state.pool, settings),
    }
    prune_rates(state.http_rates)
    return out


async def janitor_loop(state: Any) -> None:
    await asyncio.sleep(15)  # дать серверу подняться
    while True:
        try:
            res = await sweep(state)
            if any(res.values()):
                log.info("janitor: removed %s", res)
        except asyncio.CancelledError:
            raise
        except Exception:  # noqa: BLE001 — уборка не должна падать и ронять сервер
            log.exception("janitor sweep failed")
        await asyncio.sleep(state.settings.janitor_interval_s)
