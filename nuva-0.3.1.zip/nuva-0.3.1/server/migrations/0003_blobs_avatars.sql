-- 0003_blobs_avatars.sql — протокол 0.3: зашифрованные блобы (голосовые) и публичные аватарки.
--
-- Блоб — это шифртекст, который сервер не может прочитать: клиент шифрует запись случайным ключом,
-- а ключ едет получателю внутри обычного E2E-конверта. Сервер хранит файл на диске (том blobs),
-- а здесь — только учёт: кто загрузил, кому предназначен, сколько весит и когда истекает.

CREATE TABLE blobs (
    id                 UUID PRIMARY KEY,                                       -- выбирает клиент (UUIDv7)
    uploader_account   UUID NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
    recipient_account  UUID NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
    size               BIGINT NOT NULL CHECK (size > 0),
    sha256             BYTEA  NOT NULL CHECK (octet_length(sha256) = 32),
    created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
    expires_at         TIMESTAMPTZ NOT NULL DEFAULT now() + INTERVAL '30 days'
);
CREATE INDEX blobs_uploader_idx  ON blobs (uploader_account);
CREATE INDEX blobs_recipient_idx ON blobs (recipient_account);
CREATE INDEX blobs_expiry_idx    ON blobs (expires_at);

-- Квитанция «это устройство получателя забрало блоб и сохранило у себя». Когда квитанции есть
-- от всех активных устройств получателя, существовавших на момент загрузки, блоб удаляется сразу.
CREATE TABLE blob_acks (
    blob_id   UUID NOT NULL REFERENCES blobs(id) ON DELETE CASCADE,
    device_id UUID NOT NULL,
    acked_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (blob_id, device_id)
);

-- Аватар — публичная часть профиля (как имя и юзернейм), JPEG до 256 КиБ.
-- avatar_ver растёт при каждой смене и удалении: клиенты кэшируют по версии (ETag).
ALTER TABLE accounts ADD COLUMN avatar_ver INT NOT NULL DEFAULT 0;

CREATE TABLE avatars (
    account_id UUID PRIMARY KEY REFERENCES accounts(id) ON DELETE CASCADE,
    data       BYTEA NOT NULL CHECK (octet_length(data) BETWEEN 1 AND 262144),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
