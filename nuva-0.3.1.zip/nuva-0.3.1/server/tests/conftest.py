"""Интеграционные тесты: нужен живой PostgreSQL в DATABASE_URL (в CI — service-контейнер).

    DATABASE_URL=postgresql://nuva:nuva@localhost:5432/nuva_test pytest
"""
from __future__ import annotations

import asyncio
import base64
import os
import tempfile
import uuid
from dataclasses import dataclass, field

import asyncpg
import pytest

os.environ.setdefault("SERVER_HOST", "api.nuva.test")
os.environ.setdefault("AUTH_TIMEOUT_S", "1.5")
os.environ.setdefault("IDLE_TIMEOUT_S", "5")
os.environ.setdefault("BLOB_DIR", os.path.join(tempfile.gettempdir(), "nuva-test-blobs"))
os.environ.setdefault("JANITOR_INTERVAL_S", "3600")

DATABASE_URL = os.environ.get("DATABASE_URL")

from nacl.bindings import crypto_scalarmult_base  # noqa: E402
from nacl.signing import SigningKey  # noqa: E402

from app import crypto  # noqa: E402

HOST = os.environ["SERVER_HOST"]


def b64(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode()


def unb64(s: str) -> bytes:
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


def db(sql: str, *args):
    async def run():
        con = await asyncpg.connect(DATABASE_URL)
        try:
            return await con.fetch(sql, *args)
        finally:
            await con.close()
    return asyncio.run(run())


def make_invite(uses: int = 1, days: int = 14, revoked: bool = False) -> str:
    code = crypto.generate_invite_code()
    db("INSERT INTO invites (code_hash, max_uses, expires_at, revoked_at)"
       " VALUES ($1, $2, now() + make_interval(days => $3), CASE WHEN $4 THEN now() END)",
       crypto.invite_hash(code), uses, days, revoked)
    return code


@dataclass
class Device:
    sk: SigningKey = field(default_factory=SigningKey.generate)
    xk_priv: bytes = field(default_factory=lambda: os.urandom(32))
    device_id: str | None = None
    account_id: str | None = None

    @property
    def ik(self) -> bytes:
        return self.sk.verify_key.encode()

    @property
    def xk(self) -> bytes:
        return crypto_scalarmult_base(self.xk_priv)

    def sign(self, data: bytes) -> bytes:
        return self.sk.sign(data).signature

    def register_frame(self, nonce: bytes, invite: str, username: str, fid: str = "c-1",
                       sig_override: bytes | None = None) -> dict:
        payload = crypto.reg_payload(HOST, nonce, self.ik, self.xk, username)
        return {
            "v": 1, "type": "account.register", "id": fid, "invite": invite, "username": username,
            "device": {
                "identity_key": b64(self.ik), "x25519_key": b64(self.xk),
                "x25519_sig": b64(self.sign(crypto.xk_payload(self.xk))), "platform": "desktop",
            },
            "sig": b64(sig_override if sig_override is not None else self.sign(payload)),
        }

    def auth_frame(self, nonce: bytes, fid: str = "c-1") -> dict:
        did = uuid.UUID(self.device_id)
        return {"v": 1, "type": "auth.response", "id": fid, "device_id": self.device_id,
                "sig": b64(self.sign(crypto.auth_payload(HOST, did, nonce)))}


@pytest.fixture(scope="session")
def client():
    if not DATABASE_URL:
        pytest.skip("DATABASE_URL is not set")
    from fastapi.testclient import TestClient

    from app.main import app
    with TestClient(app) as c:  # lifespan: пул + миграции
        yield c


@pytest.fixture(autouse=True)
def clean_db(request):
    if "client" in request.fixturenames:
        request.getfixturevalue("client")
        db("TRUNCATE messages, devices, accounts, invites RESTART IDENTITY CASCADE")
    yield


def connect(client):
    return client.websocket_connect("/ws", subprotocols=["nuva.v1"])


def challenge(ws) -> bytes:
    f = ws.receive_json()
    assert f["type"] == "auth.challenge" and f["v"] == 1
    nonce = unb64(f["nonce"])
    assert len(nonce) == 32
    return nonce


def register(client, dev: Device, username: str, invite: str | None = None) -> Device:
    invite = invite or make_invite()
    with connect(client) as ws:
        nonce = challenge(ws)
        ws.send_json(dev.register_frame(nonce, invite, username))
        r = ws.receive_json()
        assert r["type"] == "account.registered", r
        assert ws.receive_json()["type"] == "queue.empty"
        dev.device_id, dev.account_id = r["device_id"], r["account_id"]
    return dev
