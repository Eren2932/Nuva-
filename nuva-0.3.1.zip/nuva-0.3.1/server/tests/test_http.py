"""Протокол 0.3: блобы, аватарки, janitor (нужен PostgreSQL)."""
from __future__ import annotations

import asyncio
import hashlib
import os
import time
import uuid

import pytest

from app import crypto
from app.httpapi import jpeg_size
from conftest import HOST, DATABASE_URL, Device, b64, db, register

# ───────────── чистые функции (БД не нужна) ─────────────

# Эталонный вектор: тот же SHA-256 проверяет клиентский HttpAuthTest (NuvaCrypto.httpPayload).
def test_http_payload_vector():
    payload = crypto.http_payload(
        "api.nuva.test", uuid.UUID("0190a5c2-1e4f-7a3b-8c2d-5e6f708192a3"), 1788960000, "PUT",
        "/blob/0190a5c2-1e4f-7a3b-8c2d-5e6f708192a4?to=0190a5c2-1e4f-7a3b-8c2d-5e6f708192a5",
        hashlib.sha256(b"hello blob").digest())
    assert hashlib.sha256(payload).hexdigest() == (
        "e68732ff8c26758c034d21123a9008bdecb3ff146aba91b4b3900a59ac74b9e7")


def fake_jpeg(w: int, h: int) -> bytes:
    sof = b"\xff\xc0" + (17).to_bytes(2, "big") + b"\x08" + h.to_bytes(2, "big") + w.to_bytes(2, "big") \
        + b"\x03" + b"\x01\x22\x00\x02\x11\x01\x03\x11\x01"
    return b"\xff\xd8" + b"\xff\xe0\x00\x04\x00\x00" + sof + b"\xff\xda\x00\x02" + b"\x00" * 16 + b"\xff\xd9"


def test_jpeg_size_parses_sof_and_rejects_garbage():
    assert jpeg_size(fake_jpeg(384, 256)) == (384, 256)
    assert jpeg_size(b"not a jpeg at all") is None
    assert jpeg_size(b"\xff\xd8\xff\xda\x00\x02") is None  # SOS без SOF
    assert jpeg_size(b"") is None


# ───────────── интеграционные ─────────────

def signed(dev: Device, method: str, target: str, body: bytes = b"", ts: int | None = None,
           claimed: bytes | None = None) -> dict:
    ts = int(time.time()) if ts is None else ts
    digest = claimed if claimed is not None else hashlib.sha256(body).digest()
    payload = crypto.http_payload(HOST, uuid.UUID(dev.device_id), ts, method, target, digest)
    return {"X-Nuva-Device": dev.device_id, "X-Nuva-Ts": str(ts), "X-Nuva-Sha256": digest.hex(),
            "X-Nuva-Sig": b64(dev.sign(payload))}


def put_blob(client, dev: Device, to: Device, blob_id: str, body: bytes, **kw):
    target = f"/blob/{blob_id}?to={to.account_id}"
    return client.put(target, content=body, headers=signed(dev, "PUT", target, body, **kw))


def get(client, dev: Device, target: str):
    return client.get(target, headers=signed(dev, "GET", target))


def ack(client, dev: Device, blob_id: str):
    target = f"/blob/{blob_id}"
    return client.delete(target, headers=signed(dev, "DELETE", target))


def add_device(account_id: str) -> Device:
    d = Device()
    d.device_id, d.account_id = str(uuid.uuid4()), account_id
    db("INSERT INTO devices (id, account_id, identity_key, x25519_key, x25519_sig, platform)"
       " VALUES ($1, $2, $3, $4, $5, 'android')", uuid.UUID(d.device_id), uuid.UUID(account_id),
       d.ik, d.xk, d.sign(crypto.xk_payload(d.xk)))
    return d


def blob_file(blob_id: str):
    from app.config import get_settings
    return get_settings().blob_dir / f"{blob_id}.bin"


@pytest.fixture(autouse=True)
def blob_dir_tmp(tmp_path, monkeypatch):
    # Каждый тест — свой каталог блобов (настройки читаются лениво через lru_cache, поэтому правим объект).
    if not DATABASE_URL:
        yield
        return
    from app.config import get_settings
    monkeypatch.setattr(get_settings(), "blob_dir", tmp_path, raising=False)
    monkeypatch.setattr(get_settings(), "blob_min_free_bytes", 0, raising=False)
    yield


def test_blob_roundtrip_and_delete_after_all_devices_ack(client):
    alice = register(client, Device(), "alice")
    bob = register(client, Device(), "bob")
    bob2 = add_device(bob.account_id)
    bid = str(uuid.uuid4())
    body = os.urandom(5000)

    r = put_blob(client, alice, bob, bid, body)
    assert r.status_code == 201, r.text
    assert blob_file(bid).read_bytes() == body

    # скачивают оба устройства получателя и отправитель; чужой аккаунт — нет
    assert get(client, bob, f"/blob/{bid}").content == body
    assert get(client, bob2, f"/blob/{bid}").content == body
    assert get(client, alice, f"/blob/{bid}").content == body
    carol = register(client, Device(), "carol")
    assert get(client, carol, f"/blob/{bid}").status_code == 404

    # после первой квитанции блоб жив, после второй — удалён с диска и из БД
    assert ack(client, bob, bid).status_code == 204
    assert blob_file(bid).exists()
    assert ack(client, bob2, bid).status_code == 204
    assert not blob_file(bid).exists()
    assert get(client, bob, f"/blob/{bid}").status_code == 404
    assert ack(client, bob, bid).status_code == 204  # идемпотентно


def test_sender_can_cancel_blob(client):
    alice = register(client, Device(), "alice")
    bob = register(client, Device(), "bob")
    bid = str(uuid.uuid4())
    assert put_blob(client, alice, bob, bid, b"x" * 100).status_code == 201
    assert ack(client, alice, bid).status_code == 204
    assert not blob_file(bid).exists()


def test_blob_rejects_bad_signature_skew_and_hash(client):
    alice = register(client, Device(), "alice")
    bob = register(client, Device(), "bob")
    bid = str(uuid.uuid4())
    body = b"y" * 300
    target = f"/blob/{bid}?to={bob.account_id}"

    h = signed(alice, "PUT", target, body)
    h["X-Nuva-Sig"] = b64(bytes(64))
    assert client.put(target, content=body, headers=h).status_code == 401

    old = signed(alice, "PUT", target, body, ts=int(time.time()) - 3600)
    r = client.put(target, content=body, headers=old)
    assert r.status_code == 401 and r.json()["error"] == "clock_skew"
    assert abs(r.json()["server_time"] - time.time()) < 5
    assert "x-nuva-server-time" in r.headers

    # подпись валидна для другого тела → hash_mismatch, на диск ничего не попадает
    h = signed(alice, "PUT", target, b"z" * 300)
    r = client.put(target, content=body, headers=h)
    assert r.status_code == 400 and r.json()["error"] == "hash_mismatch"
    assert not blob_file(bid).exists()
    assert [p for p in blob_file(bid).parent.iterdir()] == []  # и .part не осталось

    # подпись нельзя переиспользовать для другого получателя/пути
    other = f"/blob/{bid}?to={alice.account_id}"
    assert client.put(other, content=body, headers=signed(alice, "PUT", target, body)).status_code == 401


def test_blob_limits_and_ownership(client, monkeypatch):
    from app.config import get_settings
    alice = register(client, Device(), "alice")
    bob = register(client, Device(), "bob")
    eve = register(client, Device(), "eve")
    s = get_settings()

    monkeypatch.setattr(s, "blob_max_bytes", 1000, raising=False)
    assert put_blob(client, alice, bob, str(uuid.uuid4()), b"a" * 1001).status_code == 413
    monkeypatch.setattr(s, "blob_max_bytes", 6 * 1024 * 1024, raising=False)

    monkeypatch.setattr(s, "blob_quota_bytes", 1500, raising=False)
    b1 = str(uuid.uuid4())
    assert put_blob(client, alice, bob, b1, b"a" * 1000).status_code == 201
    r = put_blob(client, alice, bob, str(uuid.uuid4()), b"a" * 1000)
    assert r.status_code == 507 and r.json()["error"] == "quota_exceeded"
    # повторная загрузка того же id заменяет блоб и не считается дважды
    assert put_blob(client, alice, bob, b1, b"b" * 1400).status_code == 201
    assert blob_file(b1).read_bytes() == b"b" * 1400

    # чужой id перезаписать нельзя
    assert put_blob(client, eve, bob, b1, b"evil").status_code == 409
    assert blob_file(b1).read_bytes() == b"b" * 1400
    # получатель обязан существовать
    ghost = Device()
    ghost.account_id = str(uuid.uuid4())
    assert put_blob(client, alice, ghost, str(uuid.uuid4()), b"q").status_code == 404


def test_avatar_flow_and_user_info(client):
    alice = register(client, Device(), "alice")
    bob = register(client, Device(), "bob")
    assert get(client, bob, f"/avatar/{alice.account_id}").status_code == 404

    img = fake_jpeg(384, 384)
    r = client.put("/avatar", content=img, headers=signed(alice, "PUT", "/avatar", img))
    assert r.status_code == 200 and r.json() == {"ver": 1}

    r = get(client, bob, f"/avatar/{alice.account_id}")
    assert r.status_code == 200 and r.content == img and r.headers["etag"] == '"1"'
    h = signed(bob, "GET", f"/avatar/{alice.account_id}")
    h["If-None-Match"] = '"1"'
    assert client.get(f"/avatar/{alice.account_id}", headers=h).status_code == 304

    # user.info отдаёт версию
    with client.websocket_connect("/ws", subprotocols=["nuva.v1"]) as ws:
        nonce = unb64_nonce(ws.receive_json())
        ws.send_json(bob.auth_frame(nonce))
        assert ws.receive_json()["type"] == "auth.ok"
        assert ws.receive_json()["type"] == "queue.empty"
        ws.send_json({"v": 1, "type": "user.lookup", "id": "l1", "account_id": alice.account_id})
        assert ws.receive_json()["account"]["avatar_ver"] == 1

    # мусор, огромные размеры и слишком большой файл отклоняются
    junk = b"GIF89a" + b"0" * 100
    assert client.put("/avatar", content=junk, headers=signed(alice, "PUT", "/avatar", junk)).status_code == 415
    big = fake_jpeg(4000, 4000)
    assert client.put("/avatar", content=big, headers=signed(alice, "PUT", "/avatar", big)).status_code == 422
    huge = fake_jpeg(384, 384) + b"0" * (256 * 1024)
    assert client.put("/avatar", content=huge, headers=signed(alice, "PUT", "/avatar", huge)).status_code == 413

    # удаление: версия растёт, картинки нет
    r = client.delete("/avatar", headers=signed(alice, "DELETE", "/avatar"))
    assert r.json() == {"ver": 2}
    assert get(client, bob, f"/avatar/{alice.account_id}").status_code == 404
    # повторное удаление ничего не меняет
    assert client.delete("/avatar", headers=signed(alice, "DELETE", "/avatar")).json() == {"ver": 2}


def unb64_nonce(frame: dict) -> bytes:
    from conftest import unb64
    assert frame["type"] == "auth.challenge"
    return unb64(frame["nonce"])


def test_janitor_sweeps_expired_messages_blobs_and_orphans(client):
    from app.janitor import sweep
    alice = register(client, Device(), "alice")
    bob = register(client, Device(), "bob")

    # просроченное сообщение лежит в очереди
    db("INSERT INTO messages (recipient_device_id, sender_device_id, client_msg_id, envelope, expires_at)"
       " VALUES ($1, $2, $3, $4, now() - interval '1 day')",
       uuid.UUID(bob.device_id), uuid.UUID(alice.device_id), uuid.uuid4(), b"env")
    # просроченный блоб и свежий блоб
    old, fresh = str(uuid.uuid4()), str(uuid.uuid4())
    assert put_blob(client, alice, bob, old, b"o" * 50).status_code == 201
    assert put_blob(client, alice, bob, fresh, b"f" * 50).status_code == 201
    db("UPDATE blobs SET expires_at = now() - interval '1 minute' WHERE id = $1", uuid.UUID(old))
    # сирота: файл без записи, старый
    orphan = blob_file(str(uuid.uuid4()))
    orphan.write_bytes(b"?")
    past = time.time() - 7200
    os.utime(orphan, (past, past))

    res = asyncio.run(_sweep_in_app(client))
    assert res == {"messages": 1, "blobs": 1, "orphans": 1}
    assert not blob_file(old).exists() and blob_file(fresh).exists() and not orphan.exists()
    assert db("SELECT count(*) AS n FROM messages")[0]["n"] == 0


async def _sweep_in_app(client):
    from app.janitor import sweep
    import asyncpg
    from app.config import get_settings

    class State:
        pass
    st = State()
    st.settings = get_settings()
    st.http_rates = {}
    st.pool = await asyncpg.create_pool(DATABASE_URL, min_size=1, max_size=2)
    try:
        return await sweep(st)
    finally:
        await st.pool.close()
