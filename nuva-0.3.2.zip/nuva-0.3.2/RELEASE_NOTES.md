# 0.3.2 (versionCode 10) — сборка клиента

- `ChatScreen.kt:190`: `scrollBy` — расширение (`androidx.compose.foundation.gestures.scrollBy`), в 0.3.0/0.3.1
  не было импорта: компилятор падал на `:ui:compileReleaseKotlinAndroid`. Добавлен импорт.
- Подпись: проверка ключа в CI теперь видит очищенные пароли (раньше NPE в KeyCheck). Ключ открывается.
- Страховка от ошибок вывода типов: `AndroidHost` (openBatterySettings/openAppSettings/openNotificationSettings) и
  `DesktopAudio.Player.run` переписаны с явными телами/нуллабельностью, поведение то же.

# 0.3.1 (versionCode 9) — исправление сборки

- Починено падение компиляции `:core:compileReleaseKotlinAndroid` / `:core:compileKotlinDesktop`:
  `Messenger.kt:1112` читал `r.data` у строки запроса `avatarFor`, а SQLDelight называет колонку `data`
  в сгенерированном классе `data_` (data — ключевое слово Kotlin). Запрос теперь `SELECT ver, data AS jpeg`,
  в коде `r.jpeg`. Схема БД и миграции не менялись.
- CI (Android): `assembleRelease` больше не тянет за собой `:core:allTests`. Тесты ядра идут отдельным шагом
  с `continue-on-error`: упавший тест не отнимает APK. Лог сборки и тестов выгружается всегда
  (артефакт android-build-log).
- Остальное — как в 0.3.0 (см. ниже). Клиент 0.3.0 до этого ни разу не собирался: после 1112 строки могут
  всплыть ошибки в :ui и :app-android — их компилятор до сих пор не видел.

# 0.3.0 (versionCode 8) — НЕ ПРОВЕРЕНО КОМПИЛЯТОРОМ

Сделано: сервер (blob/avatar HTTP API, janitor, миграция 0003), Opus-голосовые (NVO2), загрузка/скачивание блобов,
асинхронная запись с MIC, правки Composer (круг микрофона), Bubbles/ChatScreen (рывок цитаты), очистка launcher'ов.
Не сделано: клиентский UI аватарок (выбор фото, кроп, UserAvatar). Серверная часть аватарок готова.
Старые голосовые (ADPCM) читаются.
